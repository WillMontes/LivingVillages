package com.livingvillages.network;

import com.livingvillages.LivingVillages;
import com.livingvillages.ai.AiBrainService;
import com.livingvillages.ai.VillagerThought;
import com.livingvillages.job.GatherKind;
import com.livingvillages.job.VillagerJobs;
import com.livingvillages.memory.VillagerMemory;
import com.livingvillages.interfaces.MemoryHolder;
import com.livingvillages.personality.VillagerPersonality;
import com.livingvillages.village.Village;
import com.livingvillages.village.VillageCulture;
import com.livingvillages.village.VillageDefense;
import com.livingvillages.village.VillageEconomy;
import com.livingvillages.village.VillageRegistry;
import com.livingvillages.world.WorldPerception;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.phys.AABB;

import java.util.List;
import java.util.UUID;

public class PlayerVillagerChat {

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(
                        Commands.literal("talk")
                                .then(Commands.argument("message", StringArgumentType.greedyString())
                                        .executes(ctx -> {
                                            ServerPlayer player = ctx.getSource().getPlayerOrException();
                                            handleTalk(player, StringArgumentType.getString(ctx, "message"));
                                            return 1;
                                        }))
                )
        );
        LivingVillages.LOGGER.info("Registered /talk command.");
    }

    /** A one-line note about the village's standout ally and rival, so villagers can mention other villages. */
    private static String diplomacyNote(VillageRegistry registry, Village village) {
        Village ally = null, rival = null;
        int bestRel = 59, worstRel = -19;
        for (var e : village.relations().entrySet()) {
            Village other = registry.byId(e.getKey());
            if (other == null) continue;
            if (e.getValue() > bestRel)  { bestRel = e.getValue();  ally = other; }
            if (e.getValue() < worstRel) { worstRel = e.getValue(); rival = other; }
        }
        String note = "";
        if (ally != null)  note += "Your village is allied with " + ally.name() + ". ";
        if (rival != null) note += "Your village is rivals with " + rival.name() + ". ";
        return note.isEmpty() ? "" : note + "\n";
    }

    /** How far /talk reaches for a villager — roughly a village's worth of range. */
    private static final double TALK_RANGE = 40.0;

    private static void handleTalk(ServerPlayer player, String message) {
        ServerLevel level = (ServerLevel) player.level();
        // Wide but flat: reach across the village, but don't grab a villager deep in the mine below.
        double px = player.getX(), py = player.getY(), pz = player.getZ();
        AABB box = new AABB(px - TALK_RANGE, py - 12, pz - TALK_RANGE, px + TALK_RANGE, py + 12, pz + TALK_RANGE);
        List<Villager> nearby = level.getEntitiesOfClass(Villager.class, box);

        if (nearby.isEmpty()) {
            player.sendSystemMessage(Component.literal("§7(No villager nearby.)"));
            return;
        }

        Villager villager = nearby.stream()
                .min((a, b) -> Double.compare(a.distanceTo(player), b.distanceTo(player)))
                .orElse(nearby.get(0));

        UUID uuid = villager.getUUID();

        // Pull persisted memory and personality from the villager entity via the mixin
        MemoryHolder holder = (MemoryHolder) villager;
        VillagerPersonality personality = holder.lv_getPersonality();
        VillagerMemory memory = holder.lv_getMemory();

        // Resolve the village this villager belongs to (founding one here if needed) so the
        // villager can speak from shared village knowledge, reserves, and the player's standing.
        VillageRegistry registry = level.getAttachedOrCreate(LivingVillages.VILLAGES);
        Village village = registry.getOrCreate(villager.blockPosition());
        village.replaceResources(VillageEconomy.scan(level, village.center()));
        VillageCulture culture = VillageCulture.of(level, village);
        level.setAttached(LivingVillages.VILLAGES, registry);

        // Perceive the immediate surroundings so the villager can speak about them (Feature 11).
        String surroundings = WorldPerception.describe(level, villager);
        String threatNote = VillageDefense.isUnderThreat(village.id())
                ? "YOUR VILLAGE IS UNDER ATTACK RIGHT NOW — be urgent, but stay helpful: if the player "
                  + "asks where the enemy is, tell them the exact coordinates of the nearest hostile from what you can see.\n\n"
                : "";

        String playerName = player.getName().getString();
        int rep = village.reputationOf(player.getUUID());
        String lineageSummary = holder.lv_getLineage().summary();
        String lineageNote = lineageSummary.isEmpty() ? "" : lineageSummary + "\n\n";

        String prompt = personality.toPromptPreamble() + "\n\n" +
                "You live in the village of " + village.name() + ", " + culture.description() + ". " +
                "Your opinion of " + playerName + ": " + Village.reputationLabel(rep)
                    + " (reputation " + rep + " on a -100..100 scale).\n\n" +
                lineageNote +
                threatNote +
                "What you can see around you right now:\n" + surroundings + "\n\n" +
                "Your village's stored reserves: " + village.resourceSummary() + ".\n" +
                "What your village has built so far: " + village.upgradeSummary() + ".\n" +
                diplomacyNote(registry, village) +
                "Your village collectively remembers:\n" + village.recentChronicle(5) + "\n\n" +
                "What you personally remember:\n" + memory.factsPromptString() + "\n\n" +
                "Recent conversation:\n" + memory.toPromptString(8) + "\n\n" +
                "Player " + playerName + " says: \"" + message + "\"\n\nRespond.";

        player.sendSystemMessage(Component.literal("§e" + playerName + "§r: " + message));

        AiBrainService.getInstance().think(uuid.toString(), prompt,
                thought -> {
                    String vName = personality.name;
                    if (thought.hasSpeech()) {
                        player.sendSystemMessage(Component.literal("§b" + vName + "§r: " + thought.speech));
                        // Persist both sides of the conversation so the villager remembers
                        memory.remember(playerName + " said: \"" + message + "\"");
                        memory.remember("You replied: \"" + thought.speech + "\"");
                        // Persist any durable facts the villager chose to remember (e.g. the player's name)
                        for (String fact : thought.memory) {
                            memory.rememberFact(fact);
                            LivingVillages.LOGGER.info("{} remembered: {}", vName, fact);
                        }
                        // Surface the villager's stated intent. Behaviour execution isn't wired yet,
                        // but recording the intent makes job requests visible and logs it for later.
                        if (thought.action != VillagerThought.Action.IDLE
                                && thought.action != VillagerThought.Action.UNKNOWN) {
                            String intent = thought.action.name().toLowerCase().replace('_', ' ');
                            String detail = thought.target.isBlank() ? intent : intent + " (" + thought.target + ")";
                            player.sendSystemMessage(Component.literal("§8(" + vName + " intends to: " + detail + ")"));
                            memory.remember("You decided to: " + detail);

                            // Execute the job for real (Layer C).
                            switch (thought.action) {
                                case GATHER_WOOD   -> VillagerJobs.startGather(level, villager, GatherKind.WOOD);
                                case MINE_STONE    -> VillagerJobs.startGather(level, villager, GatherKind.STONE);
                                case HARVEST_CROPS -> VillagerJobs.startGather(level, villager, GatherKind.CROPS);
                                case BUILD         -> VillagerJobs.startBuild(level, villager);
                                case BUILD_HOUSE   -> VillagerJobs.startHouse(level, villager);
                                case LAY_STREET    -> VillagerJobs.startStreet(level, villager);
                                case EXCAVATE      -> VillagerJobs.startMine(level, villager);
                                case FORTIFY       -> VillagerJobs.startWallTeam(level, villager.blockPosition(), 4);
                                case EXPLORE       -> VillagerJobs.startExplore(level, villager);
                                default            -> { }
                            }
                        }
                    } else {
                        player.sendSystemMessage(Component.literal("§7(" + vName + " stares blankly.)"));
                    }
                },
                err -> player.sendSystemMessage(Component.literal("§c(The villager seems distracted.)"))
        );
    }
}