package com.livingvillages.village;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Container;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.chunk.LevelChunk;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Feature 9 (Village Economy): builds a snapshot of a village's stored goods by
 * scanning containers (chests, barrels, etc.) in the chunks around its center.
 *
 * Iterating each chunk's block-entity map is cheap — it only visits containers that
 * actually exist, never every block — so this is safe to run on demand (e.g. /village
 * or a conversation) rather than on a tick.
 */
public final class VillageEconomy {

    /** How many chunks out from the center to scan (2 ≈ a 5x5 chunk area around the village core). */
    private static final int CHUNK_RADIUS = 2;

    private static final String[] FOOD_KEYWORDS = {
            "bread", "carrot", "potato", "beetroot", "wheat", "apple", "melon", "pumpkin_pie",
            "beef", "porkchop", "mutton", "chicken", "cod", "salmon", "stew", "berries", "cookie", "kelp"
    };

    private VillageEconomy() {}

    public static Map<String, Integer> scan(ServerLevel level, BlockPos center) {
        Map<String, Integer> totals = new LinkedHashMap<>();
        int ccx = center.getX() >> 4;
        int ccz = center.getZ() >> 4;
        for (int cx = ccx - CHUNK_RADIUS; cx <= ccx + CHUNK_RADIUS; cx++) {
            for (int cz = ccz - CHUNK_RADIUS; cz <= ccz + CHUNK_RADIUS; cz++) {
                LevelChunk chunk = level.getChunk(cx, cz);
                for (BlockEntity be : chunk.getBlockEntities().values()) {
                    if (be instanceof Container container) tally(container, totals);
                }
            }
        }
        return totals;
    }

    /** Counts empty slots across storage near the center — low means the village is running out of space. */
    public static int freeSlots(ServerLevel level, BlockPos center) {
        int free = 0;
        int ccx = center.getX() >> 4;
        int ccz = center.getZ() >> 4;
        for (int cx = ccx - CHUNK_RADIUS; cx <= ccx + CHUNK_RADIUS; cx++) {
            for (int cz = ccz - CHUNK_RADIUS; cz <= ccz + CHUNK_RADIUS; cz++) {
                for (BlockEntity be : level.getChunk(cx, cz).getBlockEntities().values()) {
                    if (!(be instanceof Container c)) continue;
                    for (int i = 0; i < c.getContainerSize(); i++) {
                        if (c.getItem(i).isEmpty()) free++;
                    }
                }
            }
        }
        return free;
    }

    /** Nearest storage container to the village center within the scan area, or null if none. */
    public static BlockPos findStorage(ServerLevel level, BlockPos center) {
        BlockPos best = null;
        double bestSq = Double.MAX_VALUE;
        int ccx = center.getX() >> 4;
        int ccz = center.getZ() >> 4;
        for (int cx = ccx - CHUNK_RADIUS; cx <= ccx + CHUNK_RADIUS; cx++) {
            for (int cz = ccz - CHUNK_RADIUS; cz <= ccz + CHUNK_RADIUS; cz++) {
                for (Map.Entry<BlockPos, BlockEntity> e : level.getChunk(cx, cz).getBlockEntities().entrySet()) {
                    if (!(e.getValue() instanceof Container)) continue;
                    double sq = center.distSqr(e.getKey());
                    if (sq < bestSq) {
                        bestSq = sq;
                        best = e.getKey();
                    }
                }
            }
        }
        return best;
    }

    /**
     * Removes up to {@code amount} items of the given category from storage near the center
     * (used to pay for construction). Returns how many were actually taken.
     */
    public static int withdraw(ServerLevel level, BlockPos center, String category, int amount) {
        int removed = 0;
        int ccx = center.getX() >> 4;
        int ccz = center.getZ() >> 4;
        for (int cx = ccx - CHUNK_RADIUS; cx <= ccx + CHUNK_RADIUS && removed < amount; cx++) {
            for (int cz = ccz - CHUNK_RADIUS; cz <= ccz + CHUNK_RADIUS && removed < amount; cz++) {
                for (BlockEntity be : level.getChunk(cx, cz).getBlockEntities().values()) {
                    if (!(be instanceof Container c)) continue;
                    boolean touched = false;
                    for (int i = 0; i < c.getContainerSize() && removed < amount; i++) {
                        ItemStack s = c.getItem(i);
                        if (s.isEmpty() || !category.equals(categoryOf(s.getItem()))) continue;
                        int take = Math.min(s.getCount(), amount - removed);
                        s.shrink(take);
                        c.setItem(i, s);
                        removed += take;
                        touched = true;
                    }
                    if (touched) c.setChanged();
                    if (removed >= amount) return removed;
                }
            }
        }
        return removed;
    }

    private static void tally(Container container, Map<String, Integer> totals) {
        int size = container.getContainerSize();
        for (int i = 0; i < size; i++) {
            ItemStack stack = container.getItem(i);
            if (stack.isEmpty()) continue;
            String cat = categoryOf(stack.getItem());
            if (cat != null) totals.merge(cat, stack.getCount(), Integer::sum);
        }
    }

    /** Maps an item to an economy category by its registry path, or null if untracked. */
    public static String categoryOf(Item item) {
        String path = BuiltInRegistries.ITEM.getKey(item).getPath();
        if (path.contains("emerald")) return "emeralds";
        if (path.contains("iron")) return "iron";   // before stone so iron_ore isn't mislabeled
        if (path.contains("log") || path.contains("planks") || path.endsWith("_wood")) return "wood";
        if (path.contains("cobble") || path.contains("stone") || path.contains("deepslate")) return "stone";
        for (String f : FOOD_KEYWORDS) {
            if (path.contains(f)) return "food";
        }
        return null;
    }
}
