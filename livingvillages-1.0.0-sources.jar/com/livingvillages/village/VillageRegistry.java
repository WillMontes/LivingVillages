package com.livingvillages.village;

import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * All villages within one ServerLevel. Attached to the level and persisted via codec.
 *
 * Villages are defined by proximity clustering: a villager belongs to the nearest
 * village whose center is within {@link #VILLAGE_RADIUS}; if there is none, a new
 * village is anchored at that spot.
 */
public class VillageRegistry {

    /** Max distance (blocks) from a village center for a villager to count as a member. */
    public static final double VILLAGE_RADIUS = 64.0;

    private final List<Village> villages = new ArrayList<>();

    public static final Codec<VillageRegistry> CODEC = Village.CODEC.listOf().xmap(
            list -> {
                VillageRegistry r = new VillageRegistry();
                r.villages.addAll(list);
                return r;
            },
            r -> r.villages
    );

    public VillageRegistry() {}

    public List<Village> all() { return villages; }

    public Village byId(UUID id) {
        for (Village v : villages) {
            if (v.id().equals(id)) return v;
        }
        return null;
    }

    /** Nearest village whose center is within {@code maxDist} of {@code pos}, or null. */
    public Village findNearest(BlockPos pos, double maxDist) {
        Village best = null;
        double bestSq = maxDist * maxDist;
        for (Village v : villages) {
            double d = v.center().distSqr(pos);
            if (d <= bestSq) {
                bestSq = d;
                best = v;
            }
        }
        return best;
    }

    /** Returns the village covering {@code pos}, creating one anchored there if none exists. */
    public Village getOrCreate(BlockPos pos) {
        Village near = findNearest(pos, VILLAGE_RADIUS);
        if (near != null) return near;
        Village created = new Village(UUID.randomUUID(), VillageNames.forPosition(pos), pos);
        villages.add(created);
        return created;
    }
}
