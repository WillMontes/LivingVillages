package com.livingvillages.village;

import net.minecraft.core.BlockPos;

/** Generates a stable, location-derived name for a newly founded village. */
public final class VillageNames {

    private static final String[] PREFIX = {
            "North", "South", "East", "West", "Stone", "Oak",
            "River", "Hill", "Pine", "Misty", "Green", "Iron"
    };
    private static final String[] SUFFIX = {
            "haven", "ford", "wood", "bury", "vale", "reach",
            "stead", "hollow", "crest", "gate", "fall", "mere"
    };

    private VillageNames() {}

    public static String forPosition(BlockPos pos) {
        int h = Math.abs(pos.getX() * 31 + pos.getZ() * 17 + 7);
        return PREFIX[h % PREFIX.length] + SUFFIX[(h / PREFIX.length) % SUFFIX.length];
    }
}
