package com.livingvillages.village;

import com.livingvillages.LivingVillages;
import com.livingvillages.interfaces.MemoryHolder;
import com.livingvillages.personality.VillagerPersonality;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.phys.AABB;

import java.util.List;

/**
 * Feature 14: Village Reports. {@code /village} prints the status of the nearest
 * village — population, leader, the player's standing, the economy ledger, and a
 * digest of recent shared events.
 */
public class VillageCommands {

    /** Whoever ranks first here acts as the village's coordinator (Feature 10). */
    private static final List<String> LEADER_PRIORITY =
            List.of("Elder", "Merchant", "Guard", "Scholar", "Builder");

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, env) ->
                dispatcher.register(Commands.literal("village").executes(ctx -> {
                    ServerPlayer player = ctx.getSource().getPlayerOrException();
                    report(player);
                    return 1;
                }))
        );
        LivingVillages.LOGGER.info("Registered /village command.");
    }

    private static void report(ServerPlayer player) {
        ServerLevel level = (ServerLevel) player.level();
        VillageRegistry reg = level.getAttachedOrCreate(LivingVillages.VILLAGES);
        Village village = reg.findNearest(player.blockPosition(), VillageRegistry.VILLAGE_RADIUS);

        if (village == null) {
            player.sendSystemMessage(Component.literal(
                    "§7(No village nearby. Stand among villagers and talk to one to found it.)"));
            return;
        }

        // Refresh the economy ledger from nearby storage before reporting (Feature 9).
        village.replaceResources(VillageEconomy.scan(level, village.center()));
        VillageCulture culture = VillageCulture.of(level, village);
        level.setAttached(LivingVillages.VILLAGES, reg);

        List<Villager> members = membersOf(level, village);
        String leader = electLeader(members);
        int rep = village.reputationOf(player.getUUID());

        player.sendSystemMessage(Component.literal("§6=== " + village.name() + " ==="));
        player.sendSystemMessage(Component.literal("§7Culture: §f" + culture.label));
        player.sendSystemMessage(Component.literal("§7Population: §f" + members.size()));
        player.sendSystemMessage(Component.literal("§7Leader: §f" + (leader == null ? "none yet" : leader)));
        player.sendSystemMessage(Component.literal(
                "§7Your standing: §f" + Village.reputationLabel(rep) + " §8(" + rep + ")"));
        player.sendSystemMessage(Component.literal("§7Resources: §f" + village.resourceSummary()));
        player.sendSystemMessage(Component.literal("§7Resource concern: §f" + village.resourceConcern()));
        player.sendSystemMessage(Component.literal("§7Upgrades: §f" + village.upgradeSummary()));
        String threats;
        if (VillageDefense.isUnderThreat(village.id())) {
            String loc = VillageDefense.threatLocation(village.id());
            threats = "§cUNDER ATTACK NOW" + (loc == null ? "" : " §7(nearest at " + loc + ")");
        } else {
            threats = village.threatSummary();
        }
        player.sendSystemMessage(Component.literal("§7Recent threats: §f" + threats));

        var rels = village.relations();
        if (!rels.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (var e : rels.entrySet()) {
                Village other = reg.byId(e.getKey());
                if (other == null) continue;
                sb.append(other.name()).append(" (").append(Village.relationLabel(e.getValue())).append("), ");
            }
            if (sb.length() > 0) {
                player.sendSystemMessage(Component.literal("§7Relations: §f" + sb.substring(0, sb.length() - 2)));
            }
        }

        player.sendSystemMessage(Component.literal("§7Recent events:"));
        List<String> events = village.chronicle();
        if (events.isEmpty()) {
            player.sendSystemMessage(Component.literal("  §8- (none yet)"));
        } else {
            for (String e : tail(events, 5)) {
                player.sendSystemMessage(Component.literal("  §8- " + e));
            }
        }
    }

    private static List<Villager> membersOf(ServerLevel level, Village village) {
        BlockPos c = village.center();
        double r = VillageRegistry.VILLAGE_RADIUS;
        AABB box = new AABB(c.getX() - r, c.getY() - r, c.getZ() - r,
                            c.getX() + r, c.getY() + r, c.getZ() + r);
        return level.getEntitiesOfClass(Villager.class, box);
    }

    private static String electLeader(List<Villager> members) {
        Villager best = null;
        int bestRank = Integer.MAX_VALUE;
        for (Villager v : members) {
            VillagerPersonality p = ((MemoryHolder) v).lv_getPersonality();
            int rank = LEADER_PRIORITY.indexOf(p.archetype);
            if (rank < 0) rank = LEADER_PRIORITY.size();
            if (rank < bestRank) {
                bestRank = rank;
                best = v;
            }
        }
        return best == null ? null : ((MemoryHolder) best).lv_getPersonality().name;
    }

    private static List<String> tail(List<String> list, int n) {
        return list.subList(Math.max(0, list.size() - n), list.size());
    }
}
