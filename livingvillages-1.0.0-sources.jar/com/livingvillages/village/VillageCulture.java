package com.livingvillages.village;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

/**
 * A village's specialized culture, derived from the terrain it was founded in. Cultures
 * give villages distinct economic identities that drive the regional economy: each
 * over-produces and exports its specialty while importing what it lacks, so a farming
 * village and a mining town come to depend on (and ally with) each other.
 */
public enum VillageCulture {
    AGRICULTURAL("agricultural", "food"),
    FORESTRY("forestry", "wood"),
    MINING("mining", "stone"),
    MARTIAL("martial", null);                 // martial exports nothing — it focuses on defense

    public final String label;
    public final String export;               // primary export resource category, or null

    VillageCulture(String label, String export) {
        this.label = label;
        this.export = export;
    }

    public String description() {
        return switch (this) {
            case AGRICULTURAL -> "a farming community renowned for its crops and full granaries";
            case FORESTRY     -> "a logging community that works the surrounding forests";
            case MINING       -> "a mining town built into rich stone and ore";
            case MARTIAL      -> "a fortified warrior community focused on walls and defense";
        };
    }

    /** Returns the village's culture, deriving and storing it from terrain on first use (caller persists). */
    public static VillageCulture of(ServerLevel level, Village village) {
        VillageCulture c = village.culture();
        if (c == null) {
            c = derive(level, village.center());
            village.setCulture(c);
        }
        return c;
    }

    private static final int R = 20, STEP = 4, RUGGED = 16, TREE_REACH = 6, SCAN_DOWN = 24;

    public static VillageCulture derive(ServerLevel level, BlockPos center) {
        int trees = 0, stone = 0, arable = 0;
        int minG = Integer.MAX_VALUE, maxG = Integer.MIN_VALUE;
        for (int dx = -R; dx <= R; dx += STEP) {
            for (int dz = -R; dz <= R; dz += STEP) {
                int x = center.getX() + dx, z = center.getZ() + dz;
                int groundTop = groundTop(level, x, z);
                minG = Math.min(minG, groundTop);
                maxG = Math.max(maxG, groundTop);
                String surf = path(level.getBlockState(new BlockPos(x, groundTop, z)));
                if (isStone(surf)) stone++;
                else if (isArable(surf)) arable++;
                if (hasTree(level, x, groundTop + 1, z)) trees++;
            }
        }
        if (maxG - minG >= RUGGED) return MARTIAL;          // rugged, defensible highland → a stronghold
        int best = Math.max(trees, Math.max(stone, arable));
        if (best == 0) return MARTIAL;                       // barren fallback
        if (best == trees) return FORESTRY;
        if (best == stone) return MINING;
        return AGRICULTURAL;
    }

    /** Top solid ground block (ignores leaves/logs/liquids) so tree height doesn't skew terrain ruggedness. */
    private static int groundTop(ServerLevel level, int x, int z) {
        int top = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
        for (int y = top; y >= top - SCAN_DOWN; y--) {
            BlockState bs = level.getBlockState(new BlockPos(x, y, z));
            if (bs.isAir()) continue;
            String p = path(bs);
            if (p.contains("leaves") || p.contains("_log") || p.equals("water") || p.equals("lava")) continue;
            return y;
        }
        return top - 1;
    }

    private static boolean hasTree(ServerLevel level, int x, int fromY, int z) {
        for (int y = fromY; y <= fromY + TREE_REACH; y++) {
            if (path(level.getBlockState(new BlockPos(x, y, z))).contains("_log")) return true;
        }
        return false;
    }

    private static boolean isStone(String p) {
        return p.equals("stone") || p.contains("deepslate") || p.contains("andesite")
            || p.contains("granite") || p.contains("diorite") || p.contains("tuff")
            || p.contains("gravel") || p.endsWith("_ore");
    }

    private static boolean isArable(String p) {
        return p.equals("grass_block") || p.equals("dirt") || p.equals("farmland")
            || p.equals("sand") || p.contains("podzol") || p.contains("mud") || p.contains("moss");
    }

    private static String path(BlockState bs) {
        return BuiltInRegistries.BLOCK.getKey(bs.getBlock()).getPath();
    }
}
