package com.livingvillages.village;

import com.livingvillages.LivingVillages;
import com.livingvillages.interfaces.MemoryHolder;
import com.livingvillages.job.VillagerJobs;
import com.livingvillages.job.WallJob;
import com.livingvillages.world.WorldPerception;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.animal.golem.IronGolem;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.phys.AABB;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Feature 12: Adaptive Defense. Watches loaded villages for hostile mobs and reacts when
 * a raid begins: it raises an alarm (player message + a remembered chronicle entry),
 * records the raid on the village for future reference, and cancels villagers' active
 * jobs so their normal self-preservation AI (fleeing zombies, heading indoors) takes over
 * instead of them obliviously chopping wood mid-attack.
 *
 * Only villages near a player are checked, so far-off chunks are never force-loaded.
 */
public final class VillageDefense {

    private static final int    CHECK_INTERVAL   = 40;            // ~2s, for responsiveness
    private static final double LOADED_RADIUS_SQ = 128.0 * 128.0;
    /** Threat scan is a FLAT box: wide horizontally, shallow vertically, so cave mobs far
     *  below the village don't register as a surface raid. */
    private static final double THREAT_H_RADIUS  = VillageRegistry.VILLAGE_RADIUS;
    private static final double THREAT_V_RADIUS  = 10.0;

    /** Villages currently under threat, so we alarm once on onset and announce the all-clear once. */
    private static final Set<UUID> threatened = ConcurrentHashMap.newKeySet();
    /** Most recent location of the nearest threat per village, for reporting coordinates. */
    private static final Map<UUID, BlockPos> nearestThreat = new ConcurrentHashMap<>();
    /** When each threatened village last actually saw a hostile, to avoid rapid alarm flapping. */
    private static final Map<UUID, Long> lastThreatSeen = new ConcurrentHashMap<>();
    private static final long GRACE_MS = 12000L;   // stay alert ~12s after the last hostile vanishes

    private static int ticks;

    private VillageDefense() {}

    public static boolean isUnderThreat(UUID villageId) {
        return threatened.contains(villageId);
    }

    /** "x, y, z" of the nearest current threat, or null if none. */
    public static String threatLocation(UUID villageId) {
        BlockPos p = nearestThreat.get(villageId);
        return p == null ? null : p.getX() + ", " + p.getY() + ", " + p.getZ();
    }

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (++ticks < CHECK_INTERVAL) return;
            ticks = 0;
            for (ServerLevel level : server.getAllLevels()) sweep(level);
        });
        LivingVillages.LOGGER.info("Adaptive village defense enabled.");
    }

    private static void sweep(ServerLevel level) {
        List<ServerPlayer> players = level.players();
        if (players.isEmpty()) return;

        long now = System.currentTimeMillis();
        VillageRegistry reg = level.getAttachedOrCreate(LivingVillages.VILLAGES);
        boolean changed = false;
        for (Village village : reg.all()) {
            if (!nearAnyPlayer(village.center(), players)) continue;

            List<Monster> hostiles = level.getEntitiesOfClass(Monster.class, areaOf(village));
            hostiles.removeIf(mm -> !WorldPerception.isOutInTheOpen(level, mm));   // ignore cave mobs
            boolean wasThreatened = threatened.contains(village.id());

            if (!hostiles.isEmpty()) {
                lastThreatSeen.put(village.id(), now);
                nearestThreat.put(village.id(), nearestTo(village.center(), hostiles));   // keep coords fresh
                rallyGolems(level, village, hostiles);
                if (!wasThreatened) {
                    threatened.add(village.id());
                    onRaidStart(level, village, hostiles.size(), players);
                    changed = true;
                }
            } else if (wasThreatened && now - lastThreatSeen.getOrDefault(village.id(), 0L) >= GRACE_MS) {
                threatened.remove(village.id());
                nearestThreat.remove(village.id());
                lastThreatSeen.remove(village.id());
                onRaidEnd(level, village, players);
                changed = true;
            }
        }
        if (changed) level.setAttached(LivingVillages.VILLAGES, reg);
    }

    /** Point any iron golems at the nearest raider so they engage threats beyond their own sight range. */
    private static void rallyGolems(ServerLevel level, Village village, List<Monster> hostiles) {
        for (IronGolem golem : level.getEntitiesOfClass(IronGolem.class, areaOf(village))) {
            Monster target = nearestMonster(golem.blockPosition(), hostiles);
            if (target == null) continue;
            golem.setTarget(target);
            golem.getNavigation().moveTo(target, 1.1);
        }
    }

    private static Monster nearestMonster(BlockPos from, List<Monster> hostiles) {
        Monster best = null;
        double bestSq = Double.MAX_VALUE;
        for (Monster m : hostiles) {
            double d = from.distSqr(m.blockPosition());
            if (d < bestSq) { bestSq = d; best = m; }
        }
        return best;
    }

    private static BlockPos nearestTo(BlockPos center, List<Monster> hostiles) {
        BlockPos best = null;
        double bestSq = Double.MAX_VALUE;
        for (Monster m : hostiles) {
            double d = center.distSqr(m.blockPosition());
            if (d < bestSq) { bestSq = d; best = m.blockPosition(); }
        }
        return best;
    }

    private static void onRaidStart(ServerLevel level, Village village, int count, List<ServerPlayer> players) {
        BlockPos at = nearestThreat.get(village.id());
        String where = at == null ? "" : " near (" + at.getX() + ", " + at.getY() + ", " + at.getZ() + ")";
        village.recordRaid();
        village.record("A raid struck " + village.name() + " — " + count + " hostile creature"
                + (count == 1 ? "" : "s") + "!" + where);

        if (isWalled(village)) {
            WallJob.closeGates(level, village.center(), village.wallRadius());
            village.record("The gates of " + village.name() + " were sealed shut.");
        }

        // Guards fight; everyone else musters to safety. In a martial village, every able
        // adult takes up arms instead of just the Guards.
        boolean martial = VillageCulture.of(level, village) == VillageCulture.MARTIAL;
        for (Villager v : level.getEntitiesOfClass(Villager.class, areaOf(village))) {
            boolean fighter = (martial && !v.isBaby())
                    || "Guard".equals(((MemoryHolder) v).lv_getPersonality().archetype);
            if (fighter) {
                VillagerJobs.startGuard(level, v, village.id(), village.center());
            } else {
                VillagerJobs.startMuster(v, village.id(), village.center());
            }
        }

        Component alarm = Component.literal("§c⚠ " + village.name() + " is under attack!" + where);
        for (ServerPlayer p : players) {
            if (village.center().distSqr(p.blockPosition()) <= LOADED_RADIUS_SQ) p.sendSystemMessage(alarm);
        }
        LivingVillages.LOGGER.info("Raid on {} ({} hostiles){}.", village.name(), count, where);
    }

    private static void onRaidEnd(ServerLevel level, Village village, List<ServerPlayer> players) {
        if (isWalled(village)) {
            WallJob.openGates(level, village.center(), village.wallRadius());
        }
        village.record("The raid on " + village.name() + " has ended.");
        Component allClear = Component.literal("§a" + village.name() + " is safe again.");
        for (ServerPlayer p : players) {
            if (village.center().distSqr(p.blockPosition()) <= LOADED_RADIUS_SQ) p.sendSystemMessage(allClear);
        }
    }

    private static AABB areaOf(Village village) {
        BlockPos c = village.center();
        return new AABB(
                c.getX() - THREAT_H_RADIUS, c.getY() - THREAT_V_RADIUS, c.getZ() - THREAT_H_RADIUS,
                c.getX() + THREAT_H_RADIUS, c.getY() + THREAT_V_RADIUS, c.getZ() + THREAT_H_RADIUS);
    }

    private static boolean isWalled(Village village) {
        int r = village.wallRadius();
        return r > 0 && village.wallProgress() >= WallJob.perimeterColumns(r);
    }

    private static boolean nearAnyPlayer(BlockPos center, List<ServerPlayer> players) {
        for (ServerPlayer p : players) {
            if (center.distSqr(p.blockPosition()) <= LOADED_RADIUS_SQ) return true;
        }
        return false;
    }
}
