package com.livingvillages.village;

import com.livingvillages.LivingVillages;
import com.livingvillages.interfaces.MemoryHolder;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.item.ItemStack;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

/**
 * Turns world events into village memory and reputation changes — Feature 13
 * (Reputation) feeding Feature 6 (Shared Village Memory). Because reputation lives on
 * the village, every villager there reacts to what one of them experienced (Feature 4).
 */
public class VillageEvents {

    private static final int ATTACK_REP_PENALTY  = -15;
    private static final int DEFENSE_REP_REWARD  =  3;

    public static void register() {
        registerAttacks();
        registerDefense();
        registerGifts();
        LivingVillages.LOGGER.info("Village reputation tracking enabled (attacks, defense, gifts).");
    }

    /** Harming a villager drops the player's standing village-wide. */
    private static void registerAttacks() {
        ServerLivingEntityEvents.AFTER_DAMAGE.register((entity, source, baseDamage, dealt, blocked) -> {
            if (!(entity instanceof Villager villager)) return;
            if (!(source.getEntity() instanceof ServerPlayer player)) return;
            if (!(villager.level() instanceof ServerLevel level)) return;

            VillageRegistry reg = level.getAttachedOrCreate(LivingVillages.VILLAGES);
            Village village = reg.getOrCreate(villager.blockPosition());
            String villagerName = ((MemoryHolder) villager).lv_getPersonality().name;
            String playerName = player.getName().getString();

            village.adjustReputation(player.getUUID(), ATTACK_REP_PENALTY);
            village.record(playerName + " attacked " + villagerName + ".");
            level.setAttached(LivingVillages.VILLAGES, reg);

            LivingVillages.LOGGER.info("{} standing in {} is now {} (attacked {})",
                    playerName, village.name(), village.reputationOf(player.getUUID()), villagerName);
        });
    }

    /** Killing a hostile mob near a village earns goodwill (Feature 12 ↔ 13). */
    private static void registerDefense() {
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, damageSource) -> {
            if (!(entity instanceof Enemy)) return;
            if (!(damageSource.getEntity() instanceof ServerPlayer player)) return;
            if (!(entity.level() instanceof ServerLevel level)) return;

            VillageRegistry reg = level.getAttachedOrCreate(LivingVillages.VILLAGES);
            Village village = reg.findNearest(entity.blockPosition(), VillageRegistry.VILLAGE_RADIUS);
            if (village == null) return; // kill wasn't near any village

            String mob = entity.getName().getString();
            String playerName = player.getName().getString();
            village.adjustReputation(player.getUUID(), DEFENSE_REP_REWARD);
            village.record(playerName + " defended the village from a " + mob + ".");
            level.setAttached(LivingVillages.VILLAGES, reg);
        });
    }

    /** Sneak-right-clicking a villager with an item gifts it: goodwill + the villager remembers. */
    private static void registerGifts() {
        UseEntityCallback.EVENT.register((player, level, hand, entity, hitResult) -> {
            if (!(entity instanceof Villager villager)) return InteractionResult.PASS;
            if (hand != InteractionHand.MAIN_HAND)      return InteractionResult.PASS;
            if (!player.isShiftKeyDown())               return InteractionResult.PASS;

            ItemStack held = player.getItemInHand(hand);
            if (held.isEmpty()) return InteractionResult.PASS;

            // It's a gift. Apply effects server-side; SUCCESS on both sides suppresses the trade GUI.
            if (level instanceof ServerLevel serverLevel) {
                int value = giftValue(held);
                String itemName = held.getHoverName().getString();
                held.shrink(1);

                VillageRegistry reg = serverLevel.getAttachedOrCreate(LivingVillages.VILLAGES);
                Village village = reg.getOrCreate(villager.blockPosition());
                String villagerName = ((MemoryHolder) villager).lv_getPersonality().name;
                String playerName = player.getName().getString();

                village.adjustReputation(player.getUUID(), value);
                village.record(playerName + " gave " + villagerName + " " + itemName + ".");
                serverLevel.setAttached(LivingVillages.VILLAGES, reg);

                ((MemoryHolder) villager).lv_getMemory()
                        .rememberFact(playerName + " gave you " + itemName + " as a gift.");

                player.sendSystemMessage(Component.literal(
                        "§b" + villagerName + "§r: Thank you, " + playerName + "!"));
            }
            return InteractionResult.SUCCESS;
        });
    }

    private static int giftValue(ItemStack stack) {
        String cat = VillageEconomy.categoryOf(stack.getItem());
        if ("emeralds".equals(cat)) return 5;
        if ("iron".equals(cat))     return 3;
        if ("food".equals(cat))     return 2;
        return 1;
    }
}
