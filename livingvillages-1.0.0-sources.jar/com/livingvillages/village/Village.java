package com.livingvillages.village;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.BlockPos;

import java.util.*;

/**
 * A village is a proximity cluster of villagers that shares state the way a real
 * community would: a collective chronicle of major events (Feature 6), a per-player
 * reputation ledger (Feature 13), and an economy ledger of tracked resources
 * (Feature 9). Population and leadership are derived live from nearby villagers
 * rather than stored, so they never go stale.
 *
 * Instances persist as part of {@link VillageRegistry}, attached to the ServerLevel.
 */
public class Village {

    private static final int MAX_CHRONICLE = 60;
    public static final int REP_MIN = -100;
    public static final int REP_MAX = 100;

    private final UUID id;
    private String name;
    private BlockPos center;
    private final Map<String, Integer> resources  = new HashMap<>();
    private final Deque<String> chronicle         = new ArrayDeque<>();
    private final Map<UUID, Integer> reputation   = new HashMap<>();
    private final Map<UUID, Integer> relations = new HashMap<>();   // other village id -> standing (-100..100)
    private int raidCount;
    private long lastRaidEpoch;
    private int wallProgress;   // perimeter columns of the defensive wall built so far
    private int wallRadius;     // wall half-width, sized to enclose the village's buildings (0 = not sized)
    private VillageCulture culture;   // specialized culture (null until derived from terrain)
    private int mineDepth;   // how many steps the village's mine staircase has been dug
    private BlockPos mineHead = BlockPos.ZERO;  // current bottom of the (possibly bent) shaft; ZERO = no mine
    private int mineDir;                        // packed dig direction (0=none,1=N,2=E,3=S,4=W) — saves a codec slot
    private final Map<String, Integer> upgrades = new HashMap<>();   // counts of constructed assets: houses/streets/warehouses

    public Village(UUID id, String name, BlockPos center) {
        this.id = id;
        this.name = name;
        this.center = center;
    }

    public static final Codec<Village> CODEC = RecordCodecBuilder.create(inst -> inst.group(
            Codec.STRING.fieldOf("id").forGetter(v -> v.id.toString()),
            Codec.STRING.fieldOf("name").forGetter(v -> v.name),
            BlockPos.CODEC.fieldOf("center").forGetter(v -> v.center),
            Codec.unboundedMap(Codec.STRING, Codec.INT).optionalFieldOf("resources", Map.of())
                    .forGetter(v -> v.resources),
            Codec.STRING.listOf().optionalFieldOf("chronicle", List.of())
                    .forGetter(v -> new ArrayList<>(v.chronicle)),
            Codec.unboundedMap(Codec.STRING, Codec.INT).optionalFieldOf("reputation", Map.of())
                    .forGetter(Village::reputationAsStrings),
            Codec.INT.optionalFieldOf("raids", 0).forGetter(v -> v.raidCount),
            Codec.LONG.optionalFieldOf("lastRaid", 0L).forGetter(v -> v.lastRaidEpoch),
            Codec.INT.optionalFieldOf("mineDepth", 0).forGetter(v -> v.mineDepth),
            BlockPos.CODEC.optionalFieldOf("mineHead", BlockPos.ZERO).forGetter(v -> v.mineHead),
            Codec.INT.optionalFieldOf("mineDir", 0).forGetter(v -> v.mineDir),
            Codec.unboundedMap(Codec.STRING, Codec.INT).optionalFieldOf("relations", Map.of())
                    .forGetter(Village::relationsAsStrings),
            Codec.INT.optionalFieldOf("wallProgress", 0).forGetter(v -> v.wallProgress),
            Codec.STRING.optionalFieldOf("culture", "").forGetter(v -> v.culture == null ? "" : v.culture.name()),
            Codec.INT.optionalFieldOf("wallRadius", 0).forGetter(v -> v.wallRadius),
            Codec.unboundedMap(Codec.STRING, Codec.INT).optionalFieldOf("upgrades", Map.of())
                    .forGetter(v -> v.upgrades)
    ).apply(inst, Village::fromData));

    private static Village fromData(String id, String name, BlockPos center,
                                    Map<String, Integer> resources, List<String> chronicle,
                                    Map<String, Integer> reputation, int raids, long lastRaid,
                                    int mineDepth, BlockPos mineHead, int mineDir,
                                    Map<String, Integer> relations, int wallProgress, String culture,
                                    int wallRadius, Map<String, Integer> upgrades) {
        Village v = new Village(UUID.fromString(id), name, center);
        v.resources.putAll(resources);
        chronicle.forEach(v::record);
        reputation.forEach((k, val) -> v.reputation.put(UUID.fromString(k), val));
        v.raidCount = raids;
        v.lastRaidEpoch = lastRaid;
        v.mineDepth = mineDepth;
        v.mineHead = mineHead;
        v.mineDir = mineDir;
        relations.forEach((k, val) -> v.relations.put(UUID.fromString(k), val));
        v.wallProgress = wallProgress;
        v.wallRadius = wallRadius;
        v.upgrades.putAll(upgrades);
        if (!culture.isEmpty()) {
            try { v.culture = VillageCulture.valueOf(culture); } catch (IllegalArgumentException ignored) {}
        }
        return v;
    }

    private static Map<String, Integer> reputationAsStrings(Village v) {
        Map<String, Integer> out = new HashMap<>();
        v.reputation.forEach((k, val) -> out.put(k.toString(), val));
        return out;
    }

    public UUID id()        { return id; }
    public String name()    { return name; }
    public BlockPos center(){ return center; }
    public void setCenter(BlockPos c) { this.center = c; }

    // ---- Shared village memory (Feature 6) ----

    public void record(String event) {
        if (event == null || event.isBlank()) return;
        chronicle.addLast(event.trim());
        while (chronicle.size() > MAX_CHRONICLE) chronicle.removeFirst();
    }

    public List<String> chronicle() { return new ArrayList<>(chronicle); }

    public String recentChronicle(int limit) {
        List<String> all = chronicle();
        int start = Math.max(0, all.size() - limit);
        List<String> recent = all.subList(start, all.size());
        return recent.isEmpty() ? "(nothing notable has happened yet)" : String.join("\n", recent);
    }

    // ---- Reputation (Feature 13) ----

    public int reputationOf(UUID player) { return reputation.getOrDefault(player, 0); }

    public void adjustReputation(UUID player, int delta) {
        int updated = Math.max(REP_MIN, Math.min(REP_MAX, reputationOf(player) + delta));
        reputation.put(player, updated);
    }

    public static String reputationLabel(int rep) {
        if (rep <= -60) return "reviled";
        if (rep <= -20) return "distrusted";
        if (rep <   20) return "neutral";
        if (rep <   60) return "liked";
        return "revered";
    }

    // ---- Diplomacy (village-to-village relations) ----

    public int relationWith(UUID otherVillage) { return relations.getOrDefault(otherVillage, 0); }

    public void adjustRelation(UUID otherVillage, int delta) {
        int updated = Math.max(REP_MIN, Math.min(REP_MAX, relationWith(otherVillage) + delta));
        relations.put(otherVillage, updated);
    }

    public Map<UUID, Integer> relations() { return new HashMap<>(relations); }

    public boolean isAlly(UUID otherVillage)  { return relationWith(otherVillage) >= 60; }
    public boolean isRival(UUID otherVillage) { return relationWith(otherVillage) <= -20; }

    public static String relationLabel(int rel) {
        if (rel <= -60) return "at war";
        if (rel <= -20) return "rivals";
        if (rel <   20) return "neutral";
        if (rel <   60) return "friendly";
        return "allied";
    }

    private static Map<String, Integer> relationsAsStrings(Village v) {
        Map<String, Integer> out = new HashMap<>();
        v.relations.forEach((k, val) -> out.put(k.toString(), val));
        return out;
    }

    // ---- Adaptive defense (Feature 12) ----

    public void recordRaid() {
        raidCount++;
        lastRaidEpoch = System.currentTimeMillis();
    }

    public int raidCount() { return raidCount; }

    public int wallProgress()             { return wallProgress; }
    public void setWallProgress(int n)    { this.wallProgress = n; }
    public int wallRadius()               { return wallRadius; }
    public void setWallRadius(int r)      { this.wallRadius = r; }

    public VillageCulture culture()              { return culture; }
    public void setCulture(VillageCulture c)     { this.culture = c; }

    public String threatSummary() {
        if (lastRaidEpoch == 0L) return "none on record";
        long minutes = (System.currentTimeMillis() - lastRaidEpoch) / 60000L;
        String when = minutes <= 0 ? "moments ago" : minutes + " min ago";
        return "last raid " + when + " (" + raidCount + " total)";
    }

    // ---- Mine (the village's single deepening staircase) ----

    public int mineDepth()      { return mineDepth; }
    public int mineDx() { return switch (mineDir) { case 2 -> 1; case 4 -> -1; default -> 0; }; }
    public int mineDz() { return switch (mineDir) { case 1 -> -1; case 3 -> 1; default -> 0; }; }
    /** Current bottom of the shaft, or null if no mine has been started yet. */
    public BlockPos mineHead()  { return mineHead.equals(BlockPos.ZERO) ? null : mineHead; }

    public void setMineState(BlockPos head, int dx, int dz, int depth) {
        this.mineHead = head;
        if (dx == 0 && dz == -1)      this.mineDir = 1;     // N
        else if (dx == 1 && dz == 0)  this.mineDir = 2;     // E
        else if (dx == 0 && dz == 1)  this.mineDir = 3;     // S
        else if (dx == -1 && dz == 0) this.mineDir = 4;     // W
        else                          this.mineDir = 0;     // none
        this.mineDepth = Math.max(this.mineDepth, depth);
    }

    // ---- Upgrades / civic improvements ----

    public int  upgrade(String key)             { return upgrades.getOrDefault(key, 0); }
    public void incrementUpgrade(String key)    { upgrades.merge(key, 1, Integer::sum); }
    public int  houses()                        { return upgrade("houses"); }
    public int  streets()                       { return upgrade("streets"); }
    public int  warehouses()                    { return upgrade("warehouses"); }

    /** Human-readable list of what the village has built — surfaced in /village and /talk. */
    public String upgradeSummary() {
        StringBuilder sb = new StringBuilder();
        int h = houses(), w = warehouses(), s = streets();
        sb.append(h).append(" house").append(h == 1 ? "" : "s");
        sb.append(", ").append(w).append(" warehouse").append(w == 1 ? "" : "s");
        sb.append(", ").append(s).append(" street").append(s == 1 ? "" : "s");
        if (mineDepth > 0)     sb.append(", a mine ").append(mineDepth).append(" steps deep");
        if (wallProgress > 0)  sb.append(", a defensive wall");
        return sb.toString();
    }

    // ---- Economy ledger (Feature 9) ----

    public int resource(String key)                 { return resources.getOrDefault(key, 0); }
    public void setResource(String key, int amount) { resources.put(key, Math.max(0, amount)); }
    public void addResource(String key, int delta)  { setResource(key, resource(key) + delta); }
    public Map<String, Integer> resources()         { return new HashMap<>(resources); }

    /** Overwrites the ledger with a fresh snapshot, dropping categories that are now zero/absent. */
    public void replaceResources(Map<String, Integer> snapshot) {
        resources.clear();
        snapshot.forEach((k, v) -> {
            if (v != null && v > 0) resources.put(k, v);
        });
    }

    public String resourceSummary() {
        if (resources.isEmpty()) return "nothing notable in storage";
        StringBuilder sb = new StringBuilder();
        resources.forEach((k, v) -> sb.append(v).append(' ').append(k).append(", "));
        String s = sb.toString();
        return s.endsWith(", ") ? s.substring(0, s.length() - 2) : s;
    }

    /** Identifies the staple in shortest supply, for the report's "concern" line (Feature 9). */
    public String resourceConcern() {
        String[] staples = {"food", "wood", "stone", "iron"};
        String lowest = staples[0];
        int lowestVal = Integer.MAX_VALUE;
        for (String s : staples) {
            int v = resource(s);
            if (v < lowestVal) {
                lowestVal = v;
                lowest = s;
            }
        }
        if (lowestVal == 0)  return "no " + lowest + " in storage";
        if (lowestVal < 16)  return "low " + lowest + " (" + lowestVal + ")";
        return "none";
    }
}
