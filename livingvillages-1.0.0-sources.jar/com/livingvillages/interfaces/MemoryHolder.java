package com.livingvillages.interfaces;

import com.livingvillages.lineage.VillagerLineage;
import com.livingvillages.memory.VillagerMemory;
import com.livingvillages.personality.VillagerPersonality;

/**
 * Implemented by VillagerMemoryMixin — lets other code access persisted
 * memory, lineage, and personality without depending on the mixin class directly.
 *
 * Usage:  ((MemoryHolder) villager).lv_getMemory()
 */
public interface MemoryHolder {
    VillagerMemory lv_getMemory();
    VillagerPersonality lv_getPersonality();
    VillagerLineage lv_getLineage();
}
