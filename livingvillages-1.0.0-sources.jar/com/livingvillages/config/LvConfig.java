package com.livingvillages.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.livingvillages.LivingVillages;
import net.fabricmc.loader.api.FabricLoader;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public class LvConfig {

    public enum Backend { ANTHROPIC, OLLAMA, OPENAI_COMPAT }

    public Backend backend                 = Backend.OLLAMA;
    public String  model                   = "llama3.2:3b";
    public String  apiKey                  = "";
    public String  baseUrl                 = "http://localhost:11434";
    public int     villagerCooldownSeconds = 5;
    public int     maxConcurrentRequests   = 2;
    public int     timeoutSeconds          = 30;

    private static LvConfig instance;

    public static LvConfig get() {
        if (instance == null) instance = load();
        return instance;
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static Path configPath() {
        return FabricLoader.getInstance().getConfigDir().resolve("livingvillages.json");
    }

    private static LvConfig load() {
        Path path = configPath();
        if (Files.exists(path)) {
            try (Reader r = new InputStreamReader(
                    new FileInputStream(path.toFile()), StandardCharsets.UTF_8)) {
                LvConfig cfg = GSON.fromJson(r, LvConfig.class);
                if (cfg != null) {
                    LivingVillages.LOGGER.info("Config loaded. Backend: {}, Model: {}",
                            cfg.backend, cfg.model);
                    return cfg;
                }
            } catch (Exception e) {
                LivingVillages.LOGGER.error("Failed to read config: {}", e.getMessage());
            }
        }
        LvConfig defaults = new LvConfig();
        defaults.save();
        LivingVillages.LOGGER.info("Created default config at {}", path);
        return defaults;
    }

    public void save() {
        try {
            Path path = configPath();
            Files.createDirectories(path.getParent());
            try (Writer w = new OutputStreamWriter(
                    new FileOutputStream(path.toFile()), StandardCharsets.UTF_8)) {
                GSON.toJson(this, w);
            }
        } catch (Exception e) {
            LivingVillages.LOGGER.error("Failed to save config: {}", e.getMessage());
        }
    }

    public boolean hasApiKey() {
        return apiKey != null && !apiKey.isBlank();
    }

    public String resolvedBaseUrl() {
        if (baseUrl != null && !baseUrl.isBlank()) {
            return baseUrl.replaceAll("/+$", "");
        }
        return switch (backend) {
            case ANTHROPIC     -> "https://api.anthropic.com";
            case OLLAMA        -> "http://localhost:11434";
            case OPENAI_COMPAT -> "https://api.openai.com";
        };
    }
}