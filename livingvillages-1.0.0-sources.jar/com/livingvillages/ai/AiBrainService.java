package com.livingvillages.ai;

import com.livingvillages.LivingVillages;
import com.livingvillages.ai.provider.*;
import com.livingvillages.config.LvConfig;
import okhttp3.OkHttpClient;

import java.util.concurrent.*;
import java.util.function.Consumer;

public class AiBrainService {

    private static final AiBrainService INSTANCE = new AiBrainService();
    private AiProvider provider;
    private ExecutorService executor;
    private final ConcurrentHashMap<String, Long> lastCallTime = new ConcurrentHashMap<>();

    private AiBrainService() {}
    public static AiBrainService getInstance() { return INSTANCE; }

    public void init() {
        LvConfig cfg = LvConfig.get();

        if (cfg.backend != LvConfig.Backend.OLLAMA && !cfg.hasApiKey()) {
            LivingVillages.LOGGER.warn("Backend {} requires an apiKey in config/livingvillages.json. AI disabled.", cfg.backend);
            return;
        }

        OkHttpClient http = new OkHttpClient.Builder()
                .callTimeout(cfg.timeoutSeconds, TimeUnit.SECONDS)
                .build();

        provider = switch (cfg.backend) {
            case ANTHROPIC     -> new AnthropicProvider(http, cfg);
            case OLLAMA        -> new OllamaProvider(http, cfg);
            case OPENAI_COMPAT -> new OpenAiCompatProvider(http, cfg);
        };
        executor = Executors.newFixedThreadPool(cfg.maxConcurrentRequests);
        LivingVillages.LOGGER.info("AI ready. Backend: {}", provider.describe());
    }

    public void think(String villagerUuid, String prompt,
                      Consumer<VillagerThought> onResponse,
                      Consumer<String> onError) {
        if (provider == null) { onError.accept("No AI provider configured"); return; }

        long cooldownMs = LvConfig.get().villagerCooldownSeconds * 1000L;
        long now = System.currentTimeMillis();
        Long last = lastCallTime.get(villagerUuid);
        if (last != null && (now - last) < cooldownMs) return;
        lastCallTime.put(villagerUuid, now);

        executor.submit(() -> {
            try {
                onResponse.accept(VillagerThought.parse(provider.complete(prompt)));
            } catch (Exception e) {
                LivingVillages.LOGGER.error("AI call failed for {}: {}", villagerUuid, e.getMessage());
                onError.accept(e.getMessage());
            }
        });
    }

    public boolean isReady() { return provider != null; }
}