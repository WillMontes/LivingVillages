package com.livingvillages.ai.provider;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.livingvillages.config.LvConfig;
import okhttp3.*;
import java.io.IOException;

public class AnthropicProvider implements AiProvider {

    private static final MediaType JSON_TYPE = MediaType.get("application/json; charset=utf-8");
    private final OkHttpClient http;
    private final Gson gson = new Gson();
    private final LvConfig cfg;

    public AnthropicProvider(OkHttpClient http, LvConfig cfg) {
        this.http = http; this.cfg = cfg;
    }

    @Override
    public String complete(String prompt) throws Exception {
        JsonObject body = new JsonObject();
        body.addProperty("model", cfg.model);
        body.addProperty("max_tokens", 256);
        JsonArray messages = new JsonArray();
        JsonObject msg = new JsonObject();
        msg.addProperty("role", "user");
        msg.addProperty("content", prompt);
        messages.add(msg);
        body.add("messages", messages);

        Request request = new Request.Builder()
                .url(cfg.resolvedBaseUrl() + "/v1/messages")
                .header("x-api-key", cfg.apiKey)
                .header("anthropic-version", "2023-06-01")
                .header("content-type", "application/json")
                .post(RequestBody.create(gson.toJson(body), JSON_TYPE))
                .build();

        try (Response response = http.newCall(request).execute()) {
            if (!response.isSuccessful())
                throw new IOException("HTTP " + response.code() + ": " + response.body().string());
            JsonObject json = gson.fromJson(response.body().charStream(), JsonObject.class);
            return json.getAsJsonArray("content").get(0)
                    .getAsJsonObject().get("text").getAsString();
        }
    }

    @Override public String describe() {
        return "Anthropic (" + cfg.model + ")";
    }
}