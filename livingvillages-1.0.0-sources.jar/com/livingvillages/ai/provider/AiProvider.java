package com.livingvillages.ai.provider;

public interface AiProvider {
    String complete(String prompt) throws Exception;
    String describe();
}