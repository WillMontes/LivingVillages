package com.livingvillages.ai.provider;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.livingvillages.config.LvConfig;
import okhttp3.*;
import java.io.IOException;

public class OllamaProvider implements AiProvider {

    private static final MediaType JSON_TYPE = MediaType.get("application/json; charset=utf-8");
    private final OkHttpClient http;
    private final Gson gson = new Gson();
    private final LvConfig cfg;

    public OllamaProvider(OkHttpClient http, LvConfig cfg) {
        this.http = http; this.cfg = cfg;
    }

    @Override
    public String complete(String prompt) throws Exception {
        JsonObject body = new JsonObject();
        body.addProperty("model", cfg.model);
        body.addProperty("prompt", prompt);
        body.addProperty("stream", false);

        Request request = new Request.Builder()
                .url(cfg.resolvedBaseUrl() + "/api/generate")
                .header("content-type", "application/json")
                .post(RequestBody.create(gson.toJson(body), JSON_TYPE))
                .build();

        try (Response response = http.newCall(request).execute()) {
            if (!response.isSuccessful())
                throw new IOException("HTTP " + response.code() + ": " + response.body().string());
            JsonObject json = gson.fromJson(response.body().charStream(), JsonObject.class);
            return json.get("response").getAsString();
        }
    }

    @Override public String describe() {
        return "Ollama (" + cfg.model + " @ " + cfg.resolvedBaseUrl() + ")";
    }
}