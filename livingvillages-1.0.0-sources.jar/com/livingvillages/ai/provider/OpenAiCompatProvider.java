package com.livingvillages.ai.provider;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.livingvillages.config.LvConfig;
import okhttp3.*;
import java.io.IOException;

public class OpenAiCompatProvider implements AiProvider {

    private static final MediaType JSON_TYPE = MediaType.get("application/json; charset=utf-8");
    private final OkHttpClient http;
    private final Gson gson = new Gson();
    private final LvConfig cfg;

    public OpenAiCompatProvider(OkHttpClient http, LvConfig cfg) {
        this.http = http; this.cfg = cfg;
    }

    @Override
    public String complete(String prompt) throws Exception {
        JsonObject body = new JsonObject();
        body.addProperty("model", cfg.model);
        body.addProperty("max_tokens", 256);

        JsonArray messages = new JsonArray();
        JsonObject system = new JsonObject();
        system.addProperty("role", "system");
        system.addProperty("content", "You are a Minecraft villager. Always respond with valid JSON only.");
        messages.add(system);
        JsonObject user = new JsonObject();
        user.addProperty("role", "user");
        user.addProperty("content", prompt);
        messages.add(user);
        body.add("messages", messages);

        JsonObject fmt = new JsonObject();
        fmt.addProperty("type", "json_object");
        body.add("response_format", fmt);

        Request.Builder req = new Request.Builder()
                .url(cfg.resolvedBaseUrl() + "/v1/chat/completions")
                .header("content-type", "application/json");
        if (cfg.hasApiKey()) req.header("Authorization", "Bearer " + cfg.apiKey);
        req.post(RequestBody.create(gson.toJson(body), JSON_TYPE));

        try (Response response = http.newCall(req.build()).execute()) {
            if (!response.isSuccessful())
                throw new IOException("HTTP " + response.code() + ": " + response.body().string());
            JsonObject json = gson.fromJson(response.body().charStream(), JsonObject.class);
            return json.getAsJsonArray("choices").get(0).getAsJsonObject()
                    .getAsJsonObject("message").get("content").getAsString();
        }
    }

    @Override public String describe() {
        return "OpenAI-compat (" + cfg.model + " @ " + cfg.resolvedBaseUrl() + ")";
    }
}