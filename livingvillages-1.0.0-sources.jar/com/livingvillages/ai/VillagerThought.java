package com.livingvillages.ai;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class VillagerThought {

    public enum Action {
        IDLE, GATHER_WOOD, MINE_STONE, HARVEST_CROPS, BUILD, BUILD_HOUSE, LAY_STREET,
        EXCAVATE, FORTIFY, EXPLORE, PATROL, FLEE, REPAIR, TRADE, UNKNOWN
    }

    public final String speech;
    public final String thought;
    public final Action action;
    public final String target;
    /** Durable facts the villager wants to remember long-term (player names, promises, etc.). */
    public final List<String> memory;

    private static final Gson GSON = new Gson();

    public VillagerThought(String speech, String thought, Action action, String target) {
        this(speech, thought, action, target, List.of());
    }

    public VillagerThought(String speech, String thought, Action action, String target, List<String> memory) {
        this.speech  = speech  != null ? speech  : "";
        this.thought = thought != null ? thought : "";
        this.action  = action  != null ? action  : Action.IDLE;
        this.target  = target  != null ? target  : "";
        this.memory  = memory  != null ? memory  : List.of();
    }

    public static VillagerThought parse(String rawText) {
        String cleaned = rawText.trim()
                .replaceAll("(?s)^```json\\s*", "")
                .replaceAll("(?s)^```\\s*",     "")
                .replaceAll("(?s)\\s*```$",     "");

        // 1. Try parsing the whole response as one JSON object (happy path)
        try {
            JsonObject obj = GSON.fromJson(cleaned, JsonObject.class);
            return fromJson(obj);
        } catch (JsonSyntaxException | IllegalStateException ignored) {}

        // 2. Model returned multiple JSON objects — extract and merge them
        JsonObject merged = new JsonObject();
        Matcher m = Pattern.compile("\\{[^{}]*\\}").matcher(cleaned);
        while (m.find()) {
            try {
                JsonObject part = GSON.fromJson(m.group(), JsonObject.class);
                for (Map.Entry<String, com.google.gson.JsonElement> entry : part.entrySet()) {
                    if (!merged.has(entry.getKey())) {
                        merged.add(entry.getKey(), entry.getValue());
                    }
                }
            } catch (JsonSyntaxException ignored) {}
        }
        if (merged.size() > 0) {
            return fromJson(merged);
        }

        // 3. No JSON found at all — treat entire response as speech
        return new VillagerThought(rawText, "", Action.IDLE, "");
    }

    private static VillagerThought fromJson(JsonObject obj) {
        return new VillagerThought(
                getString(obj, "speech"),
                getString(obj, "thought"),
                parseAction(getString(obj, "action")),
                getString(obj, "target"),
                getStringList(obj, "memory")
        );
    }

    /**
     * Reads the "memory" field as a list of facts. Small models are inconsistent here:
     * they may return an array, a single string, or even a nested object. Handle all of
     * them rather than throwing, so a malformed field never sinks the whole response.
     */
    private static List<String> getStringList(JsonObject obj, String key) {
        List<String> out = new ArrayList<>();
        if (obj == null || !obj.has(key) || obj.get(key).isJsonNull()) return out;
        JsonElement el = obj.get(key);
        if (el.isJsonArray()) {
            for (JsonElement item : el.getAsJsonArray()) {
                addFact(out, item);
            }
        } else {
            addFact(out, el);
        }
        return out;
    }

    private static void addFact(List<String> out, JsonElement el) {
        if (el == null || el.isJsonNull()) return;
        String s = el.isJsonPrimitive() ? el.getAsString() : el.toString();
        if (s != null && !s.isBlank()) out.add(s.trim());
    }

    private static String getString(JsonObject obj, String key) {
        if (obj == null || !obj.has(key)) return "";
        JsonElement el = obj.get(key);
        if (el.isJsonNull()) return "";
        // Small models sometimes nest an object/array where a string is expected.
        // getAsString() throws UnsupportedOperationException("JsonObject") on those,
        // so only call it for primitives and stringify anything else.
        if (el.isJsonPrimitive()) return el.getAsString();
        return el.toString();
    }

    private static Action parseAction(String raw) {
        if (raw == null || raw.isBlank()) return Action.IDLE;
        try { return Action.valueOf(raw.toUpperCase()); }
        catch (IllegalArgumentException e) { return Action.UNKNOWN; }
    }

    public boolean hasSpeech() { return !speech.isBlank(); }
}