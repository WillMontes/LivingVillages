package com.livingvillages.personality;

import net.minecraft.nbt.CompoundTag;
import java.util.Random;
import java.util.UUID;

public class VillagerPersonality {

    private static final String[] ARCHETYPES = {
            "Builder","Farmer","Merchant","Explorer","Guard",
            "Scholar","Healer","Elder","Gossip","Wanderer"
    };
    private static final String[] TRAITS = {
            "cautious","optimistic","grumpy","curious","proud",
            "generous","suspicious","cheerful","pragmatic","stubborn"
    };
    private static final String[] NAMES = {
            "Aldric","Bram","Celia","Doven","Elara","Finn","Greta",
            "Hazel","Idris","Jana","Kael","Lira","Mira","Noel","Petra"
    };

    public final String archetype, traitOne, traitTwo, name;

    public VillagerPersonality(String archetype, String traitOne, String traitTwo, String name) {
        this.archetype = archetype; this.traitOne = traitOne;
        this.traitTwo  = traitTwo; this.name     = name;
    }

    public static VillagerPersonality random(UUID seed) {
        Random rng = new Random(seed.getLeastSignificantBits());
        String arch = ARCHETYPES[rng.nextInt(ARCHETYPES.length)];
        String t1   = TRAITS[rng.nextInt(TRAITS.length)];
        String t2; do { t2 = TRAITS[rng.nextInt(TRAITS.length)]; } while (t2.equals(t1));
        return new VillagerPersonality(arch, t1, t2, NAMES[rng.nextInt(NAMES.length)]);
    }

    public String toPromptPreamble() {
        return String.format(
                "You are %s, a Minecraft villager. Archetype: %s. Traits: %s, %s. " +
                        "You MUST respond with exactly ONE JSON object and nothing else — no extra text, no second JSON block. " +
                        "Format: {\"speech\":\"...\",\"thought\":\"...\",\"action\":\"IDLE|GATHER_WOOD|MINE_STONE|HARVEST_CROPS|BUILD|BUILD_HOUSE|LAY_STREET|EXCAVATE|FORTIFY|EXPLORE|PATROL|FLEE|REPAIR|TRADE\",\"target\":\"\",\"memory\":[\"...\"]}. " +
                        "All keys must be in the same single object. Speech is 1-2 sentences max. Stay in character. " +
                        "\"memory\" is an array of short facts worth remembering forever — the player's preferred name, promises made, " +
                        "trades agreed, things they like or dislike. Add a fact ONLY when you learn something new and lasting; " +
                        "otherwise return an empty array []. Write each fact as a brief standalone sentence. " +
                        "IMPORTANT: if the player asks you to do a task you can perform — gather wood (GATHER_WOOD), mine stone (MINE_STONE), " +
                        "harvest crops (HARVEST_CROPS), build a warehouse/storehouse (BUILD), build a new HOUSE for the village (BUILD_HOUSE), " +
                        "lay a cobblestone STREET radiating from the center (LAY_STREET), dig a mine for ore/iron (EXCAVATE), " +
                        "build a defensive wall (FORTIFY), or scout the surrounding lands (EXPLORE) — " +
                        "you MUST set \"action\" to that exact value, not just talk about it.",
                name, archetype, traitOne, traitTwo);
    }

    public void writeNbt(CompoundTag tag) {
        tag.putString("LVArchetype", archetype);
        tag.putString("LVTraitOne",  traitOne);
        tag.putString("LVTraitTwo",  traitTwo);
        tag.putString("LVName",      name);
    }

    public static VillagerPersonality readNbt(CompoundTag tag) {
        if (!tag.contains("LVArchetype")) return null;
        return new VillagerPersonality(
                tag.getString("LVArchetype").orElse(""), tag.getString("LVTraitOne").orElse(""),
                tag.getString("LVTraitTwo").orElse(""),  tag.getString("LVName").orElse(""));
    }
}