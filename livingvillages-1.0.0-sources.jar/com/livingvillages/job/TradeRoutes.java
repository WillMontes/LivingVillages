package com.livingvillages.job;

import com.livingvillages.LivingVillages;
import com.livingvillages.village.Village;
import com.livingvillages.village.VillageRegistry;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.phys.AABB;

import java.util.List;

/**
 * Future feature "Regional Trade": periodically pairs up nearby loaded villages and, when
 * one has a surplus of a resource the other lacks, dispatches a {@link CaravanJob} to carry
 * some over. The village behaves as part of a connected region, not in isolation.
 */
public final class TradeRoutes {

    private static final int    CHECK_INTERVAL   = 1200;        // ~60s between trade sweeps
    private static final double LOADED_RADIUS_SQ = 128.0 * 128.0;
    private static final double CARAVAN_RANGE_SQ = 256.0 * 256.0;
    private static final int    SURPLUS_MIN       = 64;   // a village will share a resource above this
    private static final int    ALLY_SURPLUS_MIN  = 48;   // ...lower bar for an allied village
    private static final int    SHORTAGE_MAX      = 16;   // ...with one that has less than this
    private static final int    TRANSFER          = 32;
    private static final String[] CATEGORIES = {"food", "wood", "stone", "iron"};

    private static int ticks;

    private TradeRoutes() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (++ticks < CHECK_INTERVAL) return;
            ticks = 0;
            for (ServerLevel level : server.getAllLevels()) sweep(level);
        });
        LivingVillages.LOGGER.info("Regional trade routes enabled.");
    }

    private static void sweep(ServerLevel level) {
        List<ServerPlayer> players = level.players();
        if (players.isEmpty()) return;
        List<Village> villages = level.getAttachedOrCreate(LivingVillages.VILLAGES).all();

        for (Village from : villages) {
            if (!nearAnyPlayer(from.center(), players)) continue;
            if (anyoneBusy(level, from.center())) continue;          // its workers are occupied
            for (Village to : villages) {
                if (from == to) continue;
                if (from.center().distSqr(to.center()) > CARAVAN_RANGE_SQ) continue;
                if (!nearAnyPlayer(to.center(), players)) continue;
                if (from.isRival(to.id())) continue;                         // won't trade with rivals

                int surplusMin = from.isAlly(to.id()) ? ALLY_SURPLUS_MIN : SURPLUS_MIN;
                String cat = tradableCategory(from, to, surplusMin);
                if (cat == null) continue;
                Villager carrier = findIdleVillager(level, from.center());
                if (carrier == null) break;                          // nobody free in 'from'

                int amount = Math.min(TRANSFER, from.resource(cat) - SHORTAGE_MAX);
                VillagerJobs.startCaravan(level, carrier, from.center(), from.name(),
                        to.center(), to.name(), cat, amount);
                LivingVillages.LOGGER.info("Caravan dispatched: {} -> {} with {} {}.",
                        from.name(), to.name(), amount, cat);
                break;                                               // one caravan per source per sweep
            }
        }
    }

    private static String tradableCategory(Village from, Village to, int surplusMin) {
        for (String cat : CATEGORIES) {
            if (from.resource(cat) >= surplusMin && to.resource(cat) < SHORTAGE_MAX) return cat;
        }
        return null;
    }

    private static boolean nearAnyPlayer(BlockPos center, List<ServerPlayer> players) {
        for (ServerPlayer p : players) {
            if (center.distSqr(p.blockPosition()) <= LOADED_RADIUS_SQ) return true;
        }
        return false;
    }

    private static boolean anyoneBusy(ServerLevel level, BlockPos center) {
        for (Villager v : villagersNear(level, center)) {
            if (VillagerJobs.isBusy(v)) return true;
        }
        return false;
    }

    private static Villager findIdleVillager(ServerLevel level, BlockPos center) {
        Villager best = null;
        double bestSq = Double.MAX_VALUE;
        for (Villager v : villagersNear(level, center)) {
            if (VillagerJobs.isBusy(v) || v.isBaby()) continue;
            double sq = center.distSqr(v.blockPosition());
            if (sq < bestSq) {
                bestSq = sq;
                best = v;
            }
        }
        return best;
    }

    private static List<Villager> villagersNear(ServerLevel level, BlockPos center) {
        AABB box = new AABB(center).inflate(VillageRegistry.VILLAGE_RADIUS);
        return level.getEntitiesOfClass(Villager.class, box);
    }
}
