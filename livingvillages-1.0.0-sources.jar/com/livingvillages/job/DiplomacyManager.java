package com.livingvillages.job;

import com.livingvillages.LivingVillages;
import com.livingvillages.village.Village;
import com.livingvillages.village.VillageRegistry;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

import java.util.List;

/**
 * The negative half of diplomacy (trade caravans are the positive half): nearby villages
 * that are BOTH short on the same staple are competing for scarce resources, so their
 * relations sour over time and they can drift into rivalry. Combined with trade goodwill,
 * this makes village relationships swing both ways — helpful neighbours become allies,
 * struggling neighbours become rivals.
 */
public final class DiplomacyManager {

    private static final int    CHECK_INTERVAL   = 1200;          // ~60s between checks
    private static final double LOADED_RADIUS_SQ = 128.0 * 128.0;
    private static final double RANGE_SQ         = 256.0 * 256.0; // villages this close interact
    private static final int    SHORTAGE         = 16;
    private static final int    COMPETE_PENALTY  = -3;
    private static final String[] STAPLES = {"food", "wood", "stone", "iron"};

    private static int ticks;

    private DiplomacyManager() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (++ticks < CHECK_INTERVAL) return;
            ticks = 0;
            for (ServerLevel level : server.getAllLevels()) sweep(level);
        });
        LivingVillages.LOGGER.info("Village diplomacy enabled.");
    }

    private static void sweep(ServerLevel level) {
        List<ServerPlayer> players = level.players();
        if (players.isEmpty()) return;

        VillageRegistry reg = level.getAttachedOrCreate(LivingVillages.VILLAGES);
        List<Village> villages = reg.all();
        boolean changed = false;
        for (int i = 0; i < villages.size(); i++) {
            Village a = villages.get(i);
            if (!nearAnyPlayer(a.center(), players)) continue;
            for (int j = i + 1; j < villages.size(); j++) {
                Village b = villages.get(j);
                if (a.center().distSqr(b.center()) > RANGE_SQ) continue;
                if (!nearAnyPlayer(b.center(), players)) continue;
                if (!competing(a, b)) continue;

                int before = a.relationWith(b.id());
                a.adjustRelation(b.id(), COMPETE_PENALTY);
                b.adjustRelation(a.id(), COMPETE_PENALTY);
                changed = true;
                if (before > -20 && a.relationWith(b.id()) <= -20) {     // crossed into rivalry
                    a.record(a.name() + " and " + b.name() + " have become rivals, competing for scarce resources.");
                    b.record(b.name() + " and " + a.name() + " have become rivals, competing for scarce resources.");
                    LivingVillages.LOGGER.info("{} and {} are now rivals.", a.name(), b.name());
                }
            }
        }
        if (changed) level.setAttached(LivingVillages.VILLAGES, reg);
    }

    private static boolean competing(Village a, Village b) {
        for (String s : STAPLES) {
            if (a.resource(s) < SHORTAGE && b.resource(s) < SHORTAGE) return true;
        }
        return false;
    }

    private static boolean nearAnyPlayer(BlockPos center, List<ServerPlayer> players) {
        for (ServerPlayer p : players) {
            if (center.distSqr(p.blockPosition()) <= LOADED_RADIUS_SQ) return true;
        }
        return false;
    }
}
