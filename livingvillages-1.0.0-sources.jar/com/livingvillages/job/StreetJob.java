package com.livingvillages.job;

import com.livingvillages.LivingVillages;
import com.livingvillages.interfaces.MemoryHolder;
import com.livingvillages.village.Village;
import com.livingvillages.village.VillageEconomy;
import com.livingvillages.village.VillageRegistry;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

/**
 * Lays a cobblestone street radiating from the village center outward in a cardinal
 * direction, with periodic torches for lighting. Each call extends the network by one
 * radial spoke; successive calls pick a fresh direction so the village's road grid
 * grows organically toward each gate.
 */
public class StreetJob implements VillagerJob {

    private enum State { PLAN, LAYING, FINISHED }

    private static final int    LENGTH         = 16;     // tiles laid per spoke
    private static final int    TORCH_SPACING  = 5;
    private static final double SPEED          = 0.6;
    private static final double REACH_SQ       = 6.25;
    private static final int    LEG_TIMEOUT    = 200;
    private static final int    GLOBAL_TIMEOUT = 4000;

    /** Cardinal directions in the order spokes are laid (N, E, S, W). */
    private static final int[][] DIRS = {{0, -1}, {1, 0}, {0, 1}, {-1, 0}};

    private final ServerLevel level;
    private final Villager villager;

    private State state = State.PLAN;
    private BlockPos villageCenter;
    private int dirX, dirZ;
    private int step;
    private int legTicks, totalTicks;

    public StreetJob(ServerLevel level, Villager villager) {
        this.level = level;
        this.villager = villager;
    }

    @Override
    public boolean isFinished() {
        return state == State.FINISHED || villager.isRemoved() || !villager.isAlive();
    }

    @Override
    public void tick() {
        if (isFinished()) return;
        totalTicks++;
        legTicks++;
        if (totalTicks > GLOBAL_TIMEOUT) { state = State.FINISHED; villager.getNavigation().stop(); return; }
        switch (state) {
            case PLAN   -> doPlan();
            case LAYING -> doLaying();
            default     -> { }
        }
    }

    private void doPlan() {
        villageCenter = resolveVillageCenter();
        // Cycle direction by streets already built so successive jobs lay spokes in different cardinals.
        Village v = level.getAttachedOrCreate(LivingVillages.VILLAGES).getOrCreate(villageCenter);
        int[] d = DIRS[Math.floorMod(v.streets(), DIRS.length)];
        dirX = d[0];
        dirZ = d[1];
        step = 1;
        state = State.LAYING;
        legTicks = 0;
    }

    private void doLaying() {
        if (step > LENGTH) { finish(); return; }
        int x = villageCenter.getX() + dirX * step;
        int z = villageCenter.getZ() + dirZ * step;
        int y = surfaceY(x, z);
        BlockPos at = new BlockPos(x, y, z);
        if (!within(at) && legTicks <= LEG_TIMEOUT) { moveTo(at); return; }
        legTicks = 0;

        // Withdraw 1 stone for the tile + clear any vegetation above.
        int got = VillageEconomy.withdraw(level, villageCenter, "stone", 1);
        if (got <= 0) { finish(); return; }
        villager.swing(InteractionHand.MAIN_HAND);
        BlockState surf = level.getBlockState(at);
        if (!surf.isAir() && !isPath(surf)) {
            level.setBlockAndUpdate(at, Blocks.AIR.defaultBlockState());
        }
        level.setBlockAndUpdate(new BlockPos(x, y - 1, z), Blocks.COBBLESTONE.defaultBlockState());

        // Anti-mob lighting along the road.
        if (step % TORCH_SPACING == 0) {
            level.setBlockAndUpdate(new BlockPos(x, y, z), Blocks.TORCH.defaultBlockState());
        }
        step++;
    }

    private void finish() {
        VillageRegistry reg = level.getAttachedOrCreate(LivingVillages.VILLAGES);
        Village v = reg.getOrCreate(villageCenter);
        v.incrementUpgrade("streets");
        v.record(((MemoryHolder) villager).lv_getPersonality().name + " laid a street from "
                + v.name() + " toward " + cardinalName(dirX, dirZ) + ".");
        level.setAttached(LivingVillages.VILLAGES, reg);
        villager.getNavigation().stop();
        state = State.FINISHED;
    }

    private static String cardinalName(int dx, int dz) {
        if (dz < 0) return "the north";
        if (dz > 0) return "the south";
        if (dx > 0) return "the east";
        if (dx < 0) return "the west";
        return "the village edge";
    }

    private static int surfaceY(ServerLevel level, int x, int z) {
        return level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
    }

    private int surfaceY(int x, int z) {
        return surfaceY(level, x, z);
    }

    private static boolean isPath(BlockState bs) {
        String p = BuiltInRegistries.BLOCK.getKey(bs.getBlock()).getPath();
        return p.equals("cobblestone") || p.equals("dirt_path");
    }

    private void moveTo(BlockPos pos) {
        villager.getNavigation().moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, SPEED);
    }

    private boolean within(BlockPos pos) {
        return villager.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) <= REACH_SQ;
    }

    private BlockPos resolveVillageCenter() {
        VillageRegistry reg = level.getAttachedOrCreate(LivingVillages.VILLAGES);
        Village v = reg.getOrCreate(villager.blockPosition());
        level.setAttached(LivingVillages.VILLAGES, reg);
        return v.center();
    }
}
