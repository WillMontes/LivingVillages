package com.livingvillages.job;

import com.livingvillages.LivingVillages;
import com.livingvillages.interfaces.MemoryHolder;
import com.livingvillages.village.Village;
import com.livingvillages.village.VillageEconomy;
import com.livingvillages.village.VillageRegistry;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.ArrayList;
import java.util.List;

/**
 * Feature 8: Intelligent Construction. A villager builds a small storage hut (warehouse)
 * near the village over time: it finds a clear, flat plot (never overwriting existing
 * builds), checks and consumes stored wood (Feature 9 — no wood, no build), walks to the
 * site, and lays the structure block-by-block, finishing with a chest inside.
 *
 * All world interaction is in {@link #tick()} on the server thread.
 */
public class BuildJob implements VillagerJob {

    private enum State { PLAN, GO_TO_SITE, BUILDING, FINISHED }

    private static final int    SIZE           = 5;     // 5x5 footprint (3x3 interior)
    private static final int    WALL_HEIGHT    = 2;
    private static final int    BUILD_INTERVAL = 5;      // ticks between block placements
    private static final double SPEED          = 0.6;
    private static final double SITE_REACH_SQ  = 25.0;
    private static final int    LEG_TIMEOUT    = 400;
    private static final int    GLOBAL_TIMEOUT = 3000;

    private record Placement(BlockPos pos, Block block) {}

    private final ServerLevel level;
    private final Villager villager;

    private State state = State.PLAN;
    private BlockPos villageCenter;
    private BlockPos origin;
    private List<Placement> placements;
    private int index;
    private int intervalCounter;
    private int legTicks;
    private int totalTicks;

    public BuildJob(ServerLevel level, Villager villager) {
        this.level = level;
        this.villager = villager;
    }

    @Override
    public boolean isFinished() {
        return state == State.FINISHED || villager.isRemoved() || !villager.isAlive();
    }

    @Override
    public void tick() {
        if (isFinished()) return;
        totalTicks++;
        legTicks++;
        if (totalTicks > GLOBAL_TIMEOUT) { state = State.FINISHED; return; }

        switch (state) {
            case PLAN       -> doPlan();
            case GO_TO_SITE -> doGoToSite();
            case BUILDING   -> doBuilding();
            default         -> { }
        }
    }

    private void doPlan() {
        villageCenter = resolveVillageCenter();

        origin = findBuildSite(villageCenter);
        if (origin == null) {
            announce("looked for somewhere to build but found no clear, level ground.");
            state = State.FINISHED;
            return;
        }

        placements = warehouse(origin);
        int planks = (int) placements.stream().filter(p -> p.block() == Blocks.OAK_PLANKS).count();
        int woodCost = (planks + 3) / 4;   // ~4 planks per log

        int have = VillageEconomy.scan(level, villageCenter).getOrDefault("wood", 0);
        if (have < woodCost) {
            announce("wants to build a warehouse but needs " + woodCost + " wood (only " + have + " in store).");
            state = State.FINISHED;
            return;
        }

        VillageEconomy.withdraw(level, villageCenter, "wood", woodCost);
        state = State.GO_TO_SITE;
        legTicks = 0;
    }

    private void doGoToSite() {
        BlockPos approach = origin.offset(SIZE / 2, 0, -1);   // just outside the doorway, never inside the build
        if (withinSq(approach, SITE_REACH_SQ) || legTicks > LEG_TIMEOUT) {
            state = State.BUILDING;
            return;
        }
        villager.getNavigation().moveTo(approach.getX() + 0.5, approach.getY(), approach.getZ() + 0.5, SPEED);
    }

    private void doBuilding() {
        if (++intervalCounter < BUILD_INTERVAL) return;
        intervalCounter = 0;

        while (index < placements.size()) {
            Placement p = placements.get(index++);
            if (level.getBlockState(p.pos()).getBlock() == p.block()) continue;  // already correct
            villager.swing(InteractionHand.MAIN_HAND);
            level.setBlockAndUpdate(p.pos(), p.block().defaultBlockState());
            break;
        }
        if (index >= placements.size()) finish();
    }

    private void finish() {
        villager.getNavigation().stop();
        creditWarehouse();
        announce("finished building a warehouse at " + origin.getX() + ", " + origin.getZ() + ".");
        state = State.FINISHED;
    }

    private void creditWarehouse() {
        VillageRegistry reg = level.getAttachedOrCreate(LivingVillages.VILLAGES);
        reg.getOrCreate(villager.blockPosition()).incrementUpgrade("warehouses");
        level.setAttached(LivingVillages.VILLAGES, reg);
    }

    // ---- blueprint ----

    private static List<Placement> warehouse(BlockPos o) {
        List<Placement> list = new ArrayList<>();
        int ox = o.getX(), oy = o.getY(), oz = o.getZ();

        // floor
        for (int dx = 0; dx < SIZE; dx++)
            for (int dz = 0; dz < SIZE; dz++)
                list.add(new Placement(new BlockPos(ox + dx, oy, oz + dz), Blocks.OAK_PLANKS));

        // walls (perimeter), leaving a 1-wide, 2-high doorway on the -Z side
        for (int h = 1; h <= WALL_HEIGHT; h++) {
            for (int dx = 0; dx < SIZE; dx++) {
                for (int dz = 0; dz < SIZE; dz++) {
                    if (dx != 0 && dx != SIZE - 1 && dz != 0 && dz != SIZE - 1) continue; // interior
                    boolean doorway = dx == SIZE / 2 && dz == 0;
                    if (doorway) continue;
                    list.add(new Placement(new BlockPos(ox + dx, oy + h, oz + dz), Blocks.OAK_PLANKS));
                }
            }
        }

        // roof
        for (int dx = 0; dx < SIZE; dx++)
            for (int dz = 0; dz < SIZE; dz++)
                list.add(new Placement(new BlockPos(ox + dx, oy + WALL_HEIGHT + 1, oz + dz), Blocks.OAK_PLANKS));

        // a chest inside, in the center
        list.add(new Placement(new BlockPos(ox + SIZE / 2, oy + 1, oz + SIZE / 2), Blocks.CHEST));
        return list;
    }

    // ---- build-site selection ----

    /** Searches rings around the center for a clear, flat SIZE×SIZE plot. Returns the floor-corner pos, or null. */
    private BlockPos findBuildSite(BlockPos center) {
        for (int r = 7; r <= 16; r += 3) {
            for (int a = 0; a < 8; a++) {
                double ang = a * Math.PI / 4.0;
                int x = center.getX() + (int) Math.round(r * Math.cos(ang));
                int z = center.getZ() + (int) Math.round(r * Math.sin(ang));
                BlockPos site = clearFlatPlot(x, z);
                if (site != null) return site;
            }
        }
        return null;
    }

    private BlockPos clearFlatPlot(int x, int z) {
        // MOTION_BLOCKING ignores grass/flowers, so the floor lands ON the ground, not above the plants.
        int baseY = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
        for (int dx = 0; dx < SIZE; dx++) {
            for (int dz = 0; dz < SIZE; dz++) {
                int cx = x + dx, cz = z + dz;
                int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING, cx, cz);
                if (Math.abs(y - baseY) > 1) return null;                  // not flat enough

                BlockState ground = level.getBlockState(new BlockPos(cx, y - 1, cz));
                if (ground.isAir() || isLiquid(ground)) return null;       // need solid, dry ground

                for (int h = 0; h <= WALL_HEIGHT + 1; h++) {               // clearance for the whole hut
                    BlockState above = level.getBlockState(new BlockPos(cx, y + h, cz));
                    if (!above.isAir() && !above.canBeReplaced()) return null;  // grass/flowers are fine
                }
            }
        }
        // Anchor the floor one below the surface air so it sits flush with the ground, not on top of it.
        return new BlockPos(x, baseY - 1, z);
    }

    private boolean isLiquid(BlockState state) {
        String path = BuiltInRegistries.BLOCK.getKey(state.getBlock()).getPath();
        return path.equals("water") || path.equals("lava");
    }

    // ---- helpers ----

    private BlockPos resolveVillageCenter() {
        VillageRegistry reg = level.getAttachedOrCreate(LivingVillages.VILLAGES);
        Village v = reg.getOrCreate(villager.blockPosition());
        level.setAttached(LivingVillages.VILLAGES, reg);
        return v.center();
    }

    private void announce(String what) {
        VillageRegistry reg = level.getAttachedOrCreate(LivingVillages.VILLAGES);
        Village v = reg.getOrCreate(villager.blockPosition());
        String name = ((MemoryHolder) villager).lv_getPersonality().name;
        v.record(name + " " + what);
        level.setAttached(LivingVillages.VILLAGES, reg);
        LivingVillages.LOGGER.info("{} {}", name, what);
    }

    private boolean withinSq(BlockPos pos, double maxSq) {
        return villager.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) <= maxSq;
    }
}
