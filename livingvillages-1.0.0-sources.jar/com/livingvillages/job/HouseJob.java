package com.livingvillages.job;

import com.livingvillages.LivingVillages;
import com.livingvillages.interfaces.MemoryHolder;
import com.livingvillages.village.Village;
import com.livingvillages.village.VillageEconomy;
import com.livingvillages.village.VillageRegistry;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DoorHingeSide;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.levelgen.Heightmap;

/**
 * Builds a small 4x4 plank house (walls, flat roof, doorway, interior torch) so the
 * village can expand housing as the population grows. The plot is found by scanning
 * outward in a spiral from the village center for a clear patch of flat ground that
 * isn't already a building. When finished, the village records the new house in its
 * upgrade ledger so villagers (and /village) know it was built.
 */
public class HouseJob implements VillagerJob {

    private enum State { PLAN, GO_TO_SITE, BUILDING, FINISHED }

    private static final int    SIZE           = 4;     // 4x4 footprint
    private static final int    HEIGHT         = 3;     // 3 blocks tall
    private static final int    SEARCH_INNER   = 6;     // skip plots too close to center
    private static final int    SEARCH_OUTER   = 16;    // give up beyond this radius
    private static final int    WOOD_COST      = 48;    // walls + roof minus doorway/window
    private static final double SPEED          = 0.6;
    private static final double REACH_SQ       = 9.0;
    private static final int    LEG_TIMEOUT    = 200;
    private static final int    GLOBAL_TIMEOUT = 6000;

    private final ServerLevel level;
    private final Villager villager;

    private State state = State.PLAN;
    private BlockPos villageCenter;
    private BlockPos plot;        // SW corner (x0, baseY, z0) of the 4x4 footprint
    private int legTicks, totalTicks;

    public HouseJob(ServerLevel level, Villager villager) {
        this.level = level;
        this.villager = villager;
    }

    @Override
    public boolean isFinished() {
        return state == State.FINISHED || villager.isRemoved() || !villager.isAlive();
    }

    @Override
    public void tick() {
        if (isFinished()) return;
        totalTicks++;
        legTicks++;
        if (totalTicks > GLOBAL_TIMEOUT) { state = State.FINISHED; villager.getNavigation().stop(); return; }
        switch (state) {
            case PLAN       -> doPlan();
            case GO_TO_SITE -> doGoToSite();
            case BUILDING   -> doBuilding();
            default         -> { }
        }
    }

    private void doPlan() {
        villageCenter = resolveVillageCenter();
        plot = findPlot();
        if (plot == null) { state = State.FINISHED; return; }   // no open lot — try again later
        state = State.GO_TO_SITE;
        legTicks = 0;
    }

    private void doGoToSite() {
        if (within(plot) || legTicks > LEG_TIMEOUT) { state = State.BUILDING; legTicks = 0; return; }
        moveTo(plot);
    }

    private void doBuilding() {
        int got = VillageEconomy.withdraw(level, villageCenter, "wood", WOOD_COST);
        if (got < WOOD_COST / 2) { state = State.FINISHED; return; }   // ran out of wood mid-build

        int x0 = plot.getX(), baseY = plot.getY(), z0 = plot.getZ();
        villager.swing(InteractionHand.MAIN_HAND);
        Block plank = Blocks.OAK_PLANKS;

        // Clear vegetation in the build envelope.
        for (int dx = -1; dx <= SIZE; dx++) {
            for (int dz = -1; dz <= SIZE; dz++) {
                for (int dy = 0; dy <= HEIGHT + 1; dy++) {
                    BlockPos p = new BlockPos(x0 + dx, baseY + dy, z0 + dz);
                    BlockState bs = level.getBlockState(p);
                    if (!bs.isAir() && !isStructure(bs)) {
                        String path = path(bs);
                        if (path.contains("grass") || path.contains("leaves") || path.contains("_log")
                                || path.contains("flower") || path.contains("bush")) {
                            level.setBlockAndUpdate(p, Blocks.AIR.defaultBlockState());
                        }
                    }
                }
            }
        }

        // Doorway faces the village center (so it opens onto the connecting street).
        // Window is placed on the opposite face for light.
        int hcx = x0 + SIZE / 2, hcz = z0 + SIZE / 2;
        int toCx = villageCenter.getX() - hcx, toCz = villageCenter.getZ() - hcz;
        boolean doorOnX = Math.abs(toCx) >= Math.abs(toCz);
        Direction doorOuter = doorOnX
                ? (toCx >= 0 ? Direction.EAST  : Direction.WEST)
                : (toCz >= 0 ? Direction.SOUTH : Direction.NORTH);
        int doorEdgeX = doorOnX ? (toCx >= 0 ? SIZE - 1 : 0) : -1;
        int doorEdgeZ = doorOnX ? -1 : (toCz >= 0 ? SIZE - 1 : 0);
        int windowEdgeX = doorOnX ? (toCx >= 0 ? 0 : SIZE - 1) : -1;
        int windowEdgeZ = doorOnX ? -1 : (toCz >= 0 ? 0 : SIZE - 1);

        // Walls (perimeter), with doorway facing center + window opposite.
        for (int dy = 0; dy < HEIGHT; dy++) {
            for (int dx = 0; dx < SIZE; dx++) {
                for (int dz = 0; dz < SIZE; dz++) {
                    boolean edge = dx == 0 || dx == SIZE - 1 || dz == 0 || dz == SIZE - 1;
                    if (!edge) continue;
                    boolean doorway = doorOnX
                            ? (dx == doorEdgeX && dz == SIZE / 2 && dy < 2)
                            : (dz == doorEdgeZ && dx == SIZE / 2 && dy < 2);
                    boolean window  = doorOnX
                            ? (dx == windowEdgeX && dz == SIZE / 2 && dy == 1)
                            : (dz == windowEdgeZ && dx == SIZE / 2 && dy == 1);
                    if (doorway || window) continue;
                    level.setBlockAndUpdate(new BlockPos(x0 + dx, baseY + dy, z0 + dz), plank.defaultBlockState());
                }
            }
        }
        // Flat plank roof.
        for (int dx = 0; dx < SIZE; dx++) {
            for (int dz = 0; dz < SIZE; dz++) {
                level.setBlockAndUpdate(new BlockPos(x0 + dx, baseY + HEIGHT, z0 + dz), plank.defaultBlockState());
            }
        }
        // Functional door in the doorway gap, opening onto the connecting street.
        placeDoor(x0, baseY, z0, doorOuter);
        // Functional bed against the wall opposite the door so villagers can sleep here (enables vanilla breeding).
        placeBed(x0, baseY, z0, doorOuter);
        // Interior torch — anti-mob lighting so the house actually shelters anyone inside.
        level.setBlockAndUpdate(new BlockPos(x0 + 1, baseY + HEIGHT - 1, z0 + 1), Blocks.TORCH.defaultBlockState());

        creditHouse();
        announce("built a new house at " + (x0 + 1) + ", " + (z0 + 1) + " for the growing village.");
        villager.getNavigation().stop();
        state = State.FINISHED;
    }

    /** Tries to align the house with an existing street, falls back to a free-form spiral search. */
    private BlockPos findPlot() {
        BlockPos planned = findPlotAlongStreet();
        if (planned != null) return planned;
        return findPlotBySpiral();
    }

    /** Cardinal directions in the order StreetJob lays its spokes (N, E, S, W). */
    private static final int[][] STREET_DIRS = {{0, -1}, {1, 0}, {0, 1}, {-1, 0}};
    private static final int STREET_LENGTH   = 16;        // matches StreetJob.LENGTH
    private static final int PLOT_SPACING    = SIZE + 1;  // distance along a street between houses

    /**
     * Town planner: enumerate every street the village has laid, walk along it, and try to
     * drop a house on either flank. Houses end up flanking the streets in regular blocks,
     * each one centered on a street tile with a 1-block gap to the cobble — giving the
     * settlement a recognisable grid layout instead of scattered huts.
     */
    private BlockPos findPlotAlongStreet() {
        int sc = level.getAttachedOrCreate(LivingVillages.VILLAGES).getOrCreate(villageCenter).streets();
        if (sc == 0) return null;
        for (int s = 0; s < sc; s++) {
            int[] dir = STREET_DIRS[s % STREET_DIRS.length];
            int[][] perps = {{-dir[1], dir[0]}, {dir[1], -dir[0]}};
            for (int along = PLOT_SPACING; along <= STREET_LENGTH; along += PLOT_SPACING) {
                int sx = villageCenter.getX() + dir[0] * along;
                int sz = villageCenter.getZ() + dir[1] * along;
                for (int[] perp : perps) {
                    int x0, z0;
                    if (dir[0] != 0) {                    // street runs along X — center along X, offset on Z
                        x0 = sx - SIZE / 2;
                        z0 = sz + perp[1] * 2 + (perp[1] < 0 ? -(SIZE - 1) : 0);
                    } else {                              // street runs along Z — center along Z, offset on X
                        x0 = sx + perp[0] * 2 + (perp[0] < 0 ? -(SIZE - 1) : 0);
                        z0 = sz - SIZE / 2;
                    }
                    BlockPos plot = plotCorner(x0, z0);
                    if (plot != null) return plot;
                }
            }
        }
        return null;
    }

    /** Original spiral search — used when no streets exist yet. */
    private BlockPos findPlotBySpiral() {
        for (int r = SEARCH_INNER; r <= SEARCH_OUTER; r += 2) {
            for (int a = 0; a < 360; a += 24) {
                int dx = (int) Math.round(r * Math.cos(Math.toRadians(a)));
                int dz = (int) Math.round(r * Math.sin(Math.toRadians(a)));
                int x = villageCenter.getX() + dx;
                int z = villageCenter.getZ() + dz;
                BlockPos candidate = plotCorner(x, z);
                if (candidate != null) return candidate;
            }
        }
        return null;
    }

    /** Returns the SW corner of a clear 4x4 plot anchored near (x, z), or null if not buildable. */
    private BlockPos plotCorner(int x, int z) {
        int baseY = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
        // Reject if any column varies too much in surface height — needs flat ground.
        int minY = baseY, maxY = baseY;
        for (int dx = 0; dx < SIZE; dx++) {
            for (int dz = 0; dz < SIZE; dz++) {
                int s = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x + dx, z + dz);
                if (s < minY) minY = s;
                if (s > maxY) maxY = s;
            }
        }
        if (maxY - minY > 1) return null;

        // Reject if any block in the build envelope is a player structure (don't overbuild someone's house).
        for (int dx = 0; dx < SIZE; dx++) {
            for (int dz = 0; dz < SIZE; dz++) {
                for (int dy = 0; dy <= HEIGHT; dy++) {
                    BlockState bs = level.getBlockState(new BlockPos(x + dx, baseY + dy, z + dz));
                    if (isStructure(bs)) return null;
                }
                // Ground below must be solid (no water).
                BlockState below = level.getBlockState(new BlockPos(x + dx, baseY - 1, z + dz));
                if (below.isAir() || isLiquid(below)) return null;
            }
        }
        return new BlockPos(x, baseY, z);
    }

    private static boolean isStructure(BlockState bs) {
        String p = path(bs);
        return p.contains("door") || p.contains("bed") || p.contains("planks") || p.contains("chest")
            || p.contains("crafting") || p.contains("furnace") || p.contains("_stairs") || p.contains("_slab")
            || p.contains("glass") || p.contains("bell") || p.contains("lantern") || p.contains("barrel")
            || p.contains("loom") || p.contains("ladder") || p.contains("bookshelf");
    }

    private static boolean isLiquid(BlockState bs) {
        String p = path(bs);
        return p.equals("water") || p.equals("lava");
    }

    private static String path(BlockState bs) {
        return BuiltInRegistries.BLOCK.getKey(bs.getBlock()).getPath();
    }

    /** Places a 2-block oak door in the doorway gap, oriented so the outside faces {@code doorOuter}. */
    private void placeDoor(int x0, int baseY, int z0, Direction doorOuter) {
        int doorX = x0 + SIZE / 2, doorZ = z0 + SIZE / 2;
        switch (doorOuter) {
            case SOUTH -> doorZ = z0 + SIZE - 1;
            case NORTH -> doorZ = z0;
            case EAST  -> doorX = x0 + SIZE - 1;
            case WEST  -> doorX = x0;
            default    -> { /* no other horizontal options */ }
        }
        BlockState lower = Blocks.OAK_DOOR.defaultBlockState()
                .setValue(BlockStateProperties.HORIZONTAL_FACING, doorOuter)
                .setValue(BlockStateProperties.DOUBLE_BLOCK_HALF, DoubleBlockHalf.LOWER)
                .setValue(BlockStateProperties.DOOR_HINGE,       DoorHingeSide.LEFT)
                .setValue(BlockStateProperties.OPEN,             Boolean.FALSE);
        BlockState upper = Blocks.OAK_DOOR.defaultBlockState()
                .setValue(BlockStateProperties.HORIZONTAL_FACING, doorOuter)
                .setValue(BlockStateProperties.DOUBLE_BLOCK_HALF, DoubleBlockHalf.UPPER)
                .setValue(BlockStateProperties.DOOR_HINGE,       DoorHingeSide.LEFT)
                .setValue(BlockStateProperties.OPEN,             Boolean.FALSE);
        level.setBlockAndUpdate(new BlockPos(doorX, baseY,     doorZ), lower);
        level.setBlockAndUpdate(new BlockPos(doorX, baseY + 1, doorZ), upper);
    }

    /**
     * Places a 2-block red bed inside the house with its head against the wall opposite the
     * door. Enables vanilla villager breeding (which requires beds + food) so the village
     * can actually grow into the houses we keep building.
     */
    private void placeBed(int x0, int baseY, int z0, Direction doorOuter) {
        Block bedBlock = Blocks.BED.pick(DyeColor.RED);
        Direction back = doorOuter.getOpposite();
        BlockPos foot = new BlockPos(x0 + SIZE / 2, baseY, z0 + SIZE / 2);
        BlockPos head = foot.relative(back);
        // If the head lands on the back wall, shift the bed one block toward the door.
        int hx = head.getX() - x0, hz = head.getZ() - z0;
        if (hx < 1 || hx > SIZE - 2 || hz < 1 || hz > SIZE - 2) {
            foot = foot.relative(doorOuter);
            head = foot.relative(back);
        }
        BlockState footState = bedBlock.defaultBlockState()
                .setValue(BlockStateProperties.HORIZONTAL_FACING, back)
                .setValue(BlockStateProperties.BED_PART,          BedPart.FOOT);
        BlockState headState = bedBlock.defaultBlockState()
                .setValue(BlockStateProperties.HORIZONTAL_FACING, back)
                .setValue(BlockStateProperties.BED_PART,          BedPart.HEAD);
        level.setBlockAndUpdate(foot, footState);
        level.setBlockAndUpdate(head, headState);
    }

    private void creditHouse() {
        VillageRegistry reg = level.getAttachedOrCreate(LivingVillages.VILLAGES);
        reg.getOrCreate(villageCenter).incrementUpgrade("houses");
        level.setAttached(LivingVillages.VILLAGES, reg);
    }

    private void announce(String what) {
        VillageRegistry reg = level.getAttachedOrCreate(LivingVillages.VILLAGES);
        Village v = reg.getOrCreate(villageCenter);
        v.record(((MemoryHolder) villager).lv_getPersonality().name + " " + what);
        level.setAttached(LivingVillages.VILLAGES, reg);
    }

    private void moveTo(BlockPos pos) {
        villager.getNavigation().moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, SPEED);
    }

    private boolean within(BlockPos pos) {
        return villager.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) <= REACH_SQ;
    }

    private BlockPos resolveVillageCenter() {
        VillageRegistry reg = level.getAttachedOrCreate(LivingVillages.VILLAGES);
        Village v = reg.getOrCreate(villager.blockPosition());
        level.setAttached(LivingVillages.VILLAGES, reg);
        return v.center();
    }
}
