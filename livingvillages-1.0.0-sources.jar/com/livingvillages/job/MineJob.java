package com.livingvillages.job;

import com.livingvillages.LivingVillages;
import com.livingvillages.interfaces.MemoryHolder;
import com.livingvillages.village.Village;
import com.livingvillages.village.VillageEconomy;
import com.livingvillages.village.VillageRegistry;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * The village mine: ONE persistent staircase that deepens a little each run, 2 wide and
 * 3 tall, lit with torches, collecting stone and ores (notably iron). The head position +
 * direction + depth are stored on the {@link Village}, so successive miners continue the
 * same shaft.
 *
 * Two robustness features: the miner is warped straight to the work face each run (no slow
 * climb down/up), and when a step would hit water/lava/bedrock the shaft TURNS to a clear
 * direction instead of giving up — which also means the miner never walks into water.
 *
 * Server-thread state machine: PLAN -> GO_TO_SITE (fresh shaft only) -> DIGGING -> RETURN.
 */
public class MineJob implements VillagerJob {

    private enum State { PLAN, GO_TO_SITE, DIGGING, RETURN, FINISHED }

    private static final int    ENTRANCE_DIST  = 10;
    private static final int    RUN_STEPS      = 24;    // fresh steps dug per trip
    public  static final int    MAX_DEPTH      = 56;    // how deep the mine ever goes (~diamond band)
    private static final int    TORCH_INTERVAL = 4;     // place a torch every N steps
    private static final double SPEED          = 0.55;
    private static final double SITE_REACH_SQ  = 9.0;
    private static final double REACH_SQ       = 6.25;
    private static final double DEPOSIT_SQ     = 9.0;
    private static final int    LEG_TIMEOUT    = 300;
    private static final int    GLOBAL_TIMEOUT = 6000;

    private final ServerLevel level;
    private final Villager villager;

    private State state = State.PLAN;
    private BlockPos villageCenter;
    private BlockPos headPos;          // current bottom/work face of the shaft
    private int digDx, digDz;          // current dig direction
    private int startDepth;
    private int maxDepthThisRun;
    private int depth;                 // steps dug so far (== current shaft depth)
    private boolean roomCarved;
    private BlockPos depositTarget;
    private final Map<Item, Integer> carried = new LinkedHashMap<>();
    private int legTicks;
    private int totalTicks;

    public MineJob(ServerLevel level, Villager villager) {
        this.level = level;
        this.villager = villager;
    }

    @Override
    public boolean isFinished() {
        return state == State.FINISHED || villager.isRemoved() || !villager.isAlive();
    }

    @Override
    public void tick() {
        if (isFinished()) return;
        totalTicks++;
        legTicks++;
        if (totalTicks > GLOBAL_TIMEOUT) { finishDigging(); return; }

        switch (state) {
            case PLAN       -> doPlan();
            case GO_TO_SITE -> doGoToSite();
            case DIGGING    -> doDigging();
            case RETURN     -> doReturn();
            default         -> { }
        }
    }

    private void doPlan() {
        villageCenter = resolveVillageCenter();
        Village v = level.getAttachedOrCreate(LivingVillages.VILLAGES).getOrCreate(villageCenter);

        BlockPos head = v.mineHead();
        if (head != null && !isLiquid(level.getBlockState(head))) {
            // Continue the existing shaft — warp straight to the work face, skipping the climb.
            headPos = head;
            digDx = v.mineDx();
            digDz = v.mineDz();
            if (digDx == 0 && digDz == 0) digDx = 1;
            startDepth = v.mineDepth();
            villager.teleportTo(headPos.getX() + 0.5, headPos.getY(), headPos.getZ() + 0.5);
            state = State.DIGGING;
        } else {
            BlockPos entrance = findMineEntrance(villageCenter);   // sets digDx/digDz
            if (entrance == null) {
                announce("looked for a place to dig a mine but found no solid ground.");
                state = State.FINISHED;
                return;
            }
            headPos = entrance;
            startDepth = 0;
            state = State.GO_TO_SITE;
        }
        depth = startDepth;
        maxDepthThisRun = Math.min(startDepth + RUN_STEPS, MAX_DEPTH);
        legTicks = 0;
    }

    private void doGoToSite() {
        if (withinSq(headPos, SITE_REACH_SQ) || legTicks > LEG_TIMEOUT) {
            state = State.DIGGING;
            legTicks = 0;
            return;
        }
        moveTo(headPos);
    }

    private void doDigging() {
        if (depth >= maxDepthThisRun) {
            if (maxDepthThisRun >= MAX_DEPTH && !roomCarved) { carveRoom(); roomCarved = true; }
            finishDigging();
            return;
        }
        if (!withinSq(headPos, REACH_SQ)) {            // follow the descending work face (short hops)
            moveTo(headPos);
            if (legTicks > LEG_TIMEOUT) finishDigging();
            return;
        }
        legTicks = 0;
        if (!digOneStep()) { finishDigging(); return; }   // boxed in by hazards on every side
        moveTo(headPos);
    }

    private void doReturn() {
        if (withinSq(depositTarget, DEPOSIT_SQ) || legTicks > LEG_TIMEOUT) { deposit(); return; }
        moveTo(depositTarget);
    }

    /** Digs one step down, turning to a clear direction if straight ahead is blocked. */
    private boolean digOneStep() {
        // Prefer to keep going straight, else turn left, else turn right (never reverse).
        int[][] candidates = {{digDx, digDz}, {-digDz, digDx}, {digDz, -digDx}};
        for (int[] d : candidates) {
            int nx = headPos.getX() + d[0];
            int ny = headPos.getY() - 1;
            int nz = headPos.getZ() + d[1];
            if (canCarve(nx, ny, nz, d[0], d[1])) {
                depth++;
                carveStep(nx, ny, nz, d[0], d[1], depth);
                headPos = new BlockPos(nx, ny, nz);
                digDx = d[0];
                digDz = d[1];
                return true;
            }
        }
        return false;
    }

    /** True if the 2-wide x 3-tall step (and its floor) is free of liquid and unbreakable blocks. */
    private boolean canCarve(int nx, int ny, int nz, int dx, int dz) {
        int px = -dz, pz = dx;
        return columnClear(nx, nz, ny) && columnClear(nx + px, nz + pz, ny);
    }

    private boolean columnClear(int x, int z, int feetY) {
        for (int dy = 0; dy <= 2; dy++) {              // feet, head, headroom
            BlockState bs = level.getBlockState(new BlockPos(x, feetY + dy, z));
            if (isLiquid(bs) || isUnbreakable(bs)) return false;
        }
        return !isLiquid(level.getBlockState(new BlockPos(x, feetY - 1, z)));  // don't open onto water below
    }

    private void carveStep(int nx, int ny, int nz, int dx, int dz, int newDepth) {
        int px = -dz, pz = dx;
        villager.swing(InteractionHand.MAIN_HAND);
        carveColumn(nx, nz, ny);
        carveColumn(nx + px, nz + pz, ny);
        if (newDepth % TORCH_INTERVAL == 0) {          // light the shaft
            level.setBlockAndUpdate(new BlockPos(nx, ny, nz), Blocks.TORCH.defaultBlockState());
        }
    }

    /** Clears one 3-tall column and shores its floor. (Hazards already excluded by canCarve.) */
    private void carveColumn(int x, int z, int feetY) {
        for (int dy = 0; dy <= 2; dy++) {
            BlockPos pos = new BlockPos(x, feetY + dy, z);
            BlockState bs = level.getBlockState(pos);
            if (bs.isAir()) continue;
            Item drop = minedItem(bs);
            level.destroyBlock(pos, false, villager, 512);
            if (drop != Items.AIR) carried.merge(drop, 1, Integer::sum);
        }
        BlockPos floor = new BlockPos(x, feetY - 1, z);
        if (level.getBlockState(floor).isAir()) {
            level.setBlockAndUpdate(floor, Blocks.COBBLESTONE.defaultBlockState());
        }
    }

    /** At the deepest point, hollows out a chamber so a lot more ore is exposed (incl. a diamond chance). */
    private void carveRoom() {
        BlockPos b = headPos;
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                BlockPos floor = new BlockPos(b.getX() + dx, b.getY() - 1, b.getZ() + dz);
                BlockState fb = level.getBlockState(floor);
                if (fb.isAir() || isLiquid(fb)) level.setBlockAndUpdate(floor, Blocks.COBBLESTONE.defaultBlockState());
                for (int dy = 0; dy <= 2; dy++) {
                    BlockPos p = new BlockPos(b.getX() + dx, b.getY() + dy, b.getZ() + dz);
                    BlockState bs = level.getBlockState(p);
                    if (bs.isAir() || isUnbreakable(bs) || isLiquid(bs)) continue;  // best-effort; never flood
                    Item drop = minedItem(bs);
                    level.destroyBlock(p, false, villager, 512);
                    if (drop != Items.AIR) carried.merge(drop, 1, Integer::sum);
                }
            }
        }
        level.setBlockAndUpdate(new BlockPos(b.getX(), b.getY(), b.getZ()), Blocks.TORCH.defaultBlockState());
    }

    private void finishDigging() {
        persistMine();
        if (carried.isEmpty()) {
            villager.getNavigation().stop();
            state = State.FINISHED;
            return;
        }
        // Warp out of the deep shaft to the surface, then walk the short way to storage.
        villager.teleportTo(villageCenter.getX() + 0.5, villageCenter.getY(), villageCenter.getZ() + 0.5);
        BlockPos storage = VillageEconomy.findStorage(level, villageCenter);
        depositTarget = storage != null ? storage : villageCenter;
        state = State.RETURN;
        legTicks = 0;
    }

    private void deposit() {
        int total = carried.values().stream().mapToInt(Integer::intValue).sum();
        int iron = carried.getOrDefault(Items.RAW_IRON, 0);
        JobStorage.transfer(level, depositTarget, carried);

        String name = ((MemoryHolder) villager).lv_getPersonality().name;
        VillageRegistry reg = level.getAttachedOrCreate(LivingVillages.VILLAGES);
        reg.getOrCreate(villageCenter).record(name + " returned from the mine with " + total + " resources"
                + (iron > 0 ? " (including " + iron + " iron)" : "") + ".");
        level.setAttached(LivingVillages.VILLAGES, reg);
        LivingVillages.LOGGER.info("{} finished mining: {} resources, {} iron (depth {}).", name, total, iron, depth);

        villager.getNavigation().stop();
        state = State.FINISHED;
    }

    private void persistMine() {
        VillageRegistry reg = level.getAttachedOrCreate(LivingVillages.VILLAGES);
        reg.getOrCreate(villageCenter).setMineState(headPos, digDx, digDz, depth);
        level.setAttached(LivingVillages.VILLAGES, reg);
    }

    // ---- helpers ----

    private BlockPos findMineEntrance(BlockPos center) {
        int[][] dirs = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        for (int[] d : dirs) {
            int x = center.getX() + d[0] * ENTRANCE_DIST;
            int z = center.getZ() + d[1] * ENTRANCE_DIST;
            int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
            BlockState ground = level.getBlockState(new BlockPos(x, y - 1, z));
            if (ground.isAir() || isLiquid(ground)) continue;       // need solid, dry ground
            digDx = d[0];
            digDz = d[1];                                            // dig outward, away from the village
            return new BlockPos(x, y, z);
        }
        return null;
    }

    /** Maps a mined block to what it yields: ores give their raw drop, everything else its block item. */
    private Item minedItem(BlockState state) {
        String p = pathOf(state);
        if (p.contains("iron"))            return Items.RAW_IRON;
        if (p.contains("copper"))          return Items.RAW_COPPER;
        if (p.contains("gold") && p.contains("ore")) return Items.RAW_GOLD;
        if (p.contains("coal"))            return Items.COAL;
        if (p.contains("diamond"))         return Items.DIAMOND;
        if (p.contains("redstone"))        return Items.REDSTONE;
        if (p.contains("lapis"))           return Items.LAPIS_LAZULI;
        if (p.contains("emerald") && p.contains("ore")) return Items.EMERALD;
        return state.getBlock().asItem();
    }

    private boolean isUnbreakable(BlockState state) {
        String p = pathOf(state);
        return p.equals("bedrock") || p.contains("obsidian");
    }

    private boolean isLiquid(BlockState state) {
        String p = pathOf(state);
        return p.equals("water") || p.equals("lava");
    }

    private String pathOf(BlockState state) {
        return BuiltInRegistries.BLOCK.getKey(state.getBlock()).getPath();
    }

    private void moveTo(BlockPos pos) {
        villager.getNavigation().moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, SPEED);
    }

    private boolean withinSq(BlockPos pos, double maxSq) {
        return villager.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) <= maxSq;
    }

    private BlockPos resolveVillageCenter() {
        VillageRegistry reg = level.getAttachedOrCreate(LivingVillages.VILLAGES);
        Village v = reg.getOrCreate(villager.blockPosition());
        level.setAttached(LivingVillages.VILLAGES, reg);
        return v.center();
    }

    private void announce(String what) {
        VillageRegistry reg = level.getAttachedOrCreate(LivingVillages.VILLAGES);
        reg.getOrCreate(villageCenter).record(((MemoryHolder) villager).lv_getPersonality().name + " " + what);
        level.setAttached(LivingVillages.VILLAGES, reg);
    }
}
