package com.livingvillages.job;

import com.livingvillages.LivingVillages;
import com.livingvillages.interfaces.MemoryHolder;
import com.livingvillages.village.Village;
import com.livingvillages.village.VillageEconomy;
import com.livingvillages.village.VillageRegistry;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;

import java.util.ArrayList;
import java.util.List;

/**
 * Builds a continuous defensive perimeter wall — a team effort. Every wall stands on ONE
 * uniform foundation height (the village's ground level): terrain and trees above it are
 * cleared, valleys and water below are filled, so the wall is flat-topped and gap-free
 * regardless of what it crosses. Builders work off the world itself — each one walls the
 * next column that isn't built yet — so several villagers can raise it together and it
 * resumes cleanly after a restart. Torches along the top keep mobs from spawning on it.
 */
public class WallJob implements VillagerJob {

    private enum State { PLAN, BUILDING, FINISHED }

    private static final int    BASE_RADIUS    = 18;     // minimum wall half-width
    private static final int    MAX_RADIUS     = 36;     // cap so a sprawling village can't make an enormous wall
    private static final int    STRUCT_MARGIN  = 4;      // keep the wall this far beyond the outermost building
    private static final int    HEIGHT         = 3;
    private static final int    TOWER_EXTRA    = 3;      // corner watchtowers
    private static final int    MAX_FILL_DOWN  = 16;     // how far down a column fills to reach solid ground
    private static final int    OVERHEAD       = 6;      // clear this much terrain above the wall top
    private static final int    TORCH_SPACING  = 6;      // a torch on top every N columns (anti-mob lighting)
    private static final double SPEED          = 0.6;
    private static final double REACH_SQ       = 9.0;
    private static final int    LEG_TIMEOUT    = 200;
    private static final int    GLOBAL_TIMEOUT = 9000;

    private final ServerLevel level;
    private final Villager villager;

    private State state = State.PLAN;
    private BlockPos villageCenter;
    private List<BlockPos> ring;
    private int radius;
    private int baseY;
    private int cursor;
    private int target = -1;
    private int legTicks, totalTicks;
    private int waterTicks;     // released to vanilla brain if stuck in water

    public WallJob(ServerLevel level, Villager villager) {
        this.level = level;
        this.villager = villager;
    }

    public static int perimeterColumns(int radius) { return 8 * radius; }

    /** The wall radius for a village, sized once to enclose its buildings and then stored (caller persists). */
    public static int radiusFor(ServerLevel level, Village village) {
        int r = village.wallRadius();
        if (r <= 0) {
            r = computeRadius(level, village.center());
            village.setWallRadius(r);
        }
        return r;
    }

    /** Square half-width that puts every nearby building inside, with a margin so the wall line stays clear. */
    private static int computeRadius(ServerLevel level, BlockPos center) {
        int maxD = 0;
        for (int dx = -MAX_RADIUS; dx <= MAX_RADIUS; dx += 2) {
            for (int dz = -MAX_RADIUS; dz <= MAX_RADIUS; dz += 2) {
                int x = center.getX() + dx, z = center.getZ() + dz;
                int surf = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
                for (int y = surf + 5; y >= surf - 3; y--) {
                    if (isStructure(level.getBlockState(new BlockPos(x, y, z)))) {
                        maxD = Math.max(maxD, Math.max(Math.abs(dx), Math.abs(dz)));
                        break;
                    }
                }
            }
        }
        return Math.max(BASE_RADIUS, Math.min(MAX_RADIUS, maxD + STRUCT_MARGIN));
    }

    /** Crafted/built blocks that mark a building (so the wall encloses them) — not natural terrain or our own wall. */
    private static boolean isStructure(BlockState bs) {
        String p = path(bs);
        return p.contains("door") || p.contains("bed") || p.contains("planks") || p.contains("chest")
            || p.contains("crafting") || p.contains("furnace") || p.contains("_stairs") || p.contains("_slab")
            || p.contains("glass") || p.contains("bell") || p.contains("lantern") || p.contains("barrel")
            || p.contains("loom") || p.contains("composter") || p.contains("ladder") || p.contains("fence")
            || p.contains("wool") || p.contains("bookshelf") || p.contains("lectern") || p.contains("bricks");
    }

    @Override
    public boolean isFinished() {
        return state == State.FINISHED || villager.isRemoved() || !villager.isAlive();
    }

    @Override
    public void tick() {
        if (isFinished()) return;
        totalTicks++;
        legTicks++;
        if (totalTicks > GLOBAL_TIMEOUT) { state = State.FINISHED; villager.getNavigation().stop(); return; }

        // Drowning guard: if the builder spends too long in water, release the job so the
        // vanilla brain (which knows how to swim) can take over before the villager dies.
        if (villager.isInWater()) {
            waterTicks++;
            if (waterTicks > 40) {                                       // ~2 s of being submerged
                state = State.FINISHED;
                villager.getNavigation().stop();
                return;
            }
        } else {
            waterTicks = 0;
        }

        switch (state) {
            case PLAN     -> doPlan();
            case BUILDING -> doBuilding();
            default       -> { }
        }
    }

    private void doPlan() {
        VillageRegistry reg = level.getAttachedOrCreate(LivingVillages.VILLAGES);
        Village v = reg.getOrCreate(villager.blockPosition());
        villageCenter = v.center();
        radius = radiusFor(level, v);                                          // sized to enclose the buildings
        level.setAttached(LivingVillages.VILLAGES, reg);

        baseY = surfaceY(level, villageCenter.getX(), villageCenter.getZ());   // one uniform foundation
        ring = computeDeformedRing();                                          // bends OUT around player builds
        cursor = villager.getRandom().nextInt(ring.size());                    // spread the team around the ring
        target = -1;
        state = State.BUILDING;
        legTicks = 0;
    }

    private void doBuilding() {
        if (target < 0) {
            target = findNextColumn();
            if (target < 0) { markComplete(); return; }   // every column is built — wall complete
            legTicks = 0;
        }
        BlockPos col = ring.get(target);
        BlockPos stand = inwardStand(col);
        if (stand == null) {                              // no dry land to stand on (e.g. over open water)
            cursor = (target + 1) % ring.size();          // skip — leave this section as an open quay
            target = -1;
            return;
        }
        if (!within(stand) && legTicks <= LEG_TIMEOUT) { moveTo(stand); return; }
        legTicks = 0;

        if (!buildColumn(col, target)) { state = State.FINISHED; return; }   // out of stone
        cursor = (target + 1) % ring.size();
        target = -1;
    }

    /** Next non-gate column (scanning forward from the cursor) that isn't walled yet, or -1 if none. */
    private int findNextColumn() {
        for (int t = 0; t < ring.size(); t++) {
            int c = (cursor + t) % ring.size();
            BlockPos col = ring.get(c);
            if (!isGate(col) && needsBuild(col)) return c;
        }
        return -1;
    }

    private boolean needsBuild(BlockPos col) {
        BlockState bs = level.getBlockState(new BlockPos(col.getX(), baseY + HEIGHT - 1, col.getZ()));
        return !"cobblestone".equals(path(bs));
    }

    private boolean buildColumn(BlockPos col, int index) {
        boolean corner = Math.abs(col.getX() - villageCenter.getX()) == radius
                      && Math.abs(col.getZ() - villageCenter.getZ()) == radius;
        int rise = corner ? HEIGHT + TOWER_EXTRA : HEIGHT;

        // Over water, raise the wall as a dam to above the surface.
        int waterTop = baseY;
        while (isWater(level.getBlockState(new BlockPos(col.getX(), waterTop, col.getZ())))) waterTop++;
        int top = Math.max(baseY, waterTop) + rise - 1;

        // Clear terrain/trees above the wall so it isn't buried in a hillside.
        for (int y = top + 1; y <= top + OVERHEAD; y++) {
            BlockPos p = new BlockPos(col.getX(), y, col.getZ());
            if (!level.getBlockState(p).isAir()) level.setBlockAndUpdate(p, Blocks.AIR.defaultBlockState());
        }

        // Fill down to solid ground so the wall never floats over valleys or water.
        int fy = baseY - 1, guard = 0;
        while (guard < MAX_FILL_DOWN) {
            BlockState bs = level.getBlockState(new BlockPos(col.getX(), fy, col.getZ()));
            if (!bs.isAir() && !isWater(bs)) break;
            fy--;
            guard++;
        }
        int floorY = fy + 1;

        int count = top - floorY + 1;
        int got = VillageEconomy.withdraw(level, villageCenter, "stone", count);
        if (got <= 0) return false;
        villager.swing(InteractionHand.MAIN_HAND);
        int placed = 0;
        for (int y = top; y >= floorY && placed < got; y--, placed++) {   // top-down: keep the defensive top
            level.setBlockAndUpdate(new BlockPos(col.getX(), y, col.getZ()), Blocks.COBBLESTONE.defaultBlockState());
        }
        if (placed > 0 && (corner || index % TORCH_SPACING == 0)) {       // anti-mob lighting along the top
            level.setBlockAndUpdate(new BlockPos(col.getX(), top + 1, col.getZ()), Blocks.TORCH.defaultBlockState());
        }
        return true;
    }

    private void markComplete() {
        VillageRegistry reg = level.getAttachedOrCreate(LivingVillages.VILLAGES);
        Village v = reg.getOrCreate(villageCenter);
        if (v.wallProgress() < perimeterColumns(radius)) {
            v.setWallProgress(perimeterColumns(radius));
            v.record(((MemoryHolder) villager).lv_getPersonality().name + " reported the village wall complete.");
            level.setAttached(LivingVillages.VILLAGES, reg);
        }
        villager.getNavigation().stop();
        state = State.FINISHED;
    }

    /**
     * Find a position INSIDE the perimeter where the builder can really stand — solid ground
     * with no water at the feet/head. Walks inward up to {@code INWARD_MAX_STEPS} blocks. If no
     * dry land exists (the column is over open water reaching deep into the village), returns
     * null so the wall section is skipped instead of suiciding a villager into the lake.
     */
    private static final int INWARD_MAX_STEPS = 8;
    private BlockPos inwardStand(BlockPos col) {
        int dx = Integer.signum(villageCenter.getX() - col.getX());
        int dz = Integer.signum(villageCenter.getZ() - col.getZ());
        if (dx == 0 && dz == 0) return null;
        for (int step = 1; step <= INWARD_MAX_STEPS; step++) {
            int ix = col.getX() + dx * step;
            int iz = col.getZ() + dz * step;
            int y = surfaceY(level, ix, iz);
            BlockState here  = level.getBlockState(new BlockPos(ix, y,     iz));
            BlockState above = level.getBlockState(new BlockPos(ix, y + 1, iz));
            if (isWater(here) || isWater(above)) continue;   // not real land — keep walking inward
            return new BlockPos(ix, y, iz);
        }
        return null;
    }

    private boolean isGate(BlockPos col) {
        return isGate(col, villageCenter, radius);
    }

    private static boolean isGate(BlockPos col, BlockPos center, int r) {
        int cx = center.getX(), cz = center.getZ();
        boolean nsEdge = col.getZ() == cz - r || col.getZ() == cz + r;
        boolean ewEdge = col.getX() == cx - r || col.getX() == cx + r;
        if (nsEdge && Math.abs(col.getX() - cx) <= 1) return true;
        if (ewEdge && Math.abs(col.getZ() - cz) <= 1) return true;
        return false;
    }

    private static List<BlockPos> computeRing(BlockPos c, int r) {
        List<BlockPos> out = new ArrayList<>();
        int x0 = c.getX() - r, x1 = c.getX() + r, z0 = c.getZ() - r, z1 = c.getZ() + r;
        for (int x = x0; x <= x1; x++)         out.add(new BlockPos(x, 0, z0));
        for (int z = z0 + 1; z <= z1; z++)     out.add(new BlockPos(x1, 0, z));
        for (int x = x1 - 1; x >= x0; x--)     out.add(new BlockPos(x, 0, z1));
        for (int z = z1 - 1; z >= z0 + 1; z--) out.add(new BlockPos(x0, 0, z));
        return out;
    }

    /**
     * Build a deformed perimeter: where a square-ring column would land on a player
     * structure, push that column OUTWARD (along its edge's outward normal) until clear,
     * up to MAX_RADIUS. Smooth circularly so consecutive columns differ in push by at
     * most 1, and insert L-corner blocks at every diagonal step so the wall stays
     * continuous. Buildings always end up enclosed; nothing in the village gets walled
     * through.
     */
    private List<BlockPos> computeDeformedRing() {
        int cx = villageCenter.getX(), cz = villageCenter.getZ();
        int x0 = cx - radius, x1 = cx + radius, z0 = cz - radius, z1 = cz + radius;

        // Base ring with each column's outward-normal axis.
        List<int[]> base = new ArrayList<>();   // [x, z, outDx, outDz]
        for (int x = x0; x <= x1; x++)         base.add(new int[]{x, z0,  0, -1});
        for (int z = z0 + 1; z <= z1; z++)     base.add(new int[]{x1, z,  1,  0});
        for (int x = x1 - 1; x >= x0; x--)     base.add(new int[]{x, z1,  0,  1});
        for (int z = z1 - 1; z >= z0 + 1; z--) base.add(new int[]{x0, z, -1,  0});
        int n = base.size();

        int maxPush = Math.max(0, MAX_RADIUS - radius);
        int[] push = new int[n];
        for (int i = 0; i < n; i++) {
            int[] b = base.get(i);
            // Don't deform gate slots — they need to stay at their canonical positions.
            push[i] = isGate(new BlockPos(b[0], 0, b[1]), villageCenter, radius)
                    ? 0 : pushNeeded(b[0], b[1], b[2], b[3], maxPush);
        }
        // Smooth circularly so consecutive pushes differ by ≤ 1 (no abrupt 2-block jumps).
        boolean changed = true;
        int guard = 0;
        while (changed && guard++ < n) {
            changed = false;
            for (int i = 0; i < n; i++) {
                int prev = push[(i - 1 + n) % n];
                int next = push[(i + 1) % n];
                int target = Math.max(prev, next) - 1;
                if (push[i] < target) { push[i] = target; changed = true; }
            }
        }

        // Apply pushes; insert L-corner blocks at diagonal steps so the wall is gap-free.
        int[][] pos = new int[n][2];
        for (int i = 0; i < n; i++) {
            int[] b = base.get(i);
            pos[i][0] = b[0] + b[2] * push[i];
            pos[i][1] = b[1] + b[3] * push[i];
        }
        List<BlockPos> out = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            out.add(new BlockPos(pos[i][0], 0, pos[i][1]));
            int[] nx = pos[(i + 1) % n];
            int dx = nx[0] - pos[i][0], dz = nx[1] - pos[i][1];
            if (Math.abs(dx) == 1 && Math.abs(dz) == 1) {
                // Pick the L-corner block further from center so the wall bulges OUT around the bend.
                int aX = pos[i][0] + dx, aZ = pos[i][1];
                int bX = pos[i][0],      bZ = pos[i][1] + dz;
                int aCh = Math.max(Math.abs(aX - cx), Math.abs(aZ - cz));
                int bCh = Math.max(Math.abs(bX - cx), Math.abs(bZ - cz));
                out.add(aCh >= bCh ? new BlockPos(aX, 0, aZ) : new BlockPos(bX, 0, bZ));
            }
        }
        return out;
    }

    /** Smallest outward offset that puts this column on terrain free of player structures. */
    private int pushNeeded(int x, int z, int outDx, int outDz, int maxPush) {
        for (int p = 0; p <= maxPush; p++) {
            if (!hasStructure(x + outDx * p, z + outDz * p)) return p;
        }
        return 0;   // can't escape within bounds; build through as a last resort
    }

    private boolean hasStructure(int x, int z) {
        int surf = surfaceY(level, x, z);
        for (int y = surf; y <= surf + HEIGHT; y++) {
            if (isStructure(level.getBlockState(new BlockPos(x, y, z)))) return true;
        }
        return false;
    }

    // ---- shared ground helpers (also used by the gate logic) ----

    static int surfaceY(ServerLevel level, int x, int z) {
        int top = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int y = top - 1; y >= top - 24; y--) {
            m.set(x, y, z);
            if (isSolidGround(level.getBlockState(m))) return y + 1;
        }
        return top;
    }

    private static boolean isSolidGround(BlockState bs) {
        if (bs.isAir()) return false;
        String p = path(bs);
        return !(p.contains("leaves") || p.contains("_log") || p.equals("water") || p.equals("lava"));
    }

    private static boolean isWater(BlockState bs) {
        return "water".equals(path(bs));
    }

    private static String path(BlockState bs) {
        return BuiltInRegistries.BLOCK.getKey(bs.getBlock()).getPath();
    }

    // ---- Gates (opened/closed by VillageDefense during raids), aligned to the uniform foundation ----

    private static List<BlockPos> gateColumns(BlockPos c, int r) {
        int cx = c.getX(), cz = c.getZ();
        List<BlockPos> g = new ArrayList<>();
        for (int d = -1; d <= 1; d++) {
            g.add(new BlockPos(cx + d, 0, cz - r));
            g.add(new BlockPos(cx + d, 0, cz + r));
            g.add(new BlockPos(cx - r, 0, cz + d));
            g.add(new BlockPos(cx + r, 0, cz + d));
        }
        return g;
    }

    public static void closeGates(ServerLevel level, BlockPos center, int radius) {
        int baseY = surfaceY(level, center.getX(), center.getZ());
        int top = baseY + HEIGHT - 1;
        for (BlockPos col : gateColumns(center, radius)) {
            if (occupiedByFriendly(level, col.getX(), baseY, col.getZ())) continue;
            int floor = Math.min(surfaceY(level, col.getX(), col.getZ()), baseY);
            for (int y = floor; y <= top; y++) {
                BlockPos p = new BlockPos(col.getX(), y, col.getZ());
                BlockState bs = level.getBlockState(p);
                if (bs.isAir() || isWater(bs)) level.setBlockAndUpdate(p, Blocks.COBBLESTONE.defaultBlockState());
            }
        }
    }

    public static void openGates(ServerLevel level, BlockPos center, int radius) {
        int baseY = surfaceY(level, center.getX(), center.getZ());
        int top = baseY + HEIGHT - 1;
        for (BlockPos col : gateColumns(center, radius)) {
            int floor = Math.min(surfaceY(level, col.getX(), col.getZ()), baseY);
            for (int y = floor; y <= top; y++) {
                BlockPos p = new BlockPos(col.getX(), y, col.getZ());
                if ("cobblestone".equals(path(level.getBlockState(p)))) {
                    level.setBlockAndUpdate(p, Blocks.AIR.defaultBlockState());
                }
            }
        }
    }

    private static boolean occupiedByFriendly(ServerLevel level, int x, int base, int z) {
        AABB box = new AABB(x, base, z, x + 1, base + HEIGHT, z + 1);
        return !level.getEntitiesOfClass(Villager.class, box).isEmpty()
            || !level.getEntitiesOfClass(Player.class, box).isEmpty();
    }

    // ---- misc ----

    private void moveTo(BlockPos pos) {
        villager.getNavigation().moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, SPEED);
    }

    private boolean within(BlockPos pos) {
        return villager.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) <= REACH_SQ;
    }

    private BlockPos resolveVillageCenter() {
        VillageRegistry reg = level.getAttachedOrCreate(LivingVillages.VILLAGES);
        Village v = reg.getOrCreate(villager.blockPosition());
        level.setAttached(LivingVillages.VILLAGES, reg);
        return v.center();
    }
}
