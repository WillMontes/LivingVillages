package com.livingvillages.job;

/** A unit of autonomous work a villager performs over many ticks (gathering, building, …). */
public interface VillagerJob {

    /** Advance one server tick. Only ever called on the server thread. */
    void tick();

    /** True once the job is complete or no longer valid (villager gone/dead). */
    boolean isFinished();
}
