package com.livingvillages.job;

import com.livingvillages.LivingVillages;
import com.livingvillages.interfaces.MemoryHolder;
import com.livingvillages.village.Village;
import com.livingvillages.village.VillageRegistry;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

/**
 * Exploration party: a villager sets out from the village, scouts a distant location, and
 * returns to report what they found — terrain, a notable feature, a biome, or even another
 * village. The discovery lands in the village chronicle, so villagers can talk about the
 * wider world ("our scouts found a ravine to the north"). The long journey is abstracted
 * with a delay + warp, like caravans, since open-terrain pathfinding that far is unreliable.
 */
public class ExplorerJob implements VillagerJob {

    private enum State { GO_OUT, TRAVEL, RETURN, FINISHED }

    private static final double SPEED        = 0.6;
    private static final int    OUT_TICKS    = 60;     // a visible departure
    private static final int    TRAVEL_TICKS = 80;     // each leg of the "journey"
    private static final int    DIST         = 110;    // how far out to scout (kept within loaded range)

    private static final int[][] DIRS  = {{0, -1}, {0, 1}, {1, 0}, {-1, 0}};
    private static final String[] NAMES = {"north", "south", "east", "west"};

    private final ServerLevel level;
    private final Villager villager;

    private State state = State.GO_OUT;
    private BlockPos home;
    private int dirX, dirZ;
    private String dirName = "out";
    private BlockPos dest;
    private String discovery = "found nothing of note";
    private int ticks;

    public ExplorerJob(ServerLevel level, Villager villager) {
        this.level = level;
        this.villager = villager;
    }

    @Override
    public boolean isFinished() {
        return state == State.FINISHED || villager.isRemoved() || !villager.isAlive();
    }

    @Override
    public void tick() {
        if (isFinished()) return;
        switch (state) {
            case GO_OUT -> doGoOut();
            case TRAVEL -> doTravel();
            case RETURN -> doReturn();
            default     -> { }
        }
    }

    private void doGoOut() {
        if (home == null) {
            home = resolveHome();
            int d = villager.getRandom().nextInt(4);
            dirX = DIRS[d][0];
            dirZ = DIRS[d][1];
            dirName = NAMES[d];
            int dx = home.getX() + dirX * DIST, dz = home.getZ() + dirZ * DIST;
            dest = new BlockPos(dx, level.getHeight(Heightmap.Types.MOTION_BLOCKING, dx, dz), dz);
        }
        int nx = home.getX() + dirX * 16, nz = home.getZ() + dirZ * 16;
        villager.getNavigation().moveTo(nx + 0.5, level.getHeight(Heightmap.Types.MOTION_BLOCKING, nx, nz), nz + 0.5, SPEED);
        if (++ticks >= OUT_TICKS) { state = State.TRAVEL; ticks = 0; }
    }

    private void doTravel() {
        if (++ticks < TRAVEL_TICKS) return;
        villager.teleportTo(dest.getX() + 0.5, dest.getY(), dest.getZ() + 0.5);
        discovery = scout(dest);
        state = State.RETURN;
        ticks = 0;
    }

    private void doReturn() {
        if (++ticks < TRAVEL_TICKS) return;
        villager.teleportTo(home.getX() + 0.5, home.getY(), home.getZ() + 0.5);
        VillageRegistry reg = level.getAttachedOrCreate(LivingVillages.VILLAGES);
        String name = ((MemoryHolder) villager).lv_getPersonality().name;
        reg.getOrCreate(home).record(name + "'s expedition returned: " + discovery + ".");
        level.setAttached(LivingVillages.VILLAGES, reg);
        villager.getNavigation().stop();
        state = State.FINISHED;
    }

    /** Inspect the destination and describe the standout finding. */
    private String scout(BlockPos d) {
        String biome = level.getBiome(d).unwrapKey()
                .map(k -> k.identifier().getPath().replace('_', ' '))
                .orElse("uncharted lands");

        Village other = level.getAttachedOrCreate(LivingVillages.VILLAGES).findNearest(d, 48);
        if (other != null && !other.center().equals(home)) {
            return "made contact with the village of " + other.name() + " in the " + biome + " to the " + dirName;
        }

        int water = 0, trees = 0, ore = 0, lowSpots = 0;
        int dTop = level.getHeight(Heightmap.Types.MOTION_BLOCKING, d.getX(), d.getZ());
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int dx = -8; dx <= 8; dx += 2) {
            for (int dz = -8; dz <= 8; dz += 2) {
                int x = d.getX() + dx, z = d.getZ() + dz;
                int top = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
                if (top < dTop - 6) lowSpots++;
                String p = path(level.getBlockState(m.set(x, top - 1, z)));
                if (p.equals("water")) water++;
                else if (p.contains("_log") || p.contains("leaves")) trees++;
                else if (p.endsWith("_ore")) ore++;
            }
        }

        String feature;
        if (ore >= 2)            feature = "ore-rich rock";
        else if (lowSpots >= 4)  feature = "a deep ravine";
        else if (water >= 6)     feature = "a wide expanse of water";
        else if (trees >= 8)     feature = "dense forest";
        else                     feature = "open country";
        return "found " + feature + " in the " + biome + " to the " + dirName;
    }

    private String path(BlockState bs) {
        return BuiltInRegistries.BLOCK.getKey(bs.getBlock()).getPath();
    }

    private BlockPos resolveHome() {
        VillageRegistry reg = level.getAttachedOrCreate(LivingVillages.VILLAGES);
        Village v = reg.getOrCreate(villager.blockPosition());
        level.setAttached(LivingVillages.VILLAGES, reg);
        return v.center();
    }
}
