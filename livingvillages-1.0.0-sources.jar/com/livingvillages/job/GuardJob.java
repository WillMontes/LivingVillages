package com.livingvillages.job;

import com.livingvillages.village.VillageDefense;
import com.livingvillages.world.WorldPerception;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.phys.AABB;

import java.util.List;
import java.util.UUID;

/**
 * The defensive class: a Guard-archetype villager that actively fights raiders during an
 * attack — including creepers, which iron golems refuse to engage. Hunts the nearest
 * hostile (creepers first), closes in, and strikes on a cooldown. Self-terminates when the
 * raid is over. Runs as a job so the brain-suppression mixin lets our combat steering win.
 */
public class GuardJob implements VillagerJob {

    private static final double SPEED           = 0.65;
    private static final double ATTACK_REACH_SQ = 4.0;    // ~2 blocks
    private static final float  DAMAGE          = 12.0f;  // kills most raiders in ~2 hits
    private static final int    ATTACK_CD       = 12;     // ~0.6s between strikes
    private static final double H_RADIUS = 48.0, V_RADIUS = 12.0;
    private static final double REGROUP_SQ = 36.0;

    private final ServerLevel level;
    private final Villager villager;
    private final UUID villageId;
    private final BlockPos center;
    private int cooldown;

    public GuardJob(ServerLevel level, Villager villager, UUID villageId, BlockPos center) {
        this.level = level;
        this.villager = villager;
        this.villageId = villageId;
        this.center = center;
    }

    @Override
    public boolean isFinished() {
        return villager.isRemoved() || !villager.isAlive() || !VillageDefense.isUnderThreat(villageId);
    }

    @Override
    public void tick() {
        if (isFinished()) return;
        if (cooldown > 0) cooldown--;

        Monster target = findTarget();
        if (target == null) {                               // no threat in reach — hold near the center
            if (distSq(center.getX() + 0.5, center.getY() + 0.5, center.getZ() + 0.5) > REGROUP_SQ) {
                villager.getNavigation().moveTo(center.getX() + 0.5, center.getY(), center.getZ() + 0.5, SPEED);
            }
            return;
        }

        if (distSq(target.getX(), target.getY(), target.getZ()) <= ATTACK_REACH_SQ) {
            if (cooldown <= 0) {
                villager.swing(InteractionHand.MAIN_HAND);
                target.hurtServer(level, level.damageSources().mobAttack(villager), DAMAGE);
                cooldown = ATTACK_CD;
            }
        } else {
            villager.getNavigation().moveTo(target.getX(), target.getY(), target.getZ(), SPEED);
        }
    }

    /** Nearest open-air hostile, preferring creepers (the threat golems ignore). */
    private Monster findTarget() {
        AABB box = new AABB(
                center.getX() - H_RADIUS, center.getY() - V_RADIUS, center.getZ() - H_RADIUS,
                center.getX() + H_RADIUS, center.getY() + V_RADIUS, center.getZ() + H_RADIUS);
        Monster best = null;
        double bestSq = Double.MAX_VALUE;
        boolean bestIsCreeper = false;
        for (Monster m : level.getEntitiesOfClass(Monster.class, box)) {
            if (!WorldPerception.isOutInTheOpen(level, m)) continue;
            boolean creeper = m instanceof Creeper;
            double sq = distSq(m.getX(), m.getY(), m.getZ());
            boolean better = (creeper && !bestIsCreeper) || (creeper == bestIsCreeper && sq < bestSq);
            if (better) {
                best = m;
                bestSq = sq;
                bestIsCreeper = creeper;
            }
        }
        return best;
    }

    private double distSq(double x, double y, double z) {
        return villager.distanceToSqr(x, y, z);
    }
}
