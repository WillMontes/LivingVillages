package com.livingvillages.job;

/** A type of gathering work a villager can perform. */
public enum GatherKind {
    WOOD("wood"),
    STONE("stone"),
    CROPS("food");

    public final String label;

    GatherKind(String label) {
        this.label = label;
    }
}
