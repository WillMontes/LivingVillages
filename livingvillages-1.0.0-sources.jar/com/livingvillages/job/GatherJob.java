package com.livingvillages.job;

import com.livingvillages.LivingVillages;
import com.livingvillages.interfaces.MemoryHolder;
import com.livingvillages.village.Village;
import com.livingvillages.village.VillageEconomy;
import com.livingvillages.village.VillageRegistry;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.state.BlockState;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/**
 * Feature 5 (execution) + Feature 7: a villager autonomously gathers a resource.
 *
 * Server-thread state machine: find nearest valid block → walk to it → harvest →
 * repeat to quota → carry the goods to the nearest village storage chest → deposit
 * (overflow / no chest = dropped at the spot). Harvested items are tracked by their
 * real block item, so a chest ends up with actual oak logs / stone the economy scan
 * then counts — chests are the single source of truth for the ledger.
 *
 * Build protection: only NATURAL targets are harvested — logs are taken only if leaves
 * are nearby (a real tree, not a log cabin), and only raw natural stone types are mined,
 * never bricks/cobble/polished blocks players build with.
 */
public class GatherJob implements VillagerJob {

    private enum State { SEARCH, GO_TO_TARGET, RETURN, FINISHED }

    private static final int    QUOTA          = 6;
    private static final int    CROP_YIELD     = 2;     // food items per harvested crop
    private static final double SPEED          = 0.6;
    private static final double REACH_SQ       = 6.25;
    private static final double DEPOSIT_SQ     = 9.0;
    private static final int    LEG_TIMEOUT    = 300;
    private static final int    GLOBAL_TIMEOUT = 1600;
    private static final int    SEARCH_H = 24, SEARCH_V = 6;

    /** Raw, naturally generated stone the villagers may mine — excludes player build blocks. */
    private static final Set<String> NATURAL_STONE =
            Set.of("stone", "deepslate", "andesite", "diorite", "granite", "tuff", "calcite");

    private final ServerLevel level;
    private final Villager villager;
    private final GatherKind kind;

    private State state = State.SEARCH;
    private BlockPos villageCenter;
    private BlockPos target;
    private BlockPos depositTarget;
    private final Map<Item, Integer> carried = new LinkedHashMap<>();
    private int collected;
    private int legTicks;
    private int totalTicks;
    private int failedReaches;

    public GatherJob(ServerLevel level, Villager villager, GatherKind kind) {
        this.level = level;
        this.villager = villager;
        this.kind = kind;
    }

    public boolean isFinished() {
        return state == State.FINISHED || villager.isRemoved() || !villager.isAlive();
    }

    public void tick() {
        if (isFinished()) return;
        totalTicks++;
        legTicks++;
        if (totalTicks > GLOBAL_TIMEOUT) { deposit(); return; }
        if (villageCenter == null) villageCenter = resolveVillageCenter();

        switch (state) {
            case SEARCH       -> doSearch();
            case GO_TO_TARGET -> doGoToTarget();
            case RETURN       -> doReturn();
            default           -> { }
        }
    }

    private BlockPos resolveVillageCenter() {
        VillageRegistry reg = level.getAttachedOrCreate(LivingVillages.VILLAGES);
        Village v = reg.getOrCreate(villager.blockPosition());
        level.setAttached(LivingVillages.VILLAGES, reg);
        return v.center();
    }

    private void doSearch() {
        target = findNearestTarget();
        if (target == null) {                  // nothing valid left nearby
            startReturn();
            return;
        }
        state = State.GO_TO_TARGET;
        legTicks = 0;
    }

    private void doGoToTarget() {
        if (target == null || !isTarget(target)) { state = State.SEARCH; legTicks = 0; return; }

        if (withinSq(target, REACH_SQ)) {
            harvest(target);
            collected++;
            failedReaches = 0;
            if (collected >= QUOTA) startReturn(); else { state = State.SEARCH; legTicks = 0; }
            return;
        }

        moveTo(target);
        boolean stuck = legTicks > LEG_TIMEOUT || (villager.getNavigation().isDone() && legTicks > 30);
        if (stuck) {
            failedReaches++;
            if (failedReaches >= 3) startReturn();
            else { state = State.SEARCH; legTicks = 0; }
        }
    }

    private void startReturn() {
        if (collected == 0) { state = State.FINISHED; return; }
        BlockPos storage = VillageEconomy.findStorage(level, villageCenter);
        depositTarget = storage != null ? storage : villageCenter;
        state = State.RETURN;
        legTicks = 0;
    }

    private void doReturn() {
        if (withinSq(depositTarget, DEPOSIT_SQ) || legTicks > LEG_TIMEOUT) { deposit(); return; }
        moveTo(depositTarget);
    }

    private void harvest(BlockPos pos) {
        BlockState state = level.getBlockState(pos);
        villager.swing(InteractionHand.MAIN_HAND);
        if (kind == GatherKind.CROPS) {
            Item food = cropFood(state);
            Block crop = state.getBlock();
            level.destroyBlock(pos, false, villager, 512);
            level.setBlockAndUpdate(pos, crop.defaultBlockState());   // replant a seedling so the farm regrows
            if (food != Items.AIR) carried.merge(food, CROP_YIELD, Integer::sum);
        } else {
            Item item = state.getBlock().asItem();
            level.destroyBlock(pos, false, villager, 512);            // no vanilla drops; we carry the item ourselves
            if (item != Items.AIR) carried.merge(item, 1, Integer::sum);
        }
    }

    private Item cropFood(BlockState state) {
        return switch (pathOf(state)) {
            case "carrots"   -> Items.CARROT;
            case "potatoes"  -> Items.POTATO;
            case "beetroots" -> Items.BEETROOT;
            default          -> Items.WHEAT;   // wheat and anything else
        };
    }

    private void deposit() {
        BlockPos dropAt = depositTarget != null ? depositTarget : villageCenter;
        JobStorage.Result result = JobStorage.transfer(level, dropAt, carried);

        if (collected > 0) {
            String name = ((MemoryHolder) villager).lv_getPersonality().name;
            VillageRegistry reg = level.getAttachedOrCreate(LivingVillages.VILLAGES);
            Village v = reg.getOrCreate(villager.blockPosition());
            String where = result.dropped() == 0 ? "stored it in the chest"
                         : result.stored() > 0 ? "stored what fit; the rest is at the town center"
                         : "left it at the town center (no storage)";
            v.record(name + " gathered " + collected + " " + kind.label + " and " + where + ".");
            level.setAttached(LivingVillages.VILLAGES, reg);
            LivingVillages.LOGGER.info("{} finished gathering {} {} (stored {}, dropped {}).",
                    name, collected, kind.label, result.stored(), result.dropped());
        }

        villager.getNavigation().stop();
        state = State.FINISHED;
    }

    // ---- target finding & helpers ----

    private void moveTo(BlockPos pos) {
        villager.getNavigation().moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, SPEED);
    }

    private boolean withinSq(BlockPos pos, double maxSq) {
        return villager.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) <= maxSq;
    }

    private boolean isTarget(BlockPos pos) {
        BlockState state = level.getBlockState(pos);
        return matchesBase(state) && passesExtra(pos, state);
    }

    /** Cheap base-type test, used to prune the search before the more expensive extra check. */
    private boolean matchesBase(BlockState state) {
        return switch (kind) {
            case WOOD  -> pathOf(state).contains("_log");
            case STONE -> NATURAL_STONE.contains(pathOf(state));
            case CROPS -> state.getBlock() instanceof CropBlock;
        };
    }

    /** Per-kind validity: real trees (leaves nearby) and only fully-grown crops. */
    private boolean passesExtra(BlockPos pos, BlockState state) {
        return switch (kind) {
            case WOOD  -> hasLeavesNearby(pos);
            case STONE -> true;
            case CROPS -> state.getBlock() instanceof CropBlock crop && crop.isMaxAge(state);
        };
    }

    private boolean hasLeavesNearby(BlockPos pos) {
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int dx = -2; dx <= 2; dx++) {
            for (int dy = -1; dy <= 3; dy++) {
                for (int dz = -2; dz <= 2; dz++) {
                    m.set(pos.getX() + dx, pos.getY() + dy, pos.getZ() + dz);
                    if (pathOf(m).contains("leaves")) return true;
                }
            }
        }
        return false;
    }

    private String pathOf(BlockPos pos) {
        return pathOf(level.getBlockState(pos));
    }

    private String pathOf(BlockState state) {
        return BuiltInRegistries.BLOCK.getKey(state.getBlock()).getPath();
    }

    private BlockPos findNearestTarget() {
        BlockPos o = villager.blockPosition();
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        BlockPos best = null;
        double bestSq = Double.MAX_VALUE;
        for (int dx = -SEARCH_H; dx <= SEARCH_H; dx++) {
            for (int dz = -SEARCH_H; dz <= SEARCH_H; dz++) {
                for (int dy = -SEARCH_V; dy <= SEARCH_V; dy++) {
                    m.set(o.getX() + dx, o.getY() + dy, o.getZ() + dz);
                    BlockState state = level.getBlockState(m);
                    if (!matchesBase(state)) continue;
                    double sq = o.distSqr(m);
                    if (sq >= bestSq) continue;
                    if (!passesExtra(m, state)) continue;   // leaves (wood) / maturity (crops)
                    bestSq = sq;
                    best = m.immutable();
                }
            }
        }
        return best;
    }
}
