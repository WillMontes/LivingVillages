package com.livingvillages.job;

import com.livingvillages.village.VillageDefense;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.npc.villager.Villager;

import java.util.UUID;

/**
 * Feature 12 ("move civilians indoors"): during a raid, a villager retreats to the
 * village center and stays there until the danger passes. Implemented as a job so our
 * navigation overrides the vanilla brain — relying on vanilla flee let villagers wander
 * off into the dark and die. Self-terminates once the village is no longer under threat.
 */
public class MusterJob implements VillagerJob {

    private static final double SPEED   = 0.7;   // hustle to safety
    private static final double SAFE_SQ = 9.0;   // within ~3 blocks of the rally point

    private final Villager villager;
    private final UUID villageId;
    private final BlockPos safePoint;

    public MusterJob(Villager villager, UUID villageId, BlockPos safePoint) {
        this.villager = villager;
        this.villageId = villageId;
        this.safePoint = safePoint;
    }

    @Override
    public boolean isFinished() {
        return villager.isRemoved() || !villager.isAlive() || !VillageDefense.isUnderThreat(villageId);
    }

    @Override
    public void tick() {
        if (isFinished()) return;
        double dsq = villager.distanceToSqr(safePoint.getX() + 0.5, safePoint.getY() + 0.5, safePoint.getZ() + 0.5);
        if (dsq > SAFE_SQ) {
            villager.getNavigation().moveTo(safePoint.getX() + 0.5, safePoint.getY(), safePoint.getZ() + 0.5, SPEED);
        } else {
            villager.getNavigation().stop();
        }
    }
}
