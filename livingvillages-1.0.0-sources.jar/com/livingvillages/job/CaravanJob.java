package com.livingvillages.job;

import com.livingvillages.LivingVillages;
import com.livingvillages.village.Village;
import com.livingvillages.village.VillageEconomy;
import com.livingvillages.village.VillageRegistry;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

import java.util.Map;

/**
 * Regional Trade / Transport: a carrier hauls a surplus resource from one village to a
 * nearby village that's short on it. Loads at the source's storage, makes the journey
 * (abstracted with a short delay + warp, since villages are far apart and open-terrain
 * pathfinding over that distance is unreliable), unloads at the destination's storage,
 * and heads home. Both villages remember the exchange.
 */
public class CaravanJob implements VillagerJob {

    private enum State { GO_PICKUP, TRAVEL, GO_DELIVER, FINISHED }

    private static final double SPEED        = 0.6;
    private static final double REACH_SQ     = 9.0;
    private static final int    TRAVEL_TICKS = 60;     // ~3s of "journey" each way
    private static final int    LEG_TIMEOUT  = 200;
    private static final int    TRADE_GOODWILL = 8;    // each delivery warms both villages' relations

    private final ServerLevel level;
    private final Villager carrier;
    private final BlockPos sourceCenter, destCenter;
    private final String sourceName, destName;
    private final String category;
    private final int amount;

    private State state = State.GO_PICKUP;
    private BlockPos pickupTarget, deliverTarget;
    private int carriedCount;
    private int legTicks, travelTicks;

    public CaravanJob(ServerLevel level, Villager carrier,
                      BlockPos sourceCenter, String sourceName,
                      BlockPos destCenter, String destName,
                      String category, int amount) {
        this.level = level;
        this.carrier = carrier;
        this.sourceCenter = sourceCenter;
        this.sourceName = sourceName;
        this.destCenter = destCenter;
        this.destName = destName;
        this.category = category;
        this.amount = amount;
        BlockPos s = VillageEconomy.findStorage(level, sourceCenter);
        this.pickupTarget = s != null ? s : sourceCenter;
    }

    @Override
    public boolean isFinished() {
        return state == State.FINISHED || carrier.isRemoved() || !carrier.isAlive();
    }

    @Override
    public void tick() {
        if (isFinished()) return;
        legTicks++;
        switch (state) {
            case GO_PICKUP  -> doPickup();
            case TRAVEL     -> doTravel();
            case GO_DELIVER -> doDeliver();
            default         -> { }
        }
    }

    private void doPickup() {
        if (!within(pickupTarget) && legTicks < LEG_TIMEOUT) { moveTo(pickupTarget); return; }
        carriedCount = VillageEconomy.withdraw(level, sourceCenter, category, amount);
        if (carriedCount <= 0) { state = State.FINISHED; return; }   // nothing left to send
        record(sourceCenter, sourceName + " sent " + carriedCount + " " + category + " to " + destName + ".");
        state = State.TRAVEL;
        travelTicks = 0;
    }

    private void doTravel() {
        if (++travelTicks < TRAVEL_TICKS) return;
        carrier.teleportTo(destCenter.getX() + 0.5, destCenter.getY(), destCenter.getZ() + 0.5);
        BlockPos d = VillageEconomy.findStorage(level, destCenter);
        deliverTarget = d != null ? d : destCenter;
        state = State.GO_DELIVER;
        legTicks = 0;
    }

    private void doDeliver() {
        if (!within(deliverTarget) && legTicks < LEG_TIMEOUT) { moveTo(deliverTarget); return; }
        JobStorage.transfer(level, deliverTarget, Map.of(representative(category), carriedCount));
        record(destCenter, destName + " received " + carriedCount + " " + category + " from " + sourceName + ".");
        improveRelations();
        carrier.teleportTo(sourceCenter.getX() + 0.5, sourceCenter.getY(), sourceCenter.getZ() + 0.5);  // head home
        carrier.getNavigation().stop();
        state = State.FINISHED;
    }

    /** Trading warms both villages toward each other — repeated trade builds an alliance. */
    private void improveRelations() {
        VillageRegistry reg = level.getAttachedOrCreate(LivingVillages.VILLAGES);
        Village src = reg.getOrCreate(sourceCenter);
        Village dst = reg.getOrCreate(destCenter);
        int before = src.relationWith(dst.id());
        src.adjustRelation(dst.id(), TRADE_GOODWILL);
        dst.adjustRelation(src.id(), TRADE_GOODWILL);
        if (before < 60 && src.relationWith(dst.id()) >= 60) {          // crossed into alliance
            src.record(src.name() + " and " + dst.name() + " have become allies through trade.");
            dst.record(dst.name() + " and " + src.name() + " have become allies through trade.");
        }
        level.setAttached(LivingVillages.VILLAGES, reg);
    }

    private static Item representative(String category) {
        return switch (category) {
            case "wood"     -> Items.OAK_LOG;
            case "stone"    -> Items.COBBLESTONE;
            case "food"     -> Items.BREAD;
            case "iron"     -> Items.RAW_IRON;
            case "emeralds" -> Items.EMERALD;
            default          -> Items.STONE;
        };
    }

    private void record(BlockPos center, String text) {
        VillageRegistry reg = level.getAttachedOrCreate(LivingVillages.VILLAGES);
        reg.getOrCreate(center).record(text);
        level.setAttached(LivingVillages.VILLAGES, reg);
    }

    private void moveTo(BlockPos pos) {
        carrier.getNavigation().moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, SPEED);
    }

    private boolean within(BlockPos pos) {
        return carrier.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) <= REACH_SQ;
    }
}
