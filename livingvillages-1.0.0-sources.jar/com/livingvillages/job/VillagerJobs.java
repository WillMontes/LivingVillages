package com.livingvillages.job;

import com.livingvillages.LivingVillages;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.phys.AABB;

import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Runs active villager jobs, one tick at a time, on the server thread. Jobs are keyed
 * by villager UUID (one job at a time per villager) and are transient — a server
 * restart simply cancels in-flight work; the results that mattered (deposited goods)
 * are already persisted in the village ledger.
 */
public final class VillagerJobs {

    private static final Map<UUID, VillagerJob> ACTIVE = new ConcurrentHashMap<>();

    private VillagerJobs() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> tickAll());
        LivingVillages.LOGGER.info("Villager job runner enabled.");
    }

    /** Begin (or restart) a gathering job. Safe to call from the AI callback thread. */
    public static void startGather(ServerLevel level, Villager villager, GatherKind kind) {
        ACTIVE.put(villager.getUUID(), new GatherJob(level, villager, kind));
    }

    /** Begin (or restart) a construction job. Safe to call from the AI callback thread. */
    public static void startBuild(ServerLevel level, Villager villager) {
        ACTIVE.put(villager.getUUID(), new BuildJob(level, villager));
    }

    /** Send a villager to shelter at {@code safePoint} for the duration of a raid. */
    public static void startMuster(Villager villager, UUID villageId, BlockPos safePoint) {
        ACTIVE.put(villager.getUUID(), new MusterJob(villager, villageId, safePoint));
    }

    /** Send a Guard out to fight raiders (incl. creepers) for the duration of a raid. */
    public static void startGuard(ServerLevel level, Villager villager, UUID villageId, BlockPos center) {
        ACTIVE.put(villager.getUUID(), new GuardJob(level, villager, villageId, center));
    }

    /** Begin (or continue) building the village's defensive perimeter wall. */
    public static void startWall(ServerLevel level, Villager villager) {
        ACTIVE.put(villager.getUUID(), new WallJob(level, villager));
    }

    /** Build a new house to expand village housing. */
    public static void startHouse(ServerLevel level, Villager villager) {
        ACTIVE.put(villager.getUUID(), new HouseJob(level, villager));
    }

    /** Lay a cobblestone street radiating from the village center. */
    public static void startStreet(ServerLevel level, Villager villager) {
        ACTIVE.put(villager.getUUID(), new StreetJob(level, villager));
    }

    /** Rally up to {@code size} idle adult villagers near {@code center} to build the wall together. */
    public static int startWallTeam(ServerLevel level, BlockPos center, int size) {
        int sent = 0;
        for (Villager v : level.getEntitiesOfClass(Villager.class, new AABB(center).inflate(64.0))) {
            if (sent >= size) break;
            if (v.isBaby() || isBusy(v)) continue;
            startWall(level, v);
            sent++;
        }
        return sent;
    }

    /** Send a villager on an exploration party to scout distant lands and report back. */
    public static void startExplore(ServerLevel level, Villager villager) {
        ACTIVE.put(villager.getUUID(), new ExplorerJob(level, villager));
    }

    /** Begin (or restart) a mining job — dig a staircase mine for stone and ore. */
    public static void startMine(ServerLevel level, Villager villager) {
        ACTIVE.put(villager.getUUID(), new MineJob(level, villager));
    }

    /** Dispatch a carrier to haul {@code amount} of {@code category} from one village to another. */
    public static void startCaravan(ServerLevel level, Villager carrier,
                                    BlockPos sourceCenter, String sourceName,
                                    BlockPos destCenter, String destName,
                                    String category, int amount) {
        ACTIVE.put(carrier.getUUID(),
                new CaravanJob(level, carrier, sourceCenter, sourceName, destCenter, destName, category, amount));
    }

    public static boolean isBusy(Villager villager) {
        return ACTIVE.containsKey(villager.getUUID());
    }

    /** Whether any villager near {@code center} is currently building the wall (for team dispatch). */
    public static boolean anyWallBuilder(ServerLevel level, BlockPos center, double radius) {
        for (Villager v : level.getEntitiesOfClass(Villager.class, new AABB(center).inflate(radius))) {
            if (ACTIVE.get(v.getUUID()) instanceof WallJob) return true;
        }
        return false;
    }

    /** Stop a villager's current job (e.g. so they can flee a raid). Restores their normal AI. */
    public static void cancel(Villager villager) {
        ACTIVE.remove(villager.getUUID());
    }

    private static void tickAll() {
        if (ACTIVE.isEmpty()) return;
        Iterator<Map.Entry<UUID, VillagerJob>> it = ACTIVE.entrySet().iterator();
        while (it.hasNext()) {
            VillagerJob job = it.next().getValue();
            if (job.isFinished()) { it.remove(); continue; }
            try {
                job.tick();
            } catch (Exception e) {
                LivingVillages.LOGGER.error("Villager job errored, cancelling: {}", e.getMessage());
                it.remove();
                continue;
            }
            if (job.isFinished()) it.remove();
        }
    }
}
