package com.livingvillages.job;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Container;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;

import java.util.Map;

/** Shared deposit logic for jobs: drop carried goods into a chest, spilling overflow on the ground. */
public final class JobStorage {

    public record Result(int stored, int dropped) {}

    private JobStorage() {}

    /**
     * Transfers everything in {@code carried} into the container at {@code target} (if any);
     * whatever doesn't fit is dropped at {@code target}.
     */
    public static Result transfer(ServerLevel level, BlockPos target, Map<Item, Integer> carried) {
        Container chest = level.getBlockEntity(target) instanceof Container c ? c : null;
        int stored = 0, dropped = 0;
        for (Map.Entry<Item, Integer> e : carried.entrySet()) {
            Item item = e.getKey();
            int amount = e.getValue();
            int leftover = chest != null ? insert(chest, item, amount) : amount;
            stored += amount - leftover;
            if (leftover > 0) {
                drop(level, target, item, leftover);
                dropped += leftover;
            }
        }
        if (chest != null) chest.setChanged();
        return new Result(stored, dropped);
    }

    /** Inserts up to {@code amount} of {@code item}; returns the leftover that didn't fit. */
    private static int insert(Container c, Item item, int amount) {
        int max = c.getMaxStackSize();
        int size = c.getContainerSize();
        for (int i = 0; i < size && amount > 0; i++) {     // top up existing stacks
            ItemStack s = c.getItem(i);
            if (s.isEmpty() || s.getItem() != item) continue;
            int space = max - s.getCount();
            if (space <= 0) continue;
            int add = Math.min(space, amount);
            s.grow(add);
            c.setItem(i, s);
            amount -= add;
        }
        for (int i = 0; i < size && amount > 0; i++) {     // fill empty slots
            if (!c.getItem(i).isEmpty()) continue;
            int add = Math.min(max, amount);
            c.setItem(i, new ItemStack(item, add));
            amount -= add;
        }
        return amount;
    }

    private static void drop(ServerLevel level, BlockPos pos, Item item, int amount) {
        while (amount > 0) {
            int n = Math.min(64, amount);
            Block.popResource(level, pos, new ItemStack(item, n));
            amount -= n;
        }
    }
}
