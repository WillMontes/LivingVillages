package com.livingvillages.job;

import com.livingvillages.LivingVillages;
import com.livingvillages.interfaces.MemoryHolder;
import com.livingvillages.village.Village;
import com.livingvillages.village.VillageCulture;
import com.livingvillages.village.VillageEconomy;
import com.livingvillages.village.VillageRegistry;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.phys.AABB;

import java.util.List;

/**
 * Feature 7: Autonomous Resource Management. Periodically each loaded village checks its
 * stored reserves; if a staple runs low, an idle adult villager is dispatched to gather
 * it — no player command required. This path is deterministic (it doesn't depend on the
 * LLM choosing an action), so resource upkeep is reliable.
 *
 * Only villages near a player are checked, so far-off chunks are never force-loaded.
 */
public final class AutoResourceManager {

    private static final int    CHECK_INTERVAL   = 600;          // ~30s between sweeps
    private static final double LOADED_RADIUS_SQ = 128.0 * 128.0;
    private static final int    FOOD_MIN  = 16;
    private static final int    WOOD_MIN  = 16;
    private static final int    STONE_MIN = 16;
    private static final int    IRON_MIN  = 8;    // iron only comes from mining; modest target so it doesn't monopolize
    /** When storage has this few empty slots left and wood is plentiful, build a new warehouse. */
    private static final int    FREE_SLOTS_MIN  = 3;
    private static final int    BUILD_WOOD_MIN  = 32;
    private static final int    HOUSE_WOOD_MIN       = 56;     // wood reserve before auto-building a house
    private static final int    VILLAGERS_PER_HOUSE  = 3;      // population per house before we need another
    private static final int    STREET_STONE_MIN     = 24;     // stone reserve before laying a street
    private static final int    MAX_STREETS          = 4;      // one street per cardinal direction
    private static final int    WALL_STONE_MIN  = 48;   // keep this much stone spare before fortifying
    private static final int    MARTIAL_WALL_STONE_MIN = 24;  // martial villages fortify on far less
    private static final int    WALL_TEAM_SIZE  = 4;          // villagers that build the wall together
    private static final int    SPECIALTY_TARGET = 64;  // over-produce a specialty up to this (= export threshold)
    private static final int    SPECIALTY_IRON   = 16;  // mining villages keep extra iron

    private static final long EXPLORE_COOLDOWN_MS = 5L * 60 * 1000;   // ~5 min between a village's expeditions
    private static final java.util.Map<java.util.UUID, Long> lastExplore = new java.util.concurrent.ConcurrentHashMap<>();

    private static int ticks;

    private AutoResourceManager() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (++ticks < CHECK_INTERVAL) return;
            ticks = 0;
            for (ServerLevel level : server.getAllLevels()) sweep(level);
        });
        LivingVillages.LOGGER.info("Autonomous resource management enabled.");
    }

    private static void sweep(ServerLevel level) {
        List<ServerPlayer> players = level.players();
        if (players.isEmpty()) return;

        VillageRegistry reg = level.getAttachedOrCreate(LivingVillages.VILLAGES);
        boolean changed = false;
        for (Village village : reg.all()) {
            if (!nearAnyPlayer(village.center(), players)) continue;   // skip unloaded villages

            village.replaceResources(VillageEconomy.scan(level, village.center()));
            changed = true;

            VillageCulture culture = VillageCulture.of(level, village);   // derive + persist on first use

            // A wall is a team build: when one is needed and not already underway, send a crew of
            // idle villagers (this is separate from the single autonomous worker below).
            int wallRadius = WallJob.radiusFor(level, village);   // sizes to enclose buildings (persists via changed)
            boolean wallNeeded = village.wallProgress() < WallJob.perimeterColumns(wallRadius);
            int wallStoneMin = culture == VillageCulture.MARTIAL ? MARTIAL_WALL_STONE_MIN : WALL_STONE_MIN;
            if (wallNeeded && village.resource("stone") >= wallStoneMin
                    && !VillagerJobs.anyWallBuilder(level, village.center(), VillageRegistry.VILLAGE_RADIUS)) {
                int dispatched = dispatchWallTeam(level, village.center());
                if (dispatched > 0) {
                    village.record("A crew of " + dispatched + " set out to build the village wall.");
                    LivingVillages.LOGGER.info("Dispatched a wall crew of {} for {}.", dispatched, village.name());
                    continue;
                }
            }

            if (anyoneBusy(level, village.center())) continue;          // one autonomous worker at a time
            Villager worker = findIdleVillager(level, village.center());
            if (worker == null) continue;
            String name = ((MemoryHolder) worker).lv_getPersonality().name;

            GatherKind need = neededResource(village, culture);
            if (need != null) {
                // Culture raises the target for its specialty, so specialists over-produce and export it.
                VillagerJobs.startGather(level, worker, need);
                village.record(name + " set out to gather " + need.label + " (reserves running low).");
                LivingVillages.LOGGER.info("{} auto-dispatched to gather {} for {}.",
                        name, need.label, village.name());
            } else if (village.resource("iron") < ironTarget(culture) && village.mineDepth() < MineJob.MAX_DEPTH) {
                // Iron can't be gathered on the surface — dig (deepen) the mine for it.
                VillagerJobs.startMine(level, worker);
                village.record(name + " set out to dig the mine for ore (iron running low).");
                LivingVillages.LOGGER.info("{} auto-dispatched to mine for {}.", name, village.name());
            } else if (needsHouse(level, village) && village.resource("wood") >= HOUSE_WOOD_MIN) {
                // Population outgrew housing → build another house.
                VillagerJobs.startHouse(level, worker);
                village.record(name + " began building a new house (the village is outgrowing its homes).");
                LivingVillages.LOGGER.info("{} auto-dispatched to build a house for {}.", name, village.name());
            } else if (village.streets() < MAX_STREETS && village.houses() >= 1
                    && village.resource("stone") >= STREET_STONE_MIN) {
                // After a house exists, lay roads radiating from the center until each cardinal has one.
                VillagerJobs.startStreet(level, worker);
                village.record(name + " set out to lay a new street.");
                LivingVillages.LOGGER.info("{} auto-dispatched to lay a street for {}.", name, village.name());
            } else if (storageFull(level, village.center()) && village.resource("wood") >= BUILD_WOOD_MIN) {
                // Feature 8 auto-trigger: stocked up and out of storage space → build a warehouse.
                VillagerJobs.startBuild(level, worker);
                village.record(name + " began building a warehouse (storage is full).");
                LivingVillages.LOGGER.info("{} auto-dispatched to build a warehouse for {}.", name, village.name());
            } else if (System.currentTimeMillis() - lastExplore.getOrDefault(village.id(), 0L) >= EXPLORE_COOLDOWN_MS) {
                // Nothing pressing to do → send an exploration party (on a long cooldown).
                lastExplore.put(village.id(), System.currentTimeMillis());
                VillagerJobs.startExplore(level, worker);
                village.record(name + " set out on an expedition to scout the surrounding lands.");
                LivingVillages.LOGGER.info("{} auto-dispatched to explore for {}.", name, village.name());
            }
        }
        if (changed) level.setAttached(LivingVillages.VILLAGES, reg);
    }

    private static GatherKind neededResource(Village v, VillageCulture culture) {
        if (v.resource("food")  < target(FOOD_MIN,  culture, VillageCulture.AGRICULTURAL)) return GatherKind.CROPS;
        if (v.resource("wood")  < target(WOOD_MIN,  culture, VillageCulture.FORESTRY))     return GatherKind.WOOD;
        if (v.resource("stone") < target(STONE_MIN, culture, VillageCulture.MINING))       return GatherKind.STONE;
        return null;
    }

    /** A culture over-produces its specialty up to a surplus (so it has goods to export). */
    private static int target(int base, VillageCulture culture, VillageCulture specialty) {
        return culture == specialty ? SPECIALTY_TARGET : base;
    }

    private static int ironTarget(VillageCulture culture) {
        return culture == VillageCulture.MINING ? SPECIALTY_IRON : IRON_MIN;
    }

    private static int dispatchWallTeam(ServerLevel level, BlockPos center) {
        return VillagerJobs.startWallTeam(level, center, WALL_TEAM_SIZE);
    }

    private static boolean storageFull(ServerLevel level, BlockPos center) {
        return VillageEconomy.freeSlots(level, center) <= FREE_SLOTS_MIN;
    }

    private static boolean nearAnyPlayer(BlockPos center, List<ServerPlayer> players) {
        for (ServerPlayer p : players) {
            if (center.distSqr(p.blockPosition()) <= LOADED_RADIUS_SQ) return true;
        }
        return false;
    }

    private static boolean anyoneBusy(ServerLevel level, BlockPos center) {
        for (Villager v : villagersNear(level, center)) {
            if (VillagerJobs.isBusy(v)) return true;
        }
        return false;
    }

    /** True when the village's adult population has outgrown its housing capacity. */
    private static boolean needsHouse(ServerLevel level, Village village) {
        int adults = 0;
        for (Villager v : villagersNear(level, village.center())) {
            if (!v.isBaby()) adults++;
        }
        return adults > village.houses() * VILLAGERS_PER_HOUSE;
    }

    private static Villager findIdleVillager(ServerLevel level, BlockPos center) {
        Villager best = null;
        double bestSq = Double.MAX_VALUE;
        for (Villager v : villagersNear(level, center)) {
            if (VillagerJobs.isBusy(v) || v.isBaby()) continue;
            double sq = center.distSqr(v.blockPosition());
            if (sq < bestSq) {
                bestSq = sq;
                best = v;
            }
        }
        return best;
    }

    private static List<Villager> villagersNear(ServerLevel level, BlockPos center) {
        AABB box = new AABB(center).inflate(VillageRegistry.VILLAGE_RADIUS);
        return level.getEntitiesOfClass(Villager.class, box);
    }
}
