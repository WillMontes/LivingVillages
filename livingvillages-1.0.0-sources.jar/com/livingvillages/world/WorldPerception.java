package com.livingvillages.world;

import com.livingvillages.interfaces.MemoryHolder;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;

import java.util.ArrayList;
import java.util.List;

/**
 * Feature 11: World Awareness. Produces a short natural-language description of what a
 * villager can perceive — sky/weather/biome, the lay of the land (forests, water, ore,
 * farmland, hazards) with rough compass directions, and nearby creatures and neighbors.
 *
 * The result is fed into the conversation prompt so villagers can discuss their
 * surroundings ("the eastern woods are nearly bare", "it's getting dark and I see
 * zombies"). MUST be called on the server thread — it reads blocks and entities.
 */
public final class WorldPerception {

    private static final int H_RADIUS = 14;   // horizontal block scan radius
    private static final int V_RADIUS = 5;    // vertical block scan radius
    private static final int ENTITY_RADIUS = 16;

    // Compass buckets for directional terrain.
    private static final int NORTH = 0, SOUTH = 1, EAST = 2, WEST = 3;
    private static final String[] DIR_NAME = {"north", "south", "east", "west"};

    private WorldPerception() {}

    public static String describe(ServerLevel level, Villager villager) {
        BlockPos origin = villager.blockPosition();
        return skyLine(level, origin) + "\n"
             + terrainLine(level, origin) + "\n"
             + creatureLine(level, villager);
    }

    private static String skyLine(ServerLevel level, BlockPos pos) {
        long t = Math.floorMod(level.getOverworldClockTime(), 24000L);
        String time;
        if (t < 1000)       time = "early dawn";
        else if (t < 5000)  time = "morning";
        else if (t < 9000)  time = "midday";
        else if (t < 12000) time = "late afternoon";
        else if (t < 13000) time = "dusk";
        else if (t < 22000) time = "night";
        else                time = "the small hours before dawn";

        String weather = level.isThundering() ? "a thunderstorm overhead"
                       : level.isRaining()    ? "steady rain"
                       : "clear skies";

        String biome = level.getBiome(pos).unwrapKey()
                .map(k -> k.identifier().getPath().replace('_', ' '))
                .orElse("unfamiliar lands");

        return "It is " + time + " with " + weather + ". You are in the " + biome + ".";
    }

    private static String terrainLine(ServerLevel level, BlockPos origin) {
        int[] trees = new int[4]; int treeTotal = 0;
        int[] water = new int[4]; int waterTotal = 0;
        int[] ore   = new int[4]; int oreTotal   = 0;
        boolean farmland = false, lava = false;

        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        int ox = origin.getX(), oy = origin.getY(), oz = origin.getZ();
        for (int dx = -H_RADIUS; dx <= H_RADIUS; dx++) {
            for (int dz = -H_RADIUS; dz <= H_RADIUS; dz++) {
                int dir = direction(dx, dz);
                for (int dy = -V_RADIUS; dy <= V_RADIUS; dy++) {
                    m.set(ox + dx, oy + dy, oz + dz);
                    BlockState state = level.getBlockState(m);
                    if (state.isAir()) continue;
                    String path = BuiltInRegistries.BLOCK.getKey(state.getBlock()).getPath();
                    if (path.contains("_log"))                         { trees[dir]++; treeTotal++; }
                    else if (path.equals("water"))                     { water[dir]++; waterTotal++; }
                    else if (path.endsWith("_ore") || path.equals("ancient_debris")) { ore[dir]++; oreTotal++; }
                    else if (path.equals("farmland") || path.equals("wheat")
                            || path.equals("carrots") || path.equals("potatoes")
                            || path.equals("beetroots"))               { farmland = true; }
                    else if (path.equals("lava"))                      { lava = true; }
                }
            }
        }

        List<String> features = new ArrayList<>();
        if (treeTotal >= 20) {
            features.add((treeTotal >= 120 ? "dense forest to the " : "scattered trees to the ") + dominant(trees));
        }
        if (waterTotal >= 12) features.add("water to the " + dominant(water));
        if (oreTotal >= 1)    features.add("exposed ore to the " + dominant(ore));
        if (farmland)         features.add("tended farmland close by");
        if (lava)             features.add("dangerous lava nearby");

        if (features.isEmpty()) return "The land immediately around you is plain and open.";
        return "Around you: " + String.join("; ", features) + ".";
    }

    private static String creatureLine(ServerLevel level, Villager villager) {
        // Flat box: wide horizontally, shallow vertically, so cave mobs below don't count as "nearby".
        BlockPos p = villager.blockPosition();
        AABB box = new AABB(
                p.getX() - ENTITY_RADIUS, p.getY() - 6, p.getZ() - ENTITY_RADIUS,
                p.getX() + ENTITY_RADIUS, p.getY() + 6, p.getZ() + ENTITY_RADIUS);
        List<Monster> monsters   = level.getEntitiesOfClass(Monster.class, box);
        monsters.removeIf(mm -> !isOutInTheOpen(level, mm));   // ignore mobs underground in caves
        List<Animal> animals     = level.getEntitiesOfClass(Animal.class, box);
        List<Villager> villagers = level.getEntitiesOfClass(Villager.class, box);

        List<String> parts = new ArrayList<>();
        if (!monsters.isEmpty()) {
            Monster nearest = null;
            double bestSq = Double.MAX_VALUE;
            for (Monster mm : monsters) {
                double d = p.distSqr(mm.blockPosition());
                if (d < bestSq) { bestSq = d; nearest = mm; }
            }
            BlockPos mp = nearest.blockPosition();
            String dir = DIR_NAME[direction(mp.getX() - p.getX(), mp.getZ() - p.getZ())];
            parts.add("DANGER: " + monsters.size() + " hostile creature"
                    + (monsters.size() == 1 ? "" : "s") + " nearby. Nearest is a "
                    + nearest.getName().getString() + " at coordinates (" + mp.getX() + ", " + mp.getY()
                    + ", " + mp.getZ() + "), about " + (int) Math.sqrt(bestSq) + " blocks to the " + dir);
        }

        List<String> neighbours = new ArrayList<>();
        for (Villager v : villagers) {
            if (v == villager) continue;
            neighbours.add(((MemoryHolder) v).lv_getPersonality().name);
            if (neighbours.size() >= 4) break;
        }
        if (!neighbours.isEmpty()) parts.add("fellow villagers nearby: " + String.join(", ", neighbours));
        if (!animals.isEmpty())    parts.add("some animals graze nearby");

        if (parts.isEmpty()) return "No one else is around right now.";
        return String.join(". ", parts) + ".";
    }

    /** True if the entity is at/above the surface (not down in a cave). */
    public static boolean isOutInTheOpen(ServerLevel level, Entity e) {
        BlockPos p = e.blockPosition();
        return p.getY() >= level.getHeight(Heightmap.Types.MOTION_BLOCKING, p.getX(), p.getZ()) - 1;
    }

    private static int direction(int dx, int dz) {
        if (Math.abs(dx) >= Math.abs(dz)) return dx >= 0 ? EAST : WEST;
        return dz >= 0 ? SOUTH : NORTH;
    }

    private static String dominant(int[] counts) {
        int best = 0;
        for (int i = 1; i < 4; i++) if (counts[i] > counts[best]) best = i;
        return DIR_NAME[best];
    }
}
