package com.livingvillages.mixin;

import com.livingvillages.LivingVillages;
import com.livingvillages.interfaces.MemoryHolder;
import com.livingvillages.lineage.VillagerLineage;
import com.livingvillages.memory.VillagerMemory;
import com.livingvillages.personality.VillagerPersonality;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.npc.villager.Villager;
import org.spongepowered.asm.mixin.Mixin;

/**
 * Implements MemoryHolder on every Villager by delegating to Fabric's
 * Data Attachment API. No manual NBT hooks needed — Fabric persists the
 * attachment automatically alongside the entity's save data.
 *
 * VillagerPersonality is UUID-seeded and fully deterministic, so it is
 * re-derived on demand rather than stored at all.
 */
@Mixin(Villager.class)
public abstract class VillagerMemoryMixin implements MemoryHolder {

    @Override
    public VillagerMemory lv_getMemory() {
        // getAttachedOrCreate uses the initializer (VillagerMemory::new) registered
        // in LivingVillages, so this is never null.
        return ((Villager) (Object) this).getAttachedOrCreate(LivingVillages.VILLAGER_MEMORY);
    }

    @Override
    public VillagerPersonality lv_getPersonality() {
        // Same UUID → same personality every time. No persistence required.
        return VillagerPersonality.random(((Entity) (Object) this).getUUID());
    }

    @Override
    public VillagerLineage lv_getLineage() {
        return ((Villager) (Object) this).getAttachedOrCreate(LivingVillages.VILLAGER_LINEAGE);
    }
}
