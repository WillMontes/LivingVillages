package com.livingvillages.mixin;

import com.livingvillages.job.VillagerJobs;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.npc.villager.Villager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * While a villager is running one of our jobs, skip its vanilla brain step. The brain is
 * what fights us for control of navigation (a farmer's WORK activity keeps re-targeting
 * crops, etc.). Cancelling {@code customServerAiStep} stops the brain from issuing its own
 * walk targets, leaving our job's navigation as the only thing steering. The rest of the
 * mob's normal ticking (path following, physics) is untouched, so our moveTo still drives
 * movement.
 */
@Mixin(Villager.class)
public abstract class VillagerJobBrainMixin {

    @Inject(method = "customServerAiStep", at = @At("HEAD"), cancellable = true)
    private void livingvillages$suppressBrainWhileWorking(ServerLevel level, CallbackInfo ci) {
        if (VillagerJobs.isBusy((Villager) (Object) this)) {
            ci.cancel();
        }
    }
}
