package com.livingvillages.memory;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;

import java.util.*;

public class VillagerMemory {

    /** Rolling conversation log — recent dialogue, oldest dropped first. */
    private static final int MAX_ENTRIES = 40;
    /** Durable facts the villager has chosen to remember (e.g. "Player prefers to be called Will"). */
    private static final int MAX_FACTS   = 30;

    private static final String NBT_LOG   = "LVMemories";
    private static final String NBT_FACTS = "LVFacts";

    private final Deque<String> entries = new ArrayDeque<>();
    /** LinkedHashSet: dedupes facts while preserving the order they were learned. */
    private final LinkedHashSet<String> facts = new LinkedHashSet<>();

    /**
     * Codec used by the Fabric Data Attachment API for automatic persistence.
     * Stores both the durable facts and the rolling conversation log. Both fields
     * are optional so a villager saved before facts existed still loads cleanly.
     */
    public static final Codec<VillagerMemory> CODEC = RecordCodecBuilder.create(inst -> inst.group(
            Codec.STRING.listOf().optionalFieldOf("facts", List.of())
                    .forGetter(m -> new ArrayList<>(m.facts)),
            Codec.STRING.listOf().optionalFieldOf("log", List.of())
                    .forGetter(m -> new ArrayList<>(m.entries))
    ).apply(inst, VillagerMemory::fromData));

    public VillagerMemory() {}

    private static VillagerMemory fromData(List<String> facts, List<String> log) {
        VillagerMemory m = new VillagerMemory();
        facts.forEach(m::rememberFact);
        log.forEach(m::remember);
        return m;
    }

    // ---- Rolling conversation log ----

    public void remember(String event) {
        if (event == null || event.isBlank()) return;
        entries.addLast(event);
        while (entries.size() > MAX_ENTRIES) entries.removeFirst();
    }

    public List<String> getAll() { return new ArrayList<>(entries); }

    public String toPromptString(int limit) {
        List<String> all = getAll();
        int start = Math.max(0, all.size() - limit);
        List<String> recent = all.subList(start, all.size());
        return recent.isEmpty() ? "(no memories yet)" : String.join("\n", recent);
    }

    // ---- Durable facts ----

    public void rememberFact(String fact) {
        if (fact == null || fact.isBlank()) return;
        String trimmed = fact.trim();
        // Re-inserting moves nothing in a LinkedHashSet, so drop-then-add keeps the
        // most recently reinforced fact newest and lets the cap evict the stalest.
        facts.remove(trimmed);
        facts.add(trimmed);
        while (facts.size() > MAX_FACTS) {
            Iterator<String> it = facts.iterator();
            it.next();
            it.remove();
        }
    }

    public List<String> getFacts() { return new ArrayList<>(facts); }

    public String factsPromptString() {
        return facts.isEmpty() ? "(nothing memorable yet)" : String.join("\n", facts);
    }

    // ---- Manual NBT helpers (kept for callers that persist outside the attachment) ----

    public void writeNbt(CompoundTag tag) {
        ListTag log = new ListTag();
        for (String e : entries) log.add(StringTag.valueOf(e));
        tag.put(NBT_LOG, log);

        ListTag factList = new ListTag();
        for (String f : facts) factList.add(StringTag.valueOf(f));
        tag.put(NBT_FACTS, factList);
    }

    public void readNbt(CompoundTag tag) {
        entries.clear();
        tag.getList(NBT_LOG).ifPresent(list -> {
            for (int i = 0; i < list.size(); i++) list.getString(i).ifPresent(entries::addLast);
        });
        facts.clear();
        tag.getList(NBT_FACTS).ifPresent(list -> {
            for (int i = 0; i < list.size(); i++) list.getString(i).ifPresent(this::rememberFact);
        });
    }
}
