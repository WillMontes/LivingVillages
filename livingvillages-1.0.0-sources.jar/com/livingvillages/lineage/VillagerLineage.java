package com.livingvillages.lineage;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

import java.util.ArrayList;
import java.util.List;

/**
 * Per-villager ancestry: who their parent was, when they were born, and the notable deeds
 * the village remembers about their line. Persisted via Fabric attachment so generations
 * truly remember important ancestors.
 *
 * Lineage is "initialized" the first time the manager sees a villager — they're either
 * adopted into an existing line as a child of the eldest local villager, or marked as a
 * founder when no elder exists.
 */
public class VillagerLineage {

    private static final int MAX_DEEDS = 6;

    private String parentName = "";
    private long birthEpoch = 0L;
    private final List<String> deeds = new ArrayList<>();

    public static final Codec<VillagerLineage> CODEC = RecordCodecBuilder.create(inst -> inst.group(
            Codec.STRING.optionalFieldOf("parent", "").forGetter(l -> l.parentName),
            Codec.LONG.optionalFieldOf("birth", 0L).forGetter(l -> l.birthEpoch),
            Codec.STRING.listOf().optionalFieldOf("deeds", List.of()).forGetter(l -> new ArrayList<>(l.deeds))
    ).apply(inst, VillagerLineage::fromData));

    public VillagerLineage() {}

    private static VillagerLineage fromData(String parent, long birth, List<String> deeds) {
        VillagerLineage l = new VillagerLineage();
        l.parentName = parent;
        l.birthEpoch = birth;
        deeds.forEach(l::rememberDeed);
        return l;
    }

    public boolean isInitialized()       { return birthEpoch > 0L; }
    public boolean isFounder()           { return parentName.isEmpty(); }
    public String  parentName()          { return parentName; }
    public long    birthEpoch()          { return birthEpoch; }
    public List<String> deeds()          { return new ArrayList<>(deeds); }

    public void initFounder(long epoch) {
        this.birthEpoch = epoch;
    }

    public void initChildOf(String parent, long epoch, List<String> inheritedDeeds) {
        this.parentName = parent;
        this.birthEpoch = epoch;
        deeds.clear();
        if (inheritedDeeds != null) inheritedDeeds.forEach(this::rememberDeed);
    }

    public void rememberDeed(String deed) {
        if (deed == null || deed.isBlank()) return;
        String trimmed = deed.trim();
        deeds.remove(trimmed);
        deeds.add(trimmed);
        while (deeds.size() > MAX_DEEDS) deeds.remove(0);
    }

    public String summary() {
        if (!isInitialized()) return "";
        if (isFounder() && deeds.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        if (!parentName.isEmpty()) sb.append("You are a descendant of ").append(parentName).append(". ");
        if (!deeds.isEmpty()) {
            sb.append("Honored deeds of your line: ");
            for (int i = 0; i < deeds.size(); i++) {
                if (i > 0) sb.append("; ");
                sb.append(deeds.get(i));
            }
            sb.append('.');
        }
        return sb.toString();
    }
}
