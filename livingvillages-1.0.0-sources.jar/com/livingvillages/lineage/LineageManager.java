package com.livingvillages.lineage;

import com.livingvillages.LivingVillages;
import com.livingvillages.interfaces.MemoryHolder;
import com.livingvillages.village.Village;
import com.livingvillages.village.VillageRegistry;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.phys.AABB;

import java.util.ArrayList;
import java.util.List;

/**
 * Establishes and maintains family lineages: every new villager becomes either a founder
 * (a fresh line) or a descendant of the local eldest villager, inheriting their honored
 * deeds. Deaths of named villagers are recorded so their line — and the village —
 * remembers them.
 *
 * Lineage data lives on each villager's persistent attachment, so generations carry their
 * heritage across saves and restarts.
 */
public final class LineageManager {

    private static final int    CHECK_INTERVAL   = 600;          // ~30s between sweeps
    private static final double LOADED_RADIUS_SQ = 128.0 * 128.0;

    private static int ticks;

    private LineageManager() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (++ticks < CHECK_INTERVAL) return;
            ticks = 0;
            for (ServerLevel level : server.getAllLevels()) sweep(level);
        });

        ServerLivingEntityEvents.AFTER_DEATH.register((entity, damageSource) -> {
            if (!(entity instanceof Villager villager)) return;
            if (!(entity.level() instanceof ServerLevel level)) return;
            recordDeath(level, villager);
        });

        LivingVillages.LOGGER.info("Family lineage tracking enabled.");
    }

    private static void sweep(ServerLevel level) {
        List<ServerPlayer> players = level.players();
        if (players.isEmpty()) return;

        VillageRegistry reg = level.getAttachedOrCreate(LivingVillages.VILLAGES);
        boolean changed = false;
        long now = System.currentTimeMillis();
        for (Village village : reg.all()) {
            if (!nearAnyPlayer(village.center(), players)) continue;

            List<Villager> members = level.getEntitiesOfClass(Villager.class,
                    new AABB(village.center()).inflate(VillageRegistry.VILLAGE_RADIUS));

            // Snapshot the established elders BEFORE assigning lineages this tick, so that
            // newly-initialized villagers in this same sweep don't accidentally become each
            // other's parents.
            List<Villager> elders = new ArrayList<>();
            for (Villager v : members) {
                if (((MemoryHolder) v).lv_getLineage().isInitialized()) elders.add(v);
            }

            for (Villager v : members) {
                VillagerLineage lin = ((MemoryHolder) v).lv_getLineage();
                if (lin.isInitialized()) continue;

                Villager parent = pickEldest(elders, now);
                if (parent == null) {
                    lin.initFounder(now);             // first generation — no chronicle spam
                } else {
                    VillagerLineage parentLin = ((MemoryHolder) parent).lv_getLineage();
                    String parentName = ((MemoryHolder) parent).lv_getPersonality().name;
                    lin.initChildOf(parentName, now, parentLin.deeds());
                    String childName = ((MemoryHolder) v).lv_getPersonality().name;
                    village.record(childName + " was born to " + parentName
                            + (parentLin.isFounder() ? "" : " of the line of " + parentLin.parentName())
                            + ".");
                }
                changed = true;
            }
        }
        if (changed) level.setAttached(LivingVillages.VILLAGES, reg);
    }

    /** Pick the villager with the earliest birth — most likely to be a respected elder. */
    private static Villager pickEldest(List<Villager> elders, long now) {
        Villager best = null;
        long bestAge = -1L;
        for (Villager e : elders) {
            long age = now - ((MemoryHolder) e).lv_getLineage().birthEpoch();
            if (age > bestAge) { bestAge = age; best = e; }
        }
        return best;
    }

    private static void recordDeath(ServerLevel level, Villager villager) {
        VillagerLineage lin = ((MemoryHolder) villager).lv_getLineage();
        if (!lin.isInitialized()) return;

        VillageRegistry reg = level.getAttachedOrCreate(LivingVillages.VILLAGES);
        Village village = reg.findNearest(villager.blockPosition(), VillageRegistry.VILLAGE_RADIUS);
        if (village == null) return;

        String name = ((MemoryHolder) villager).lv_getPersonality().name;
        String descent = lin.parentName().isEmpty() ? " (a founder of the village)"
                                                    : ", child of " + lin.parentName();
        village.record(name + " has died" + descent + ".");

        // Add this villager to the family's chronicle of deeds so descendants remember them.
        String deed = name + " lived in " + village.name();
        propagateDeed(level, villager, deed);

        level.setAttached(LivingVillages.VILLAGES, reg);
    }

    /** Adds a deed to every living villager in the same village so the line carries it forward. */
    private static void propagateDeed(ServerLevel level, Villager dead, String deed) {
        Village village = level.getAttachedOrCreate(LivingVillages.VILLAGES)
                .findNearest(dead.blockPosition(), VillageRegistry.VILLAGE_RADIUS);
        if (village == null) return;
        AABB box = new AABB(village.center()).inflate(VillageRegistry.VILLAGE_RADIUS);
        String deadName = ((MemoryHolder) dead).lv_getPersonality().name;
        for (Villager v : level.getEntitiesOfClass(Villager.class, box)) {
            if (v == dead) continue;
            VillagerLineage lin = ((MemoryHolder) v).lv_getLineage();
            // Children inherit the deed; bystanders skip, so the family's record stays personal.
            if (lin.parentName().equals(deadName)) lin.rememberDeed(deed);
        }
    }

    private static boolean nearAnyPlayer(BlockPos center, List<ServerPlayer> players) {
        for (ServerPlayer p : players) {
            if (center.distSqr(p.blockPosition()) <= LOADED_RADIUS_SQ) return true;
        }
        return false;
    }
}
