package com.livingvillages.entity;

import com.livingvillages.LivingVillages;
import com.livingvillages.interfaces.MemoryHolder;
import com.livingvillages.personality.VillagerPersonality;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.npc.villager.Villager;

/**
 * Gives every villager a visible nameplate above its head, drawn from its
 * deterministic personality, so names render the way a player's username does
 * instead of the default hover-only "Villager" label.
 */
public class VillagerNameTags {

    public static void register() {
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (!(entity instanceof Villager villager)) return;
            // Respect a name a player gave with a name tag.
            if (villager.hasCustomName()) return;

            VillagerPersonality personality = ((MemoryHolder) villager).lv_getPersonality();
            villager.setCustomName(Component.literal(personality.name));
            villager.setCustomNameVisible(true);
        });
        LivingVillages.LOGGER.info("Villager name tags enabled.");
    }
}
