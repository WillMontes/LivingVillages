package com.livingvillages;

import com.livingvillages.ai.AiBrainService;
import com.livingvillages.config.LvConfig;
import com.livingvillages.entity.VillagerNameTags;
import com.livingvillages.job.AutoResourceManager;
import com.livingvillages.job.DiplomacyManager;
import com.livingvillages.job.TradeRoutes;
import com.livingvillages.job.VillagerJobs;
import com.livingvillages.lineage.LineageManager;
import com.livingvillages.lineage.VillagerLineage;
import com.livingvillages.memory.VillagerMemory;
import com.livingvillages.network.PlayerVillagerChat;
import com.livingvillages.village.VillageCommands;
import com.livingvillages.village.VillageDefense;
import com.livingvillages.village.VillageEvents;
import com.livingvillages.village.VillageRegistry;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LivingVillages implements ModInitializer {
	public static final String MOD_ID = "livingvillages";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	/** Persistent per-villager conversation memory, managed by Fabric's Data Attachment API. */
	public static final AttachmentType<VillagerMemory> VILLAGER_MEMORY =
			AttachmentRegistry.create(
					Identifier.fromNamespaceAndPath(MOD_ID, "villager_memory"),
					builder -> builder.persistent(VillagerMemory.CODEC).initializer(VillagerMemory::new)
			);

	/** Per-level registry of villages (shared memory, reputation, economy), attached to the ServerLevel. */
	public static final AttachmentType<VillageRegistry> VILLAGES =
			AttachmentRegistry.create(
					Identifier.fromNamespaceAndPath(MOD_ID, "villages"),
					builder -> builder.persistent(VillageRegistry.CODEC).initializer(VillageRegistry::new)
			);

	/** Persistent per-villager family lineage (parent, birth, inherited deeds). */
	public static final AttachmentType<VillagerLineage> VILLAGER_LINEAGE =
			AttachmentRegistry.create(
					Identifier.fromNamespaceAndPath(MOD_ID, "villager_lineage"),
					builder -> builder.persistent(VillagerLineage.CODEC).initializer(VillagerLineage::new)
			);

	@Override
	public void onInitialize() {
		LOGGER.info("Living Villages initializing...");

		LvConfig cfg = LvConfig.get();
		LOGGER.info("Config: backend={}, model={}, baseUrl={}",
				cfg.backend, cfg.model, cfg.resolvedBaseUrl());
		LOGGER.info("Edit config at: {}",
				FabricLoader.getInstance().getConfigDir().resolve("livingvillages.json"));

		AiBrainService.getInstance().init();
		PlayerVillagerChat.register();
		VillagerNameTags.register();
		VillageEvents.register();
		VillageCommands.register();
		VillagerJobs.register();
		AutoResourceManager.register();
		VillageDefense.register();
		TradeRoutes.register();
		DiplomacyManager.register();
		LineageManager.register();

		LOGGER.info("Living Villages ready.");
	}

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}
}